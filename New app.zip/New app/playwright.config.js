module.exports = {
  testDir: 'tests-e2e',
  testMatch: /.*\.spec\.js$/,
  retries: process.env.CI ? 2 : 0
};
