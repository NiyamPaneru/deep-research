// Simple Authentication System for Smart Clipboard AI

class AuthManager {
  constructor() {
    this.currentUser = null;
    this.authListeners = [];
  }

  // Check if user is authenticated
  isAuthenticated() {
    return !!this.getCurrentUser();
  }

  // Get current user from storage
  getCurrentUser() {
    if (this.currentUser) return this.currentUser;
    
    try {
      const stored = localStorage.getItem('smartClipboard_user');
      this.currentUser = stored ? JSON.parse(stored) : null;
      return this.currentUser;
    } catch (error) {
      console.error('Error getting current user:', error);
      return null;
    }
  }

  // Simple email/password registration
  async register(email, password, name = '') {
    if (!email || !password) {
      throw new Error('Email and password are required');
    }

    if (password.length < 6) {
      throw new Error('Password must be at least 6 characters');
    }

    // Check if user already exists
    const existingUsers = this.getAllUsers();
    if (existingUsers.find(u => u.email === email)) {
      throw new Error('User already exists with this email');
    }

    // Create new user
    const user = {
      id: Date.now().toString(),
      email: email.toLowerCase().trim(),
      name: name.trim() || email.split('@')[0],
      tier: 'free',
      createdAt: new Date().toISOString(),
      lastLogin: new Date().toISOString()
    };

    // Store password hash (simple for demo - use proper hashing in production)
    const passwordHash = btoa(password + email); // Basic encoding
    
    // Save user
    this.saveUser(user, passwordHash);
    this.setCurrentUser(user);
    
    return user;
  }

  // Simple email/password login
  async login(email, password) {
    if (!email || !password) {
      throw new Error('Email and password are required');
    }

    const users = this.getAllUsers();
    const user = users.find(u => u.email === email.toLowerCase().trim());
    
    if (!user) {
      throw new Error('Invalid email or password');
    }

    // Verify password
    const storedHash = localStorage.getItem(`smartClipboard_pwd_${user.id}`);
    const passwordHash = btoa(password + email.toLowerCase().trim());
    
    if (storedHash !== passwordHash) {
      throw new Error('Invalid email or password');
    }

    // Update last login
    user.lastLogin = new Date().toISOString();
    this.saveUser(user, storedHash);
    this.setCurrentUser(user);
    
    return user;
  }

  // Logout
  logout() {
    this.currentUser = null;
    localStorage.removeItem('smartClipboard_user');
    this.notifyAuthListeners('logout');
  }

  // Update user tier (for subscriptions)
  updateUserTier(tier) {
    const user = this.getCurrentUser();
    if (!user) throw new Error('No authenticated user');
    
    user.tier = tier;
    user.updatedAt = new Date().toISOString();
    
    const passwordHash = localStorage.getItem(`smartClipboard_pwd_${user.id}`);
    this.saveUser(user, passwordHash);
    this.setCurrentUser(user);
    
    return user;
  }

  // Private methods
  saveUser(user, passwordHash) {
    const users = this.getAllUsers();
    const existingIndex = users.findIndex(u => u.id === user.id);
    
    if (existingIndex >= 0) {
      users[existingIndex] = user;
    } else {
      users.push(user);
    }
    
    localStorage.setItem('smartClipboard_users', JSON.stringify(users));
    localStorage.setItem(`smartClipboard_pwd_${user.id}`, passwordHash);
  }

  setCurrentUser(user) {
    this.currentUser = user;
    localStorage.setItem('smartClipboard_user', JSON.stringify(user));
    localStorage.setItem('userTier', user.tier); // For compatibility
    this.notifyAuthListeners('login', user);
  }

  getAllUsers() {
    try {
      const stored = localStorage.getItem('smartClipboard_users');
      return stored ? JSON.parse(stored) : [];
    } catch (error) {
      console.error('Error getting users:', error);
      return [];
    }
  }

  // Auth state listeners
  onAuthChange(callback) {
    this.authListeners.push(callback);
  }

  notifyAuthListeners(event, user = null) {
    this.authListeners.forEach(callback => {
      try {
        callback(event, user);
      } catch (error) {
        console.error('Auth listener error:', error);
      }
    });
  }
}

// Global auth instance
window.authManager = new AuthManager();

// Auto-login check on page load
document.addEventListener('DOMContentLoaded', () => {
  const user = window.authManager.getCurrentUser();
  if (user) {
    console.log('Auto-logged in as:', user.email);
  }
});