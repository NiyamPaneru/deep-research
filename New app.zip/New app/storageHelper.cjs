'use strict';

const DEVICE_KEY = 'smartClipboard_deviceId_v1';
const memoryStore = new Map();

function getChromeStorage() {
  if (typeof chrome !== 'undefined' && chrome.storage?.local) {
    return chrome.storage.local;
  }
  return null;
}

function normalizeKeys(keys) {
  if (Array.isArray(keys)) return keys;
  if (keys && typeof keys === 'object') return Object.keys(keys);
  if (typeof keys === 'string') return [keys];
  return [];
}

async function storageGet(keys) {
  const area = getChromeStorage();
  if (!area) {
    const entries = normalizeKeys(keys);
    if (!entries.length) return {};
    return entries.reduce((acc, key) => {
      acc[key] = memoryStore.get(key);
      return acc;
    }, {});
  }

  try {
    const result = area.get(keys);
    if (result && typeof result.then === 'function') {
      return result.catch(() => ({}));
    }
  } catch (_error) {
    return {};
  }

  return new Promise((resolve) => {
    try {
      area.get(keys, (items) => {
        if (chrome.runtime?.lastError) {
          resolve({});
          return;
        }
        resolve(items || {});
      });
    } catch (_error) {
      resolve({});
    }
  });
}

async function storageSet(items) {
  if (!items || typeof items !== 'object') {
    return false;
  }

  const area = getChromeStorage();
  if (!area) {
    Object.entries(items).forEach(([key, value]) => {
      memoryStore.set(key, value);
    });
    return true;
  }

  const result = area.set(items);
  if (result && typeof result.then === 'function') {
    try {
      await result;
      return true;
    } catch (_error) {
      return false;
    }
  }

  return new Promise((resolve) => {
    try {
      area.set(items, () => {
        if (chrome.runtime?.lastError) {
          resolve(false);
          return;
        }
        resolve(true);
      });
    } catch (_error) {
      resolve(false);
    }
  });
}

async function storageRemove(keys) {
  const entries = normalizeKeys(keys);
  const area = getChromeStorage();

  if (!area) {
    if (!entries.length && typeof keys === 'string') {
      memoryStore.delete(keys);
      return true;
    }
    entries.forEach((key) => memoryStore.delete(key));
    return true;
  }

  const result = area.remove(keys);
  if (result && typeof result.then === 'function') {
    try {
      await result;
      return true;
    } catch (_error) {
      return false;
    }
  }

  return new Promise((resolve) => {
    try {
      area.remove(keys, () => {
        if (chrome.runtime?.lastError) {
          resolve(false);
          return;
        }
        resolve(true);
      });
    } catch (_error) {
      resolve(false);
    }
  });
}

function getNodeCrypto() {
  if (typeof require === 'function') {
    try {
      return require('crypto');
    } catch (_error) {
      return null;
    }
  }
  return null;
}

function generateDeviceId() {
  if (typeof crypto !== 'undefined' && crypto.randomUUID) {
    return crypto.randomUUID();
  }

  const nodeCrypto = getNodeCrypto();
  if (nodeCrypto?.randomUUID) {
    return nodeCrypto.randomUUID();
  }

  const source = nodeCrypto?.randomBytes ? nodeCrypto : Math;
  const randomValue = typeof source.randomBytes === 'function'
    ? source.randomBytes(8).toString('hex')
    : source.random().toString(36).slice(2, 10);
  return `device_${randomValue}`;
}

async function getOrCreateDeviceId() {
  const current = await storageGet([DEVICE_KEY]);
  const existing = current?.[DEVICE_KEY];
  if (existing && typeof existing === 'string') {
    return existing;
  }

  const generated = generateDeviceId();
  await storageSet({ [DEVICE_KEY]: generated });
  return generated;
}

const storageHelper = {
  storageGet,
  storageSet,
  storageRemove,
  getOrCreateDeviceId,
  get: storageGet,
  set: storageSet,
  remove: storageRemove
};

if (typeof globalThis !== 'undefined') {
  globalThis.storageHelper = storageHelper;
}

module.exports = storageHelper;
module.exports.storageHelper = storageHelper;
module.exports.storageGet = storageGet;
module.exports.storageSet = storageSet;
module.exports.storageRemove = storageRemove;
module.exports.getOrCreateDeviceId = getOrCreateDeviceId;
