# Smart Clipboard AI – Post-Refactor TODOs

## 🔧 Dev Verification
- [ ] Verify history layout and footer alignment
- [ ] Test background messaging reliability (retry logic)
- [ ] Confirm Supabase verify_ltd() Edge Function works
- [ ] Test RocketHub LTD activation flow
- [ ] Confirm jokes rotate every 90s across pages
- [ ] Check humor toggle updates instantly
- [ ] Verify chrome.storage replaces localStorage
- [ ] Remove debug logs from production build
- [ ] Test "Move to History" button in popup

## 🧠 UX Testing
- [ ] Free user flow: 3 AI generations per 36h
- [ ] LTD user flow: license key + email activation
- [ ] Pro user flow (later): sign-in + subscription
- [ ] Visual consistency (popup, settings, history)
- [ ] Humor experience (rotation + tone toggle)
- [ ] Single joke visible per page (no duplicates)

## 🔒 Security
- [ ] No plaintext tokens in code
- [ ] Supabase API key only used in Edge Functions
- [ ] License key obfuscation working
- [ ] Rate limit Edge Function (5/min per IP)
- [ ] config.example.js template created ✓
- [ ] Real config.js added to .gitignore

## 🧩 Deployment
- [ ] Build production ZIP
- [ ] Test on Chrome Dev mode
- [ ] Ship RocketHub version (LTD)
- [ ] Prepare Pro version (with Google Sign-In)

## 📋 Supabase Setup (Manual)
- [ ] Create Supabase project
- [ ] Run SQL schema for `licenses` table
- [ ] Run SQL schema for `subscriptions` table
- [ ] Deploy `verify_ltd` Edge Function
- [ ] Test Edge Function with curl
- [ ] Integrate Edge Function with extension

## 🎨 UI Polish
- [ ] History page: footer + humor panel ✓
- [ ] Popup: single joke, no duplicate sections ✓
- [ ] Settings: RocketHub promo visibility (date-based)
- [ ] Settings: humor toggle + interval control
- [ ] Consistent spacing across all pages

## 🚀 RocketHub Launch Prep
- [ ] Set ROCKETHUB_PROMO_END date in config
- [ ] Test LTD activation with test license key
- [ ] Verify unlimited quota for LTD users
- [ ] Prepare marketing copy for RocketHub listing
- [ ] Create demo video showing LTD activation

## 🔄 Future (Pro Plan)
- [ ] Google Sign-In integration
- [ ] Gumroad subscription verification
- [ ] Subscription management UI
- [ ] Daily subscription status check
- [ ] Upgrade flow from LTD to Pro
