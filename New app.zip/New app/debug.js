/**
 * Debug utilities for Smart Clipboard Chrome Extension
 * This script helps surface errors that might otherwise be hidden in the popup context
 */

// Initialize debug log buffer
let debugLogBuffer = [];
const MAX_LOG_ENTRIES = 50;

// Main debug log function - logs to console and stores in buffer
window.debugLog = function(data) {
  // Ensure data is an object with at least a message
  const entry = {
    timestamp: new Date().toISOString(),
    ...data
  };
  
  // Log to console
  console.log(`[DEBUG] ${entry.timestamp}:`, entry);
  
  // Add to buffer with rotation
  debugLogBuffer.push(entry);
  if (debugLogBuffer.length > MAX_LOG_ENTRIES) {
    debugLogBuffer.shift();
  }
  
  // Update debug panel if it exists
  updateDebugPanel();
  
  return entry;
};

// Function to show current logs in UI
function updateDebugPanel() {
  const debugPanel = document.getElementById('debugPanel');
  if (!debugPanel) return;
  
  // Clear existing content
  debugPanel.innerHTML = '';
  
  // Show newest logs first
  const logs = [...debugLogBuffer].reverse();
  
  logs.forEach(entry => {
    const logEntry = document.createElement('div');
    logEntry.className = `debug-entry ${entry.type || 'info'}`;
    
    const timestamp = document.createElement('span');
    timestamp.className = 'debug-time';
    timestamp.textContent = new Date(entry.timestamp).toLocaleTimeString();
    
    const message = document.createElement('span');
    message.className = 'debug-msg';
    message.textContent = entry.message || JSON.stringify(entry);
    
    const source = document.createElement('span');
    source.className = 'debug-source';
    source.textContent = entry.source || 'unknown';
    
    logEntry.appendChild(timestamp);
    logEntry.appendChild(source);
    logEntry.appendChild(message);
    debugPanel.appendChild(logEntry);
  });
}

// Initialize debug panel if requested
document.addEventListener('DOMContentLoaded', function() {
  // Check if debug panel is requested via URL param or localStorage
  const debugParam = new URLSearchParams(window.location.search).get('debug');
  const debugEnabled = debugParam === 'true' || localStorage.getItem('enableDebug') === 'true';
  
  if (debugEnabled) {
    createDebugPanel();
  }
  
  // Log initialization info
  window.debugLog({
    type: 'info',
    source: 'debug.js',
    message: `Debug utilities initialized. Debug panel: ${debugEnabled}`
  });
});

// Create debug panel in UI
function createDebugPanel() {
  if (document.getElementById('debugPanel')) return;
  
  const panel = document.createElement('div');
  panel.id = 'debugPanel';
  panel.className = 'debug-panel';
  panel.style.cssText = `
    position: fixed;
    bottom: 0;
    left: 0;
    right: 0;
    height: 200px;
    background: rgba(0,0,0,0.8);
    color: #eee;
    font-family: monospace;
    font-size: 12px;
    overflow-y: auto;
    z-index: 10000;
    padding: 10px;
    border-top: 2px solid #666;
  `;
  
  const header = document.createElement('div');
  header.innerHTML = '<b>Debug Log</b> <span id="clearDebug" style="cursor:pointer;float:right;color:#f99;">Clear</span>';
  panel.appendChild(header);
  
  document.body.appendChild(panel);
  
  document.getElementById('clearDebug').addEventListener('click', function() {
    debugLogBuffer = [];
    updateDebugPanel();
  });
  
  updateDebugPanel();
}

// Export logs function
window.exportDebugLogs = function() {
  const logs = JSON.stringify(debugLogBuffer, null, 2);
  const blob = new Blob([logs], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  
  const a = document.createElement('a');
  a.href = url;
  a.download = `smart-clipboard-debug-${new Date().toISOString().slice(0,10)}.json`;
  a.click();
  URL.revokeObjectURL(url);
};

// Log uncaught errors (filter out ResizeObserver noise)
window.addEventListener('error', function(event) {
  // Ignore ResizeObserver errors - they're harmless Chrome extension noise
  if (event.message && event.message.includes('ResizeObserver')) {
    return;
  }
  
  window.debugLog({
    type: 'error',
    source: event.filename || 'unknown',
    message: event.message,
    lineno: event.lineno,
    colno: event.colno
  });
});

// Log unhandled promise rejections
window.addEventListener('unhandledrejection', function(event) {
  window.debugLog({
    type: 'promise_error',
    source: 'promise',
    message: event.reason ? (event.reason.message || String(event.reason)) : 'Unknown promise error'
  });
});

// Provide a function to toggle debug mode
window.toggleDebugMode = function() {
  const current = localStorage.getItem('enableDebug') === 'true';
  localStorage.setItem('enableDebug', (!current).toString());
  alert(`Debug mode ${!current ? 'enabled' : 'disabled'}. Reload the page to apply.`);
};
