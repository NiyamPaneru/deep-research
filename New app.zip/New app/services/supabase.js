// Supabase service for Smart Clipboard AI
// Handles LTD license verification and Pro subscription management

const SUPABASE_URL = 'https://smartclipboard-ai.supabase.co';
const VERIFY_LTD_ENDPOINT = `${SUPABASE_URL}/functions/v1/verify_ltd`;

/**
 * Verify LTD license with Supabase Edge Function
 * @param {string} licenseKey - License key from RocketHub
 * @param {string} email - User email
 * @returns {Promise<{valid: boolean, plan?: string, message?: string}>}
 */
async function verifyLTD(licenseKey, email) {
  if (!licenseKey || !email) {
    return { valid: false, message: 'License key and email required' };
  }

  try {
    const response = await fetch(VERIFY_LTD_ENDPOINT, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        licenseKey: licenseKey.trim(),
        email: email.trim().toLowerCase()
      })
    });

    if (!response.ok) {
      if (response.status === 429) {
        return { valid: false, message: 'Too many requests. Please try again in a moment.' };
      }
      return { valid: false, message: `Verification failed (${response.status})` };
    }

    const data = await response.json();
    
    if (data.valid) {
      return {
        valid: true,
        plan: data.plan || 'LTD',
        message: data.message || 'License verified successfully'
      };
    }

    return {
      valid: false,
      message: data.message || 'Invalid license key or email'
    };

  } catch (error) {
    return {
      valid: false,
      message: 'Network error. Please check your connection and try again.'
    };
  }
}

/**
 * Stub for Pro subscription verification
 * @param {string} subscriptionId - Subscription ID
 * @returns {Promise<{valid: boolean, status?: string, message?: string}>}
 */
async function verifyPro(subscriptionId) {
  // Placeholder for Pro verification
  // Will be implemented when Pro subscriptions are ready
  return {
    valid: false,
    message: 'Pro subscriptions not yet available'
  };
}

export { verifyLTD, verifyPro };