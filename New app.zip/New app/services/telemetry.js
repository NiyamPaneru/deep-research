const TELEMETRY_ENDPOINT = 'https://api.example.com/telemetry';
const TELEMETRY_STORAGE_KEY = 'telemetryEnabled';

let telemetryOptIn = false;
let preferenceLoaded = false;

async function readPreference() {
  if (preferenceLoaded) {
    return telemetryOptIn;
  }

  if (typeof chrome !== 'undefined' && chrome.storage?.local) {
    try {
      const data = await chrome.storage.local.get([TELEMETRY_STORAGE_KEY]);
      telemetryOptIn = Boolean(data?.[TELEMETRY_STORAGE_KEY]);
    } catch (_error) {
      telemetryOptIn = false;
    }
  }

  preferenceLoaded = true;
  return telemetryOptIn;
}

function applyTelemetryPreference(flag) {
  telemetryOptIn = Boolean(flag);
  preferenceLoaded = true;
}

if (typeof chrome !== 'undefined' && chrome.storage?.onChanged?.addListener) {
  chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName === 'local' && Object.prototype.hasOwnProperty.call(changes, TELEMETRY_STORAGE_KEY)) {
      telemetryOptIn = Boolean(changes[TELEMETRY_STORAGE_KEY]?.newValue);
      preferenceLoaded = true;
    }
  });
}

async function sendTelemetry(event, payload = {}) {
  const enabled = await readPreference();
  if (!enabled) {
    return;
  }

  try {
    await fetch(TELEMETRY_ENDPOINT, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        event,
        status: payload.status || null,
        code: payload.code || null,
        ts: Date.now()
      })
    });
  } catch (_error) {
    // Best-effort only.
  }
}

const telemetry = {
  send: sendTelemetry,
  setOptIn: applyTelemetryPreference,
  refreshPreference: () => readPreference().catch(() => {})
};

if (typeof globalThis !== 'undefined') {
  globalThis.telemetry = telemetry;
}

export { telemetry };
export default telemetry;
