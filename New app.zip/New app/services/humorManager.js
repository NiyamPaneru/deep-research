import {
  DEFAULT_HUMOR_SETTINGS,
  getHumorPayload,
  loadHumorSettings,
  updateHumorSettings,
  subscribeToHumorSettings,
  resetHumorRuntime
} from '../src/humor/humorService.js';

async function isHumorEnabled() {
  const settings = await loadHumorSettings();
  return Boolean(settings.humorEnabled);
}

function sanitizeCategory(category) {
  return typeof category === 'string' && category.trim() ? category.trim() : 'general';
}

async function fetchJoke(category, options = {}) {
  const payload = await getHumorPayload({ category: sanitizeCategory(category), force: Boolean(options.force) });
  if (!payload?.show) {
    return null;
  }
  return payload.joke ?? null;
}

async function setHumorEnabled(enabled) {
  const settings = await loadHumorSettings();
  return updateHumorSettings({
    ...settings,
    humorEnabled: Boolean(enabled)
  });
}

async function setHumorTone(tone) {
  const settings = await loadHumorSettings();
  return updateHumorSettings({
    ...settings,
    tone
  });
}

async function setRotationInterval(seconds) {
  const settings = await loadHumorSettings();
  return updateHumorSettings({
    ...settings,
    rotationInterval: seconds
  });
}

const humorManager = {
  DEFAULT_HUMOR_SETTINGS,
  loadSettings: loadHumorSettings,
  updateSettings: updateHumorSettings,
  enable: () => setHumorEnabled(true),
  disable: () => setHumorEnabled(false),
  setTone: setHumorTone,
  setRotationInterval,
  isEnabled: isHumorEnabled,
  getJoke: fetchJoke,
  subscribe: subscribeToHumorSettings,
  resetRuntime: resetHumorRuntime
};

if (typeof globalThis !== 'undefined') {
  globalThis.humorManager = humorManager;
}

export default humorManager;