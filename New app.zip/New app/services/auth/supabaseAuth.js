// GPT-5 Refactor: Supabase Auth placeholder for Google sign-in.
import { debugLog } from '../../utils/debug.js';

class SupabaseAuth {
  constructor() {
    this.user = null;
  }

  async signInWithGoogle() {
    debugLog('auth.signInWithGoogle.start');
    // TODO: implement Supabase Auth client flow in future iteration.
    throw new Error('Google Sign-In not implemented in offline mode.');
  }

  async signOut() {
    this.user = null;
    debugLog('auth.signOut');
  }

  getUser() {
    return this.user;
  }
}

export default new SupabaseAuth();
