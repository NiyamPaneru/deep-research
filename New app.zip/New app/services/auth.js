/**
 * Authentication and subscription service for Smart Clipboard AI
 */

const localStore = (() => {
  try {
    return typeof localStorage !== 'undefined' ? localStorage : null;
  } catch (_error) {
    return null;
  }
})();

class AuthService {
  constructor() {
    this.currentUser = null;
    this.authListeners = [];
    this.stripeBaseUrl = 'https://smartclipboard.ai';
    this.sessionToken = null;
  }

  /**
   * Initialize auth service and try auto-login
   */
  async initialize() {
    try {
      await this.checkAuthState();
    } catch (error) {
      console.warn('Auth initialization error:', error);
    }
  }

  /**
   * Sign in via Google OAuth or email/password
   * @returns {Promise<Object>} User object
   */
  async signIn() {
    try {
      // For demo: Create fake auth session
      const user = {
        id: 'user_' + Math.random().toString(36).substring(2, 10),
        email: 'user@example.com',
        name: 'Demo User',
        photoUrl: null,
        createdAt: new Date().toISOString()
      };

      // Store user data
      await this._storeUserData(user);

      // Trigger auth state change
      this._notifyListeners('signin', user);
      return { user };
    } catch (error) {
      console.error('Sign in error:', error);
      throw error;
    }
  }

  /**
   * Sign out current user
   */
  async signOut() {
    try {
      // Clear user data from storage
      await chrome.storage.local.remove([
        'authUser',
        'userSubscription'
      ]);

      if (chrome.storage?.session) {
        await chrome.storage.session.remove(['authToken']);
      }

  localStore?.removeItem('userTier');
  localStore?.removeItem('authUser');
  localStore?.removeItem('authToken');
      this.currentUser = null;
      this.sessionToken = null;
      
      // Trigger auth state change
      this._notifyListeners('signout');
      return { success: true };
    } catch (error) {
      console.error('Sign out error:', error);
      throw error;
    }
  }

  /**
   * Check if user is authenticated
   * @returns {Promise<boolean>}
   */
  async isAuthenticated() {
    try {
      const user = await this.getCurrentUser();
      return !!user;
    } catch (error) {
      return false;
    }
  }

  /**
   * Get current authenticated user
   * @returns {Promise<Object|null>} User object or null if not authenticated
   */
  async getCurrentUser() {
    try {
      if (this.currentUser) return this.currentUser;
      
      // Try to get from chrome storage first
      if (chrome?.storage?.local) {
        const data = await chrome.storage.local.get(['authUser']);
        if (data.authUser) {
          this.currentUser = data.authUser;
          return this.currentUser;
        }
      }
      
      // Fallback to localStorage
      const storedUser = localStore?.getItem('authUser');
      if (storedUser) {
        this.currentUser = JSON.parse(storedUser);
        return this.currentUser;
      }
      
      return null;
    } catch (error) {
      console.error('Error getting current user:', error);
      return null;
    }
  }

  /**
   * Get current user's authentication token
   * @returns {Promise<string|null>} Auth token or null
   */
  async getAuthToken() {
    try {
      if (this.sessionToken) {
        return this.sessionToken;
      }

      if (chrome.storage?.session) {
        const data = await chrome.storage.session.get(['authToken']);
        const token = data?.authToken || null;
        this.sessionToken = token;
        return token;
      }

      return null;
    } catch (error) {
      console.error('Error getting auth token:', error);
      return null;
    }
  }

  /**
   * Get current user's subscription info
   * @returns {Promise<Object>} Subscription object
   */
  async getUserSubscription() {
    try {
      // Check if user is authenticated
      const user = await this.getCurrentUser();
      if (!user) {
        return { tier: 'free', isActive: false };
      }
      
      // Try to get from chrome storage
      if (chrome?.storage?.local) {
        const data = await chrome.storage.local.get(['userSubscription']);
        if (data.userSubscription) {
          return data.userSubscription;
        }
      }
      
      // Fallback to localStorage tier
      const tier = localStore?.getItem('userTier') || 'free';
      return {
        tier,
        isActive: tier !== 'free',
        updatedAt: new Date().toISOString()
      };
    } catch (error) {
      console.error('Error getting user subscription:', error);
      return { tier: 'free', isActive: false };
    }
  }

  /**
   * Start Stripe checkout flow for subscription
   * @param {string} tier - Tier to subscribe to (pro, business, enterprise)
   * @returns {Promise<void>}
   */
  async startSubscription(tier) {
    try {
      const user = await this.getCurrentUser();
      if (!user) throw new Error('User must be logged in to subscribe');
      
      // Construct checkout URL (in production, generate server-side)
      const params = new URLSearchParams({
        tier: tier,
        userId: user.id,
        email: user.email,
        returnUrl: chrome.runtime.getURL('stripe-callback.html')
      });
      
      // Open checkout in new tab
      await chrome.tabs.create({
        url: `${this.stripeBaseUrl}/checkout?${params.toString()}`
      });
      
      return { success: true };
    } catch (error) {
      console.error('Start subscription error:', error);
      throw error;
    }
  }

  /**
   * Process subscription webhook data
   * @param {Object} data - Webhook data from Stripe
   * @returns {Promise<Object>} Updated subscription
   */
  async processSubscriptionWebhook(data) {
    try {
      // Validate the webhook data
      if (!data || !data.userId || !data.tier) {
        throw new Error('Invalid subscription data');
      }
      
      const subscription = {
        tier: data.tier,
        isActive: true,
        customerId: data.customerId || null,
        subscriptionId: data.subscriptionId || null,
        startDate: data.startDate || new Date().toISOString(),
        endDate: data.endDate || null,
        updatedAt: new Date().toISOString()
      };
      
      // Store subscription data
      await this._storeSubscription(subscription);
      
      // Update localStorage tier for compatibility
      localStore?.setItem('userTier', data.tier);
      
      // Notify listeners
      this._notifyListeners('subscription_updated', subscription);
      
      return subscription;
    } catch (error) {
      console.error('Process subscription error:', error);
      throw error;
    }
  }

  /**
   * Cancel current subscription
   * @returns {Promise<Object>} Updated subscription
   */
  async cancelSubscription() {
    try {
      const user = await this.getCurrentUser();
      if (!user) throw new Error('User must be logged in');
      
      // In a real implementation, call your backend to cancel with Stripe
      
      // For demo, just update local storage
      const subscription = {
        tier: 'free',
        isActive: false,
        updatedAt: new Date().toISOString()
      };
      
      // Store subscription data
      await this._storeSubscription(subscription);
      
      // Update localStorage tier for compatibility
      localStore?.setItem('userTier', 'free');
      
      // Notify listeners
      this._notifyListeners('subscription_updated', subscription);
      
      return subscription;
    } catch (error) {
      console.error('Cancel subscription error:', error);
      throw error;
    }
  }

  /**
   * Add listener for auth state changes
   * @param {Function} callback - Function to call on state change
   */
  onAuthStateChanged(callback) {
    if (typeof callback === 'function') {
      this.authListeners.push(callback);
    }
  }

  /**
   * Remove auth state change listener
   * @param {Function} callback - Function to remove
   */
  removeAuthStateListener(callback) {
    const index = this.authListeners.indexOf(callback);
    if (index !== -1) {
      this.authListeners.splice(index, 1);
    }
  }

  /**
   * Check current auth state and notify listeners
   * @returns {Promise<Object|null>} Current user or null
   */
  async checkAuthState() {
    try {
      const user = await this.getCurrentUser();
      if (user) {
        this._notifyListeners('auth_state_changed', user);
      }
      return user;
    } catch (error) {
      console.error('Check auth state error:', error);
      return null;
    }
  }

  /**
   * Sync usage data between devices for authenticated users
   * @param {string} tierKey - User tier key
   * @param {Object} usage - Usage data to sync
   * @returns {Promise<boolean>} Success status
   */
  async syncUsageData(tierKey, usage) {
    try {
      const user = await this.getCurrentUser();
      if (!user) return false;
      
      // Store usage data in user-specific key
      if (chrome?.storage?.sync) {
        const key = `usage_${user.id}_${tierKey}`;
        await chrome.storage.sync.set({ [key]: usage });
        return true;
      }
      return false;
    } catch (error) {
      console.error('Sync usage error:', error);
      return false;
    }
  }

  /**
   * Get usage data for authenticated user
   * @param {string} tierKey - User tier key
   * @returns {Promise<Object|null>} Usage data or null
   */
  async getUserUsage(tierKey) {
    try {
      const user = await this.getCurrentUser();
      if (!user) return null;
      
      // Get usage data from user-specific key
      if (chrome?.storage?.sync) {
        const key = `usage_${user.id}_${tierKey}`;
        const data = await chrome.storage.sync.get([key]);
        return data[key] || null;
      }
      return null;
    } catch (error) {
      console.error('Get user usage error:', error);
      return null;
    }
  }

  // Private methods
  async _storeUserData(user) {
    // Generate demo token
    const token = 'auth_' + Math.random().toString(36).substring(2);
    
    // Store in chrome storage
    if (chrome?.storage?.local) {
      await chrome.storage.local.set({
        authUser: user
      });
    }
    
    if (chrome.storage?.session) {
      await chrome.storage.session.set({ authToken: token });
    }

    // Fallback to localStorage
    localStore?.setItem('authUser', JSON.stringify(user));
    this.sessionToken = token;
    this.currentUser = user;
  }
  
  async _storeSubscription(subscription) {
    // Store in chrome storage
    if (chrome?.storage?.local) {
      await chrome.storage.local.set({ userSubscription: subscription });
    }
    
    // Fallback to localStorage for tier only
    localStore?.setItem('userTier', subscription.tier);
  }
  
  _notifyListeners(event, data = null) {
    this.authListeners.forEach(callback => {
      try {
        callback(event, data);
      } catch (error) {
        console.error('Auth listener error:', error);
      }
    });
  }
}

// Create singleton instance
const authService = new AuthService();

const globalTarget = typeof self !== 'undefined'
  ? self
  : typeof window !== 'undefined'
    ? window
    : typeof globalThis !== 'undefined'
      ? globalThis
      : null;

if (globalTarget) {
  globalTarget.AuthService = authService;
  globalTarget.authService = authService;
}

// Initialize when DOM is available; service workers will call lazily via background
if (typeof window !== 'undefined' && window?.addEventListener) {
  window.addEventListener('DOMContentLoaded', () => {
    authService.initialize().catch(console.error);
  });
}
