// GPT-5 Refactor: Gumroad license verification service

const GUMROAD_PRODUCT_PERMALINK = 'smart-clipboard-pro'; // Replace with your actual product permalink

/**
 * Verify a Gumroad license key
 * @param {string} licenseKey - The Gumroad license key to verify
 * @returns {Promise<Object>} Verification result
 */
async function verifyGumroadLicense(licenseKey) {
  try {
    const params = new URLSearchParams({
      product_permalink: GUMROAD_PRODUCT_PERMALINK,
      license_key: licenseKey
    });
    
    const response = await fetch(
      `https://api.gumroad.com/v2/licenses/verify?${params.toString()}`,
      { method: 'GET' }
    );
    
    const result = await response.json();
    
    if (!result.success) {
      return { 
        valid: false, 
        error: 'Invalid license key. Check your Gumroad purchase email.' 
      };
    }
    
    const purchase = result.purchase;
    
    // Check if refunded or chargebacked
    if (purchase.refunded || purchase.chargebacked) {
      return { 
        valid: false, 
        error: 'This license has been refunded or disputed.' 
      };
    }
    
    // Check if subscription cancelled
    const cancelled = purchase.subscription_cancelled_at !== null;
    const accessEnded = cancelled && 
      new Date(purchase.subscription_failed_at || purchase.subscription_cancelled_at) < new Date();
    
    return {
      valid: true,
      email: purchase.email,
      subscription_id: purchase.subscription_id,
      cancelled: cancelled,
      access_ended: accessEnded,
      purchase_date: purchase.created_at
    };
    
  } catch (error) {
    return { 
      valid: false, 
      error: 'Network error. Please check your connection and try again.' 
    };
  }
}

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
  module.exports = { verifyGumroadLicense };
}

if (typeof globalThis !== 'undefined') {
  globalThis.verifyGumroadLicense = verifyGumroadLicense;
}

export { verifyGumroadLicense };
