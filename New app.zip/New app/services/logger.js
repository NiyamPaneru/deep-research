const DEBUG_ENV_FLAG = 'DEBUG';

function isDebugEnabled() {
  const scope = typeof globalThis !== 'undefined' ? globalThis : {};
  const env = scope.ENV || {};
  if (typeof env[DEBUG_ENV_FLAG] === 'string') {
    return env[DEBUG_ENV_FLAG].toLowerCase() === 'true';
  }
  const proc = scope.process;
  return Boolean(proc?.env?.[DEBUG_ENV_FLAG] && proc.env[DEBUG_ENV_FLAG] === 'true');
}

function scrub(value) {
  if (typeof value === 'string' && value.toLowerCase().includes('hf_')) {
    return '[REDACTED_TOKEN]';
  }
  return value;
}

const logger = {
  debug: (...args) => {
    if (!isDebugEnabled()) {
      return;
    }
    const scrubbed = args.map(scrub);
    if (typeof console !== 'undefined' && console.debug) {
      console.debug('[SmartClipboard]', ...scrubbed);
    }
  }
};

if (typeof globalThis !== 'undefined') {
  globalThis.logger = logger;
}

export { logger };
export default logger;
