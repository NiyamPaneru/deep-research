// GPT-5 Refactor: Tier utilities for quota and model selection.
import { getTierPolicies } from '../../config.js';
import { debugLog } from '../../utils/debug.js';
import storageHelper from '../../storageHelper.js';
import quotaHelper from '../../quotaHelper.js';

const TIER_KEY = 'userTier';
const TIER_MODELS = {
  free: 'gpt2',
  ltd: 'tiiuae/falcon-7b-instruct',
  pro: 'tiiuae/falcon-7b-instruct'
};

async function getCurrentTier() {
  try {
    const result = await chrome.storage.local.get([TIER_KEY]);
    const tier = result[TIER_KEY] || 'free';
    return tier;
  } catch (error) {
    debugLog('tier.getCurrentTierFailed', error?.message || error);
    return 'free';
  }
}

async function setCurrentTier(tier) {
  try {
    await chrome.storage.local.set({ [TIER_KEY]: tier });
  } catch (error) {
    debugLog('tier.setCurrentTierFailed', error?.message || error);
  }
}

function getModelForTier(tier) {
  return TIER_MODELS[tier] || TIER_MODELS.free;
}

async function enforceQuota(tierKey) {
  const policies = getTierPolicies();
  const tierPolicy = policies[tierKey] || policies.free;

  if (tierPolicy?.quota?.max === -1) {
    return { ok: true, remaining: Infinity };
  }

  const deviceId = await storageHelper.getOrCreateDeviceId();
  const amount = 1;
  const result = await quotaHelper.checkAndIncrementQuota(tierKey, deviceId, amount);
  return result;
}

async function rollbackQuota(tierKey) {
  const policies = getTierPolicies();
  const tierPolicy = policies[tierKey] || policies.free;
  if (tierPolicy?.quota?.max === -1) {
    return;
  }
  const deviceId = await storageHelper.getOrCreateDeviceId();
  await quotaHelper.decrementQuota(tierKey, deviceId, 1);
}

export {
  getCurrentTier,
  setCurrentTier,
  getModelForTier,
  enforceQuota,
  rollbackQuota,
  TIER_MODELS
};
