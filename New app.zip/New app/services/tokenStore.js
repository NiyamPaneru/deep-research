import logger from './logger.js';
import telemetry from './telemetry.js';
import hfClient from './hfClient.js';

const STORE_KEY = 'hf_token_encrypted_v1';
const SECRET_KEY = 'hf_token_secret_v1';

const memoryStore = new Map();

function getStorageArea() {
  if (typeof chrome !== 'undefined' && chrome.storage?.local) {
    return chrome.storage.local;
  }
  return null;
}

function getNodeCrypto() {
  if (typeof require === 'function') {
    try {
      // eslint-disable-next-line global-require
      return require('crypto');
    } catch (_error) {
      return null;
    }
  }
  return null;
}

function getNodeUtil() {
  if (typeof require === 'function') {
    try {
      // eslint-disable-next-line global-require
      return require('util');
    } catch (_error) {
      return null;
    }
  }
  return null;
}

function toUint8Array(buffer) {
  if (buffer instanceof Uint8Array) {
    return buffer;
  }
  return new Uint8Array(buffer);
}

function toBase64(bytes) {
  if (typeof btoa === 'function') {
    let binary = '';
    const arr = toUint8Array(bytes);
    for (let i = 0; i < arr.length; i += 1) {
      binary += String.fromCharCode(arr[i]);
    }
    return btoa(binary);
  }
  return Buffer.from(bytes).toString('base64');
}

function fromBase64(value) {
  if (!value) {
    return new Uint8Array();
  }
  if (typeof atob === 'function') {
    const binary = atob(value);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i += 1) {
      bytes[i] = binary.charCodeAt(i);
    }
    return bytes;
  }
  return new Uint8Array(Buffer.from(value, 'base64'));
}

function getCrypto() {
  if (typeof crypto !== 'undefined' && crypto.subtle) {
    return crypto;
  }
  const nodeCrypto = getNodeCrypto();
  if (nodeCrypto?.webcrypto?.subtle) {
    return nodeCrypto.webcrypto;
  }
  throw new Error('CRYPTO_UNAVAILABLE');
}

function createTextEncoder() {
  if (typeof TextEncoder !== 'undefined') {
    return new TextEncoder();
  }
  const util = getNodeUtil();
  if (util?.TextEncoder) {
    return new util.TextEncoder();
  }
  throw new Error('TEXT_ENCODER_UNAVAILABLE');
}

function createTextDecoder() {
  if (typeof TextDecoder !== 'undefined') {
    return new TextDecoder();
  }
  const util = getNodeUtil();
  if (util?.TextDecoder) {
    return new util.TextDecoder();
  }
  throw new Error('TEXT_DECODER_UNAVAILABLE');
}

async function storageGet(keys) {
  const area = getStorageArea();
  if (!area) {
    if (Array.isArray(keys)) {
      return keys.reduce((acc, key) => {
        acc[key] = memoryStore.get(key);
        return acc;
      }, {});
    }
    if (typeof keys === 'string') {
      return { [keys]: memoryStore.get(keys) };
    }
    if (keys && typeof keys === 'object') {
      return Object.keys(keys).reduce((acc, key) => {
        acc[key] = memoryStore.get(key) ?? keys[key];
        return acc;
      }, {});
    }
    return {};
  }

  const result = area.get(keys);
  if (result && typeof result.then === 'function') {
    return result;
  }

  return new Promise((resolve, reject) => {
    area.get(keys, (items) => {
      if (chrome?.runtime?.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
        return;
      }
      resolve(items || {});
    });
  });
}

async function storageSet(items) {
  if (!items || typeof items !== 'object') {
    return;
  }

  const area = getStorageArea();
  if (!area) {
    Object.entries(items).forEach(([key, value]) => {
      memoryStore.set(key, value);
    });
    return;
  }

  const result = area.set(items);
  if (result && typeof result.then === 'function') {
    await result;
    return;
  }

  await new Promise((resolve, reject) => {
    area.set(items, () => {
      if (chrome?.runtime?.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
        return;
      }
      resolve();
    });
  });
}

async function storageRemove(keys) {
  const area = getStorageArea();
  if (!area) {
    if (Array.isArray(keys)) {
      keys.forEach((key) => memoryStore.delete(key));
    } else {
      memoryStore.delete(keys);
    }
    return;
  }

  const result = area.remove(keys);
  if (result && typeof result.then === 'function') {
    await result;
    return;
  }

  await new Promise((resolve, reject) => {
    area.remove(keys, () => {
      if (chrome?.runtime?.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
        return;
      }
      resolve();
    });
  });
}

async function getSecretMaterial() {
  const cached = await storageGet([SECRET_KEY]);
  const stored = cached?.[SECRET_KEY];
  if (stored && typeof stored === 'string') {
    return fromBase64(stored);
  }

  const cryptoApi = getCrypto();
  const secret = new Uint8Array(32);
  cryptoApi.getRandomValues(secret);
  await storageSet({ [SECRET_KEY]: toBase64(secret) });
  return secret;
}

async function getCryptoKey() {
  const cryptoApi = getCrypto();
  const material = await getSecretMaterial();
  return cryptoApi.subtle.importKey('raw', material, { name: 'AES-GCM' }, false, ['encrypt', 'decrypt']);
}

async function encryptToken(token) {
  const cryptoApi = getCrypto();
  const key = await getCryptoKey();
  const iv = new Uint8Array(12);
  cryptoApi.getRandomValues(iv);
  const encoder = createTextEncoder();
  const cipherBuffer = await cryptoApi.subtle.encrypt({ name: 'AES-GCM', iv }, key, encoder.encode(token));
  return {
    iv: toBase64(iv),
    data: toBase64(toUint8Array(cipherBuffer))
  };
}

async function decryptToken(payload) {
  if (!payload || typeof payload !== 'object') {
    return null;
  }

  const { iv, data } = payload;
  if (!iv || !data) {
    return null;
  }

  try {
    const cryptoApi = getCrypto();
    const key = await getCryptoKey();
    const decrypted = await cryptoApi.subtle.decrypt({ name: 'AES-GCM', iv: fromBase64(iv) }, key, fromBase64(data));
    const decoder = createTextDecoder();
    return decoder.decode(decrypted);
  } catch (error) {
    logger.debug('tokenStore.decryptFailed', error?.message || error);
    return null;
  }
}

function mapError(code) {
  switch (code) {
    case 'HF_INVALID_TOKEN':
      return { code, message: 'Invalid Hugging Face token — update it in Settings.' };
    case 'HF_MODEL_NOT_FOUND':
      return { code, message: 'Model not found — try "gpt2" or verify the model name.' };
    case 'HF_EMPTY_RESPONSE':
      return { code, message: 'Model returned no output — try again or switch models.' };
    case 'HF_SERVER_ERROR':
      return { code, message: 'Temporary server issue — try again shortly.' };
    case 'HF_NETWORK_ERROR':
    default:
      return { code: code || 'HF_NETWORK_ERROR', message: 'Network error — retry once your connection is stable.' };
  }
}

function emitTelemetry(event, payload) {
  try {
    telemetry.send(event, payload);
  } catch (_error) {
    // best effort
  }
}

async function setToken(token) {
  if (!token) {
    await clearToken();
    emitTelemetry('token_test_cleared', {});
    return { ok: true, message: 'Token cleared.' };
  }

  if (!hfClient?.generate) {
    throw new Error('HF_CLIENT_UNAVAILABLE');
  }

  try {
    const validation = await hfClient.generate('gpt2', token, 'Test', {
      parameters: {
        max_new_tokens: 1,
        return_full_text: false
      }
    });
    logger.debug('tokenStore.validationStatus', validation.status);
    emitTelemetry('token_test_success', { status: validation.status });
  } catch (error) {
    const mapped = mapError(error?.code || error?.message || 'HF_NETWORK_ERROR');
    logger.debug('tokenStore.validationFailed', mapped.code);
    emitTelemetry('token_test_fail', { code: mapped.code });
    return { ok: false, code: mapped.code, message: mapped.message };
  }

  try {
    const encrypted = await encryptToken(token);
    await storageSet({ [STORE_KEY]: encrypted });
    return { ok: true, message: 'Token saved securely.' };
  } catch (error) {
    logger.debug('tokenStore.storeFailed', error?.message || error);
    return { ok: false, code: 'TOKEN_STORE_FAILED', message: 'Unable to store the token on this device.' };
  }
}

async function getToken() {
  try {
    const stored = await storageGet([STORE_KEY]);
    return await decryptToken(stored?.[STORE_KEY]);
  } catch (error) {
    logger.debug('tokenStore.readFailed', error?.message || error);
    return null;
  }
}

async function clearToken() {
  await storageRemove([STORE_KEY]);
}

const tokenStore = {
  setToken,
  getToken,
  clearToken
};

if (typeof globalThis !== 'undefined') {
  globalThis.tokenStore = tokenStore;
  globalThis.tokenStorage = tokenStore;
}

export { tokenStore };
export default tokenStore;
