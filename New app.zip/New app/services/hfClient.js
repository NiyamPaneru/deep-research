// GPT-5 Refactor: Model client with tier-aware fallback and debug logging.
import logger from './logger.js';
import telemetry from './telemetry.js';
import { getModelForTier } from './tiers/index.js';
import { debugLog } from '../utils/debug.js';
import { getCurrentTier, enforceQuota, rollbackQuota } from './tiers/index.js';

const MAX_ATTEMPTS = 4; // initial request + up to three retries
const RETRY_BASE_MS = 400;
const RETRY_CAP_MS = 4000;
const REQUEST_TIMEOUT_MS = 20000;

function createError(code, status, friendlyMessage) {
  const error = new Error(code);
  error.code = code;
  error.status = typeof status === 'number' ? status : null;
  if (friendlyMessage) {
    error.friendlyMessage = friendlyMessage;
  }
  return error;
}

  function wait(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  function backoffDelay(attempt) {
    const exponential = Math.min(RETRY_BASE_MS * Math.pow(2, attempt), RETRY_CAP_MS);
    const jitter = Math.random() * 150;
    return exponential + jitter;
  }

  function buildBody(input, opts) {
    const payload = {
      inputs: input,
      options: Object.assign({ wait_for_model: true }, opts?.options || {})
    };
    if (opts?.parameters) {
      payload.parameters = opts.parameters;
    }
    if (opts?.body && typeof opts.body === 'object') {
      Object.assign(payload, opts.body);
    }
    return JSON.stringify(payload);
  }

async function fetchWithTimeout(endpoint, options) {
  const scopedFetch = typeof fetch === 'function' ? fetch : globalThis?.fetch;
  if (typeof AbortController !== 'function' || !scopedFetch) {
    return scopedFetch(endpoint, options);
  }
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);
  try {
    return await scopedFetch(endpoint, Object.assign({}, options, { signal: controller.signal }));
  } catch (error) {
    if (error?.name === 'AbortError') {
      throw createError('HF_TIMEOUT', null, 'The request to Hugging Face timed out. Try again in a few seconds.');
    }
    throw error;
  } finally {
    clearTimeout(timer);
  }
}

  function parseJsonSafely(text) {
    if (!text) return null;
    try {
      return JSON.parse(text);
    } catch (_error) {
      return null;
    }
  }

  function normalizePayload(data, status) {
    if (data == null) {
      throw createError('HF_EMPTY_RESPONSE', status, 'The model did not return any content. Try again.');
    }

    if (Array.isArray(data)) {
      if (!data.length) {
        throw createError('HF_EMPTY_RESPONSE', status, 'The model did not return any content. Try again.');
      }

      if (data.length === 1 && data[0] && typeof data[0].error === 'string') {
        const lowered = data[0].error.toLowerCase();
        if (lowered.includes('rate limit')) {
          throw createError('HF_RATE_LIMITED', status, 'You hit the Hugging Face rate limit. Wait a few seconds and try again.');
        }
        if (lowered.includes('loading') || lowered.includes('currently unavailable')) {
          throw createError('HF_SERVER_ERROR', status, 'The model is warming up. Try again in a moment.');
        }
        throw createError('HF_SERVER_ERROR', status, data[0].error);
      }

      return data;
    }

    if (typeof data === 'object') {
      if (Array.isArray(data.outputs) && data.outputs.length) {
        return data.outputs;
      }
      if (typeof data.generated_text === 'string' && data.generated_text.trim()) {
        return [data.generated_text];
      }
      if (typeof data.output_text === 'string' && data.output_text.trim()) {
        return [data.output_text];
      }
      if (typeof data.error === 'string' && data.error.trim()) {
        const lowered = data.error.toLowerCase();
        if (lowered.includes('rate limit')) {
          throw createError('HF_RATE_LIMITED', status, 'You hit the Hugging Face rate limit. Wait a few seconds and try again.');
        }
        if (lowered.includes('loading') || lowered.includes('currently unavailable')) {
          throw createError('HF_SERVER_ERROR', status, 'The model is warming up. Try again in a moment.');
        }
        throw createError('HF_SERVER_ERROR', status, data.error);
      }
    }

    throw createError('HF_EMPTY_RESPONSE', status, 'The model did not return any content. Try again.');
  }

function normalizeError(error) {
  if (!error) {
    return createError('HF_UNKNOWN_ERROR', null, 'An unknown error occurred. Try again.');
  }

  if (error.code && error.message === error.code) {
    return error;
  }

  if (error.code) {
    return error;
  }

  if (error.name === 'TypeError' || error.message === 'Failed to fetch') {
    return createError('HF_NETWORK_ERROR', error.status, 'Network error contacting Hugging Face. Check your connection and retry.');
  }

  return createError('HF_UNKNOWN_ERROR', error.status, 'An unknown error occurred. Try again.');
}

function shouldRetry(error, attempt) {
  const retriableCodes = new Set(['HF_SERVER_ERROR', 'HF_NETWORK_ERROR', 'HF_RATE_LIMITED', 'HF_TIMEOUT']);
  return retriableCodes.has(error.code) && attempt < MAX_ATTEMPTS - 1;
}

function recordTelemetry(ok, status, code) {
  try {
    telemetry.send('model_call_status', { ok, status: status ?? null, code: code ?? null });
  } catch (_error) {
    // ignore telemetry failures
  }
}

async function generate(requestedModel, token, input, opts = {}) {
  const tier = await getCurrentTier();
  const modelName = requestedModel || getModelForTier(tier);

  if (!modelName || typeof modelName !== 'string') {
    throw createError('HF_MODEL_REQUIRED', null, 'A Hugging Face model name is required.');
  }
  if (!token || typeof token !== 'string') {
    throw createError('HF_TOKEN_REQUIRED', null, 'Add your Hugging Face token to continue.');
  }

  const quotaResult = await enforceQuota(tier);
  if (!quotaResult.ok) {
    return {
      ok: false,
      error: createError('HF_QUOTA_EXCEEDED', null, 'Your plan quota is exhausted. Try again later.'),
      remaining: quotaResult.remaining
    };
  }

  const endpoint = `https://api-inference.huggingface.co/models/${encodeURIComponent(modelName)}`;
  const headers = {
    Authorization: `Bearer ${token}`,
    'Content-Type': 'application/json'
  };
  const body = buildBody(input, opts);

  let lastError = null;

  for (let attempt = 0; attempt < MAX_ATTEMPTS; attempt += 1) {
    try {
      const response = await fetchWithTimeout(endpoint, {
        method: 'POST',
        headers,
        body
      });
      const { status } = response;

  debugLog('hfClient.generate', { modelName, status, attempt });

      if (status === 401) throw createError('HF_INVALID_TOKEN', status, 'Invalid Hugging Face token. Update it in Settings.');
      if (status === 404) throw createError('HF_MODEL_NOT_FOUND', status, 'The selected model was not found. Try "gpt2".');
      if (status === 429) throw createError('HF_RATE_LIMITED', status, 'You hit the the rate limit. Wait a few seconds and try again.');
      if (status === 408) throw createError('HF_TIMEOUT', status, 'The request to Hugging Face timed out. Try again.');
      if (status === 204) throw createError('HF_EMPTY_RESPONSE', status, 'The model did not return any content. Try again.');
      if (status >= 500) throw createError('HF_SERVER_ERROR', status, 'Hugging Face servers are busy. Try again shortly.');

      const rawText = await response.text();
      const data = parseJsonSafely(rawText);
      const normalized = normalizePayload(data, status);

      recordTelemetry(true, status, null);
      return { ok: true, status, data: normalized, remaining: quotaResult.remaining };
    } catch (error) {
      const normalized = normalizeError(error);
      lastError = normalized;

      if (shouldRetry(normalized, attempt)) {
        await wait(backoffDelay(attempt));
        continue;
      }

      recordTelemetry(false, normalized.status, normalized.code);
      await rollbackQuota(tier);
      throw normalized;
    }
  }

  if (lastError) {
    recordTelemetry(false, lastError.status, lastError.code);
    await rollbackQuota(tier);
    throw lastError;
  }

  const fallbackError = createError('HF_SERVER_ERROR', null, 'Hugging Face servers are busy. Try again shortly.');
  recordTelemetry(false, fallbackError.status, fallbackError.code);
  await rollbackQuota(tier);
  throw fallbackError;
}

const hfClient = {
  generate
};

if (typeof globalThis !== 'undefined') {
  globalThis.hfClient = hfClient;
}

export { hfClient };
export default hfClient;
