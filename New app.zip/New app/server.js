const http = require('http');
const fs = require('fs');
const path = require('path');
const url = require('url');

// Security: Sanitize file paths to prevent directory traversal
function sanitizePath(filePath) {
  const normalized = path.normalize(filePath);
  const resolved = path.resolve(__dirname, normalized);
  const basePath = path.resolve(__dirname);
  
  // Ensure the resolved path is within the base directory
  if (!resolved.startsWith(basePath)) {
    throw new Error('Path traversal attempt detected');
  }
  
  return resolved;
}

const PORT = 54321;

const mimeTypes = {
  '.html': 'text/html',
  '.js': 'text/javascript',
  '.css': 'text/css',
  '.json': 'application/json',
  '.png': 'image/png',
  '.jpg': 'image/jpg',
  '.gif': 'image/gif',
  '.svg': 'image/svg+xml',
  '.wav': 'audio/wav',
  '.mp4': 'video/mp4',
  '.woff': 'application/font-woff',
  '.ttf': 'application/font-ttf',
  '.eot': 'application/vnd.ms-fontobject',
  '.otf': 'application/font-otf',
  '.wasm': 'application/wasm'
};

function serveFile(req, res, filePath) {
  const ext = path.parse(filePath).ext;
  const contentType = mimeTypes[ext] || 'text/plain';

  fs.readFile(filePath, (err, data) => {
    if (err) {
      res.writeHead(404, { 'Content-Type': 'text/plain' });
      res.end('File not found');
    } else {
      res.writeHead(200, { 
        'Content-Type': contentType,
        'Access-Control-Allow-Origin': 'http://localhost:54321',
        'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type, Authorization',
        'X-Content-Type-Options': 'nosniff',
        'X-Frame-Options': 'DENY'
      });
      res.end(data);
    }
  });
}

const server = http.createServer((req, res) => {
  const parsedUrl = url.parse(req.url);
  let pathname;
  try {
    pathname = sanitizePath(`.${parsedUrl.pathname}`);
  } catch (error) {
    res.writeHead(403, { 'Content-Type': 'text/plain' });
    res.end('Forbidden: Invalid path');
    return;
  }

  // Serve test harness as default
  if (pathname === path.resolve(__dirname, './')) {
    pathname = path.resolve(__dirname, './test-harness.html');
  }

  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    res.writeHead(200, {
      'Access-Control-Allow-Origin': 'http://localhost:54321',
      'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization'
    });
    res.end();
    return;
  }

  serveFile(req, res, pathname);
});

server.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}/`);
  console.log(`Test harness available at http://localhost:${PORT}/test-harness.html`);
});