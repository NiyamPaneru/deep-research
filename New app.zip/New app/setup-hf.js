'use strict';

(function initSetupPage(globalScope) {
  const logger = globalScope.logger || { debug() {} };

  document.addEventListener('DOMContentLoaded', () => {
    const dom = {
      status: document.getElementById('status'),
      testResult: document.getElementById('testResult'),
      saveBtn: document.getElementById('saveBtn'),
      clearBtn: document.getElementById('clearBtn'),
      testBtn: document.getElementById('testBtn'),
      tokenInput: document.getElementById('hfToken'),
      successBanner: document.getElementById('successBanner'),
      accordionToggle: document.getElementById('accordionToggle'),
      accordionBody: document.getElementById('troubleshooting-body')
    };

    if (!globalScope.tokenStorage || !globalScope.hfClient) {
      logger.debug('setup-hf missing dependencies', {
        tokenStorage: Boolean(globalScope.tokenStorage),
        hfClient: Boolean(globalScope.hfClient)
      });
      return;
    }

    dom.saveBtn?.addEventListener('click', () => validateAndSave(dom));
    dom.clearBtn?.addEventListener('click', () => clearToken(dom));
    dom.testBtn?.addEventListener('click', () => runTest(dom));
    dom.accordionToggle?.addEventListener('click', () => toggleAccordion(dom));

    preloadStatus(dom);
  });

  async function preloadStatus(dom) {
    try {
      const token = await globalScope.tokenStorage.getToken();
      if (token) {
  setStatus(dom.status, '✅ Token Valid — stored locally on this device.', 'success');
        showSuccess(dom.successBanner);
      }
    } catch (error) {
      logger.debug('preloadStatus failed', error?.message || error);
    }
  }

  async function validateAndSave(dom) {
    const token = dom.tokenInput?.value?.trim();
    if (!token) {
      setStatus(dom.status, '⚠️ Invalid Token — please paste your token first.', 'warning');
      dom.tokenInput?.focus();
      return;
    }

    dom.saveBtn.disabled = true;
    setStatus(dom.status, 'Validating with Hugging Face…', 'info');

    try {
      const result = await globalScope.tokenStorage.setToken(token);
      if (result?.ok) {
        dom.tokenInput.value = '';
  setStatus(dom.status, '✅ Token Valid — stored locally on this device.', 'success');
        showSuccess(dom.successBanner);
      } else {
        const message = mapTokenError(result?.code);
        setStatus(dom.status, message, 'error');
        hideSuccess(dom.successBanner);
      }
    } catch (error) {
      setStatus(dom.status, '❌ Network Error — try again shortly.', 'error');
      logger.debug('validateAndSave failed', error?.message || error);
      hideSuccess(dom.successBanner);
    } finally {
      dom.saveBtn.disabled = false;
    }
  }

  async function clearToken(dom) {
    dom.clearBtn.disabled = true;
    try {
      await globalScope.tokenStorage.clearToken();
      setStatus(dom.status, 'Token removed from this device.', 'info');
      hideSuccess(dom.successBanner);
    } catch (error) {
      setStatus(dom.status, 'Unable to clear the token. Try again.', 'error');
      logger.debug('clearToken failed', error?.message || error);
    } finally {
      dom.clearBtn.disabled = false;
    }
  }

  async function runTest(dom) {
    dom.testBtn.disabled = true;
    setStatus(dom.testResult, 'Running handshake test…', 'info');

    try {
      const token = await globalScope.tokenStorage.getToken();
      if (!token) {
        setStatus(dom.testResult, '⚠️ Invalid Token — save a token before testing.', 'warning');
        dom.tokenInput?.focus();
        hideSuccess(dom.successBanner);
        return;
      }

      const response = await globalScope.hfClient.generate('gpt2', token, 'Hello', {
        parameters: { max_new_tokens: 5, return_full_text: false },
        options: { wait_for_model: false }
      });

      if (response?.ok) {
        setStatus(dom.testResult, '✅ Token Valid', 'success');
        showSuccess(dom.successBanner);
        return;
      }
      setStatus(dom.testResult, '❌ Network Error', 'error');
      hideSuccess(dom.successBanner);
    } catch (error) {
      const mapped = mapTestError(error?.code || error?.message);
      setStatus(dom.testResult, mapped.message, mapped.tone);
      if (mapped.tone === 'success') {
        showSuccess(dom.successBanner);
      } else {
        hideSuccess(dom.successBanner);
      }
    } finally {
      dom.testBtn.disabled = false;
    }
  }

  function mapTokenError(code) {
    switch (code) {
      case 'HF_INVALID_TOKEN':
        return '⚠️ Invalid Hugging Face token — re-enter or generate a new one.';
      case 'TOKEN_ENCRYPT_FAILED':
        return '🔒 Could not save token on this device. Refresh and try again.';
      default:
        return '❌ Network error — try again shortly.';
    }
  }

  function mapTestError(code) {
    switch (code) {
      case 'HF_INVALID_TOKEN':
        return { message: '⚠️ Invalid Hugging Face token — double-check the value.', tone: 'warning' };
      case 'HF_SERVER_ERROR':
      case 'HF_NETWORK_ERROR':
        return { message: '❌ Network error — retry shortly.', tone: 'error' };
      case 'HF_MODEL_NOT_FOUND':
        return { message: "⚠️ Model not found — try 'gpt2' or check spelling.", tone: 'warning' };
      default:
        return { message: '❌ Network error — retry shortly.', tone: 'error' };
    }
  }

  function setStatus(element, message, tone) {
    if (!element) return;
    element.textContent = message;
    element.className = `status ${tone || 'info'}`;
  }

  function showSuccess(banner) {
    if (!banner) return;
    banner.hidden = false;
  }

  function hideSuccess(banner) {
    if (!banner) return;
    banner.hidden = true;
  }

  function toggleAccordion(dom) {
    if (!dom.accordionToggle || !dom.accordionBody) return;
    const expanded = dom.accordionToggle.getAttribute('aria-expanded') === 'true';
    dom.accordionToggle.setAttribute('aria-expanded', expanded ? 'false' : 'true');
    dom.accordionBody.setAttribute('aria-hidden', expanded ? 'true' : 'false');
  }
})(typeof window !== 'undefined' ? window : this);
