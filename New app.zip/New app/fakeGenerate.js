function safe(text) {
  return ('' + text).replace(/[<>&"']/g, s => ({
    '<': '&lt;', '>': '&gt;', '&': '&amp;', '"': '&quot;', "'": '&#39;'
  }[s]));
}
function fakeGenerate(prompt, useCase) {
  const base = `Offline suggestion for ${safe(useCase || 'general')} content:`;
  const p = safe(prompt || '');
  return [
    `${base} ${p}`,
    `${base} ${p} (variant 2)`,
    `${base} ${p} (variant 3)`
  ];
}