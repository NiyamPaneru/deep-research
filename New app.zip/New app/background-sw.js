var __require = /* @__PURE__ */ ((x) => typeof require !== "undefined" ? require : typeof Proxy !== "undefined" ? new Proxy(x, {
  get: (a, b) => (typeof require !== "undefined" ? require : a)[b]
}) : x)(function(x) {
  if (typeof require !== "undefined") return require.apply(this, arguments);
  throw Error('Dynamic require of "' + x + '" is not supported');
});

// utils/debug.js
var DEBUG_FLAG_KEY = "debug_logging_enabled";
var debugEnabled = null;
async function loadDebugFlag() {
  if (debugEnabled !== null) {
    return debugEnabled;
  }
  try {
    if (typeof chrome !== "undefined" && chrome.storage?.local) {
      const result = await chrome.storage.local.get([DEBUG_FLAG_KEY]);
      debugEnabled = Boolean(result[DEBUG_FLAG_KEY]);
      return debugEnabled;
    }
  } catch (_error) {
  }
  debugEnabled = false;
  return debugEnabled;
}
function debugLog(message, payload) {
  if (debugEnabled === null) {
    void loadDebugFlag().then(() => {
      if (debugEnabled) {
        console.debug("[SmartClipboard]", message, payload ?? null);
      }
    });
    return;
  }
  if (debugEnabled) {
    console.debug("[SmartClipboard]", message, payload ?? null);
  }
}

// config.js
var CONFIG = {
  SUPABASE_URL: "",
  SUPABASE_FUNCTIONS_URL: "",
  HF_SHARED_TOKEN: "",
  AUTH_REDIRECT_URL: "",
  ALLOWED_ORIGINS: ["http://localhost:54321"],
  TIER_POLICIES: {
    free: {
      type: "free",
      quota: { windowMs: 36 * 60 * 60 * 1e3, max: 3 }
    },
    ltd: {
      type: "dailyCap",
      quota: { windowMs: 24 * 60 * 60 * 1e3, max: 50 },
      defaultModel: "tiiuae/falcon-7b-instruct"
    },
    pro: {
      type: "subscription",
      quota: { windowMs: 60 * 60 * 1e3, max: -1 }
    }
  }
};
async function getRuntimeSupabaseConfig() {
  try {
    if (chrome?.storage?.local) {
      const data = await chrome.storage.local.get(["supabaseUrl", "supabaseFunctionsUrl", "supabaseAnonKey"]);
      return {
        url: (data.supabaseUrl || CONFIG.SUPABASE_URL || "").trim(),
        functionsUrl: (data.supabaseFunctionsUrl || CONFIG.SUPABASE_FUNCTIONS_URL || "").trim(),
        key: (data.supabaseAnonKey || "").trim()
      };
    }
  } catch (error) {
    debugLog("config.supabaseLoadFailed", error?.message || error);
  }
  return {
    url: CONFIG.SUPABASE_URL,
    functionsUrl: CONFIG.SUPABASE_FUNCTIONS_URL,
    key: ""
  };
}
async function getRuntimeHfToken() {
  try {
    if (chrome?.storage?.local) {
      const data = await chrome.storage.local.get(["hfToken", "hfSharedToken"]);
      if (typeof data.hfToken === "string" && data.hfToken.trim()) {
        return data.hfToken.trim();
      }
      if (typeof data.hfSharedToken === "string" && data.hfSharedToken.trim()) {
        return data.hfSharedToken.trim();
      }
    }
  } catch (error) {
    debugLog("config.hfTokenLoadFailed", error?.message || error);
  }
  return CONFIG.HF_SHARED_TOKEN || null;
}
function getTierPolicies() {
  return CONFIG.TIER_POLICIES;
}
var configUtils = {
  CONFIG,
  getRuntimeSupabaseConfig,
  getRuntimeHfToken,
  getTierPolicies,
  default: CONFIG
};
if (typeof globalThis !== "undefined") {
  globalThis.CONFIG = CONFIG;
  globalThis.getRuntimeSupabaseConfig = getRuntimeSupabaseConfig;
  globalThis.getRuntimeHfToken = getRuntimeHfToken;
  globalThis.getTierPolicies = getTierPolicies;
  globalThis.configUtils = configUtils;
}

// storageHelper.js
var DEVICE_KEY = "smartClipboard_deviceId_v1";
var memoryStore = /* @__PURE__ */ new Map();
function getChromeStorage() {
  if (typeof chrome !== "undefined" && chrome.storage?.local) {
    return chrome.storage.local;
  }
  return null;
}
function normalizeKeys(keys) {
  if (Array.isArray(keys)) return keys;
  if (keys && typeof keys === "object") return Object.keys(keys);
  if (typeof keys === "string") return [keys];
  return [];
}
async function storageGet(keys) {
  const area = getChromeStorage();
  if (!area) {
    const entries = normalizeKeys(keys);
    if (!entries.length) return {};
    return entries.reduce((acc, key) => {
      acc[key] = memoryStore.get(key);
      return acc;
    }, {});
  }
  try {
    const result = area.get(keys);
    if (result && typeof result.then === "function") {
      return result.catch(() => ({}));
    }
  } catch (_error) {
    return {};
  }
  return new Promise((resolve) => {
    try {
      area.get(keys, (items) => {
        if (chrome.runtime?.lastError) {
          resolve({});
          return;
        }
        resolve(items || {});
      });
    } catch (_error) {
      resolve({});
    }
  });
}
async function storageSet(items) {
  if (!items || typeof items !== "object") {
    return false;
  }
  const area = getChromeStorage();
  if (!area) {
    Object.entries(items).forEach(([key, value]) => {
      memoryStore.set(key, value);
    });
    return true;
  }
  const result = area.set(items);
  if (result && typeof result.then === "function") {
    try {
      await result;
      return true;
    } catch (_error) {
      return false;
    }
  }
  return new Promise((resolve) => {
    try {
      area.set(items, () => {
        if (chrome.runtime?.lastError) {
          resolve(false);
          return;
        }
        resolve(true);
      });
    } catch (_error) {
      resolve(false);
    }
  });
}
async function storageRemove(keys) {
  const entries = normalizeKeys(keys);
  const area = getChromeStorage();
  if (!area) {
    if (!entries.length && typeof keys === "string") {
      memoryStore.delete(keys);
      return true;
    }
    entries.forEach((key) => memoryStore.delete(key));
    return true;
  }
  const result = area.remove(keys);
  if (result && typeof result.then === "function") {
    try {
      await result;
      return true;
    } catch (_error) {
      return false;
    }
  }
  return new Promise((resolve) => {
    try {
      area.remove(keys, () => {
        if (chrome.runtime?.lastError) {
          resolve(false);
          return;
        }
        resolve(true);
      });
    } catch (_error) {
      resolve(false);
    }
  });
}
function getNodeCrypto() {
  if (typeof __require === "function") {
    try {
      return __require("crypto");
    } catch (_error) {
      return null;
    }
  }
  return null;
}
function generateDeviceId() {
  if (typeof crypto !== "undefined" && crypto.randomUUID) {
    return crypto.randomUUID();
  }
  const nodeCrypto = getNodeCrypto();
  if (nodeCrypto?.randomUUID) {
    return nodeCrypto.randomUUID();
  }
  const source = nodeCrypto?.randomBytes ? nodeCrypto : Math;
  const randomValue = typeof source.randomBytes === "function" ? source.randomBytes(8).toString("hex") : source.random().toString(36).slice(2, 10);
  return `device_${randomValue}`;
}
async function getOrCreateDeviceId() {
  const current = await storageGet([DEVICE_KEY]);
  const existing = current?.[DEVICE_KEY];
  if (existing && typeof existing === "string") {
    return existing;
  }
  const generated = generateDeviceId();
  await storageSet({ [DEVICE_KEY]: generated });
  return generated;
}
var storageHelper = {
  storageGet,
  storageSet,
  storageRemove,
  getOrCreateDeviceId,
  get: storageGet,
  set: storageSet,
  remove: storageRemove
};
if (typeof globalThis !== "undefined") {
  globalThis.storageHelper = storageHelper;
}
var storageHelper_default = storageHelper;

// storage/migrations.js
var MIGRATION_FLAG = "migration_v1_completed";
async function runMigrations() {
  try {
    const hasChrome = typeof chrome !== "undefined";
    if (!hasChrome || !chrome.storage?.local) {
      return;
    }
    const result = await chrome.storage.local.get([MIGRATION_FLAG]);
    if (result[MIGRATION_FLAG]) {
      return;
    }
    await migrateLocalStorage();
    await chrome.storage.local.set({ [MIGRATION_FLAG]: true });
    debugLog("migrations.completed", true);
  } catch (error) {
    debugLog("migrations.failed", error?.message || error);
  }
}
async function migrateLocalStorage() {
  try {
    const legacyKeys = [
      "smartClipboard_user",
      "smartClipboard_users",
      "userTier",
      "smartClipboard_deviceId_v1",
      "huggingFaceToken"
    ];
    const migrated = {};
    legacyKeys.forEach((key) => {
      const value = localStorage.getItem(key);
      if (value !== null && value !== void 0) {
        migrated[key] = value;
        localStorage.removeItem(key);
      }
    });
    if (Object.keys(migrated).length) {
      await chrome.storage.local.set(migrated);
    }
  } catch (error) {
    debugLog("migrations.localStorageError", error?.message || error);
  }
}
runMigrations();

// services/logger.js
var DEBUG_ENV_FLAG = "DEBUG";
function isDebugEnabled() {
  const scope = typeof globalThis !== "undefined" ? globalThis : {};
  const env = scope.ENV || {};
  if (typeof env[DEBUG_ENV_FLAG] === "string") {
    return env[DEBUG_ENV_FLAG].toLowerCase() === "true";
  }
  const proc = scope.process;
  return Boolean(proc?.env?.[DEBUG_ENV_FLAG] && proc.env[DEBUG_ENV_FLAG] === "true");
}
function scrub(value) {
  if (typeof value === "string" && value.toLowerCase().includes("hf_")) {
    return "[REDACTED_TOKEN]";
  }
  return value;
}
var logger = {
  debug: (...args) => {
    if (!isDebugEnabled()) {
      return;
    }
    const scrubbed = args.map(scrub);
    if (typeof console !== "undefined" && console.debug) {
      console.debug("[SmartClipboard]", ...scrubbed);
    }
  }
};
if (typeof globalThis !== "undefined") {
  globalThis.logger = logger;
}
var logger_default = logger;

// services/telemetry.js
var TELEMETRY_ENDPOINT = "https://api.example.com/telemetry";
var TELEMETRY_STORAGE_KEY = "telemetryEnabled";
var telemetryOptIn = false;
var preferenceLoaded = false;
async function readPreference() {
  if (preferenceLoaded) {
    return telemetryOptIn;
  }
  if (typeof chrome !== "undefined" && chrome.storage?.local) {
    try {
      const data = await chrome.storage.local.get([TELEMETRY_STORAGE_KEY]);
      telemetryOptIn = Boolean(data?.[TELEMETRY_STORAGE_KEY]);
    } catch (_error) {
      telemetryOptIn = false;
    }
  }
  preferenceLoaded = true;
  return telemetryOptIn;
}
function applyTelemetryPreference(flag) {
  telemetryOptIn = Boolean(flag);
  preferenceLoaded = true;
}
if (typeof chrome !== "undefined" && chrome.storage?.onChanged?.addListener) {
  chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName === "local" && Object.prototype.hasOwnProperty.call(changes, TELEMETRY_STORAGE_KEY)) {
      telemetryOptIn = Boolean(changes[TELEMETRY_STORAGE_KEY]?.newValue);
      preferenceLoaded = true;
    }
  });
}
async function sendTelemetry(event, payload = {}) {
  const enabled = await readPreference();
  if (!enabled) {
    return;
  }
  try {
    await fetch(TELEMETRY_ENDPOINT, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        event,
        status: payload.status || null,
        code: payload.code || null,
        ts: Date.now()
      })
    });
  } catch (_error) {
  }
}
var telemetry = {
  send: sendTelemetry,
  setOptIn: applyTelemetryPreference,
  refreshPreference: () => readPreference().catch(() => {
  })
};
if (typeof globalThis !== "undefined") {
  globalThis.telemetry = telemetry;
}
var telemetry_default = telemetry;

// quotaHelper.js
var TIER_CONFIGS = {
  free: {
    key: "free",
    name: "Free",
    generations: 3,
    resetMs: 36 * 60 * 60 * 1e3,
    price: 0,
    features: ["3 AI generations per 36h", "Unlimited clipboard history", "Basic support"]
  },
  pro: {
    key: "pro",
    name: "Pro",
    generations: -1,
    resetMs: 0,
    price: 9,
    features: ["Unlimited AI generations", "Priority support", "Advanced features"]
  }
};
async function storageGet2(keys) {
  try {
    return await storageHelper_default.storageGet(keys);
  } catch (_error) {
    return {};
  }
}
async function storageSet2(items) {
  try {
    return Boolean(await storageHelper_default.storageSet(items));
  } catch (_error) {
    return false;
  }
}
function getTierConfig(tierKey) {
  return TIER_CONFIGS[tierKey] || TIER_CONFIGS.free;
}
async function resolveTierKey() {
  try {
    const result = await storageGet2(["userTier"]);
    return result.userTier || "free";
  } catch (error) {
    logger_default.debug("quota.resolveTierFailed", error?.message || error);
    return "free";
  }
}
async function getUsageSnapshot(tierKey, deviceId) {
  const tier = getTierConfig(tierKey);
  const storageKey = `usage_${tierKey}_${deviceId}`;
  try {
    const result = await storageGet2([storageKey]);
    const usage = result[storageKey] || { used: 0, lastReset: Date.now() };
    const now = Date.now();
    const elapsed = now - usage.lastReset;
    if (tier.resetMs > 0 && elapsed >= tier.resetMs) {
      usage.used = 0;
      usage.lastReset = now;
      await storageSet2({ [storageKey]: usage });
    }
    const remaining = tier.generations === -1 ? Infinity : Math.max(0, tier.generations - usage.used);
    return {
      plan: tier,
      remaining,
      used: usage.used,
      total: tier.generations
    };
  } catch (error) {
    logger_default.debug("quota.snapshotFailed", error?.message || error);
    return {
      plan: tier,
      remaining: tier.generations === -1 ? Infinity : tier.generations,
      used: 0,
      total: tier.generations
    };
  }
}
async function checkAndIncrementQuota(tierKey, deviceId, amount = 1) {
  const snapshot = await getUsageSnapshot(tierKey, deviceId);
  if (snapshot.remaining === Infinity) {
    return { ok: true, remaining: Infinity };
  }
  if (snapshot.remaining < amount) {
    return { ok: false, remaining: snapshot.remaining };
  }
  try {
    const storageKey = `usage_${tierKey}_${deviceId}`;
    const result = await storageGet2([storageKey]);
    const usage = result[storageKey] || { used: 0, lastReset: Date.now() };
    usage.used += amount;
    await storageSet2({ [storageKey]: usage });
    const remaining = snapshot.total === -1 ? Infinity : Math.max(0, snapshot.total - usage.used);
    return { ok: true, remaining };
  } catch (error) {
    logger_default.debug("quota.incrementFailed", error?.message || error);
    return { ok: false, remaining: snapshot.remaining };
  }
}
async function decrementQuota(tierKey, deviceId, amount = 1) {
  try {
    const tier = getTierConfig(tierKey);
    const storageKey = `usage_${tierKey}_${deviceId}`;
    const result = await storageGet2([storageKey]);
    const usage = result[storageKey] || { used: 0, lastReset: Date.now() };
    usage.used = Math.max(0, usage.used - amount);
    await storageSet2({ [storageKey]: usage });
    const remaining = tier.generations === -1 ? Infinity : Math.max(0, tier.generations - usage.used);
    return { remaining };
  } catch (error) {
    logger_default.debug("quota.decrementFailed", error?.message || error);
    return { remaining: 0 };
  }
}
function listPlans(options = {}) {
  const { includeHidden = false } = options;
  return Object.values(TIER_CONFIGS).filter((plan) => includeHidden || !plan.hidden);
}
var quotaHelper = {
  getTierConfig,
  getPlan: getTierConfig,
  resolveTierKey,
  getUsageSnapshot,
  checkAndIncrementQuota,
  decrementQuota,
  listPlans
};
if (typeof globalThis !== "undefined") {
  globalThis.quotaHelper = quotaHelper;
}
var quotaHelper_default = quotaHelper;

// services/tiers/index.js
var TIER_KEY = "userTier";
var TIER_MODELS = {
  free: "gpt2",
  ltd: "tiiuae/falcon-7b-instruct",
  pro: "tiiuae/falcon-7b-instruct"
};
async function getCurrentTier() {
  try {
    const result = await chrome.storage.local.get([TIER_KEY]);
    const tier = result[TIER_KEY] || "free";
    return tier;
  } catch (error) {
    debugLog("tier.getCurrentTierFailed", error?.message || error);
    return "free";
  }
}
async function setCurrentTier(tier) {
  try {
    await chrome.storage.local.set({ [TIER_KEY]: tier });
  } catch (error) {
    debugLog("tier.setCurrentTierFailed", error?.message || error);
  }
}
function getModelForTier(tier) {
  return TIER_MODELS[tier] || TIER_MODELS.free;
}
async function enforceQuota(tierKey) {
  const policies = getTierPolicies();
  const tierPolicy = policies[tierKey] || policies.free;
  if (tierPolicy?.quota?.max === -1) {
    return { ok: true, remaining: Infinity };
  }
  const deviceId = await storageHelper_default.getOrCreateDeviceId();
  const amount = 1;
  const result = await quotaHelper_default.checkAndIncrementQuota(tierKey, deviceId, amount);
  return result;
}
async function rollbackQuota(tierKey) {
  const policies = getTierPolicies();
  const tierPolicy = policies[tierKey] || policies.free;
  if (tierPolicy?.quota?.max === -1) {
    return;
  }
  const deviceId = await storageHelper_default.getOrCreateDeviceId();
  await quotaHelper_default.decrementQuota(tierKey, deviceId, 1);
}

// services/hfClient.js
var MAX_ATTEMPTS = 4;
var RETRY_BASE_MS = 400;
var RETRY_CAP_MS = 4e3;
var REQUEST_TIMEOUT_MS = 2e4;
function createError(code, status, friendlyMessage) {
  const error = new Error(code);
  error.code = code;
  error.status = typeof status === "number" ? status : null;
  if (friendlyMessage) {
    error.friendlyMessage = friendlyMessage;
  }
  return error;
}
function wait(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
function backoffDelay(attempt) {
  const exponential = Math.min(RETRY_BASE_MS * Math.pow(2, attempt), RETRY_CAP_MS);
  const jitter = Math.random() * 150;
  return exponential + jitter;
}
function buildBody(input, opts) {
  const payload = {
    inputs: input,
    options: Object.assign({ wait_for_model: true }, opts?.options || {})
  };
  if (opts?.parameters) {
    payload.parameters = opts.parameters;
  }
  if (opts?.body && typeof opts.body === "object") {
    Object.assign(payload, opts.body);
  }
  return JSON.stringify(payload);
}
async function fetchWithTimeout(endpoint, options) {
  const scopedFetch = typeof fetch === "function" ? fetch : globalThis?.fetch;
  if (typeof AbortController !== "function" || !scopedFetch) {
    return scopedFetch(endpoint, options);
  }
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);
  try {
    return await scopedFetch(endpoint, Object.assign({}, options, { signal: controller.signal }));
  } catch (error) {
    if (error?.name === "AbortError") {
      throw createError("HF_TIMEOUT", null, "The request to Hugging Face timed out. Try again in a few seconds.");
    }
    throw error;
  } finally {
    clearTimeout(timer);
  }
}
function parseJsonSafely(text) {
  if (!text) return null;
  try {
    return JSON.parse(text);
  } catch (_error) {
    return null;
  }
}
function normalizePayload(data, status) {
  if (data == null) {
    throw createError("HF_EMPTY_RESPONSE", status, "The model did not return any content. Try again.");
  }
  if (Array.isArray(data)) {
    if (!data.length) {
      throw createError("HF_EMPTY_RESPONSE", status, "The model did not return any content. Try again.");
    }
    if (data.length === 1 && data[0] && typeof data[0].error === "string") {
      const lowered = data[0].error.toLowerCase();
      if (lowered.includes("rate limit")) {
        throw createError("HF_RATE_LIMITED", status, "You hit the Hugging Face rate limit. Wait a few seconds and try again.");
      }
      if (lowered.includes("loading") || lowered.includes("currently unavailable")) {
        throw createError("HF_SERVER_ERROR", status, "The model is warming up. Try again in a moment.");
      }
      throw createError("HF_SERVER_ERROR", status, data[0].error);
    }
    return data;
  }
  if (typeof data === "object") {
    if (Array.isArray(data.outputs) && data.outputs.length) {
      return data.outputs;
    }
    if (typeof data.generated_text === "string" && data.generated_text.trim()) {
      return [data.generated_text];
    }
    if (typeof data.output_text === "string" && data.output_text.trim()) {
      return [data.output_text];
    }
    if (typeof data.error === "string" && data.error.trim()) {
      const lowered = data.error.toLowerCase();
      if (lowered.includes("rate limit")) {
        throw createError("HF_RATE_LIMITED", status, "You hit the Hugging Face rate limit. Wait a few seconds and try again.");
      }
      if (lowered.includes("loading") || lowered.includes("currently unavailable")) {
        throw createError("HF_SERVER_ERROR", status, "The model is warming up. Try again in a moment.");
      }
      throw createError("HF_SERVER_ERROR", status, data.error);
    }
  }
  throw createError("HF_EMPTY_RESPONSE", status, "The model did not return any content. Try again.");
}
function normalizeError(error) {
  if (!error) {
    return createError("HF_UNKNOWN_ERROR", null, "An unknown error occurred. Try again.");
  }
  if (error.code && error.message === error.code) {
    return error;
  }
  if (error.code) {
    return error;
  }
  if (error.name === "TypeError" || error.message === "Failed to fetch") {
    return createError("HF_NETWORK_ERROR", error.status, "Network error contacting Hugging Face. Check your connection and retry.");
  }
  return createError("HF_UNKNOWN_ERROR", error.status, "An unknown error occurred. Try again.");
}
function shouldRetry(error, attempt) {
  const retriableCodes = /* @__PURE__ */ new Set(["HF_SERVER_ERROR", "HF_NETWORK_ERROR", "HF_RATE_LIMITED", "HF_TIMEOUT"]);
  return retriableCodes.has(error.code) && attempt < MAX_ATTEMPTS - 1;
}
function recordTelemetry(ok, status, code) {
  try {
    telemetry_default.send("model_call_status", { ok, status: status ?? null, code: code ?? null });
  } catch (_error) {
  }
}
async function generate(requestedModel, token, input, opts = {}) {
  const tier = await getCurrentTier();
  const modelName = requestedModel || getModelForTier(tier);
  if (!modelName || typeof modelName !== "string") {
    throw createError("HF_MODEL_REQUIRED", null, "A Hugging Face model name is required.");
  }
  if (!token || typeof token !== "string") {
    throw createError("HF_TOKEN_REQUIRED", null, "Add your Hugging Face token to continue.");
  }
  const quotaResult = await enforceQuota(tier);
  if (!quotaResult.ok) {
    return {
      ok: false,
      error: createError("HF_QUOTA_EXCEEDED", null, "Your plan quota is exhausted. Try again later."),
      remaining: quotaResult.remaining
    };
  }
  const endpoint = `https://api-inference.huggingface.co/models/${encodeURIComponent(modelName)}`;
  const headers = {
    Authorization: `Bearer ${token}`,
    "Content-Type": "application/json"
  };
  const body = buildBody(input, opts);
  let lastError = null;
  for (let attempt = 0; attempt < MAX_ATTEMPTS; attempt += 1) {
    try {
      const response = await fetchWithTimeout(endpoint, {
        method: "POST",
        headers,
        body
      });
      const { status } = response;
      debugLog("hfClient.generate", { modelName, status, attempt });
      if (status === 401) throw createError("HF_INVALID_TOKEN", status, "Invalid Hugging Face token. Update it in Settings.");
      if (status === 404) throw createError("HF_MODEL_NOT_FOUND", status, 'The selected model was not found. Try "gpt2".');
      if (status === 429) throw createError("HF_RATE_LIMITED", status, "You hit the the rate limit. Wait a few seconds and try again.");
      if (status === 408) throw createError("HF_TIMEOUT", status, "The request to Hugging Face timed out. Try again.");
      if (status === 204) throw createError("HF_EMPTY_RESPONSE", status, "The model did not return any content. Try again.");
      if (status >= 500) throw createError("HF_SERVER_ERROR", status, "Hugging Face servers are busy. Try again shortly.");
      const rawText = await response.text();
      const data = parseJsonSafely(rawText);
      const normalized = normalizePayload(data, status);
      recordTelemetry(true, status, null);
      return { ok: true, status, data: normalized, remaining: quotaResult.remaining };
    } catch (error) {
      const normalized = normalizeError(error);
      lastError = normalized;
      if (shouldRetry(normalized, attempt)) {
        await wait(backoffDelay(attempt));
        continue;
      }
      recordTelemetry(false, normalized.status, normalized.code);
      await rollbackQuota(tier);
      throw normalized;
    }
  }
  if (lastError) {
    recordTelemetry(false, lastError.status, lastError.code);
    await rollbackQuota(tier);
    throw lastError;
  }
  const fallbackError = createError("HF_SERVER_ERROR", null, "Hugging Face servers are busy. Try again shortly.");
  recordTelemetry(false, fallbackError.status, fallbackError.code);
  await rollbackQuota(tier);
  throw fallbackError;
}
var hfClient = {
  generate
};
if (typeof globalThis !== "undefined") {
  globalThis.hfClient = hfClient;
}
var hfClient_default = hfClient;

// services/tokenStore.js
var STORE_KEY = "hf_token_encrypted_v1";
var SECRET_KEY = "hf_token_secret_v1";
var memoryStore2 = /* @__PURE__ */ new Map();
function getStorageArea() {
  if (typeof chrome !== "undefined" && chrome.storage?.local) {
    return chrome.storage.local;
  }
  return null;
}
function getNodeCrypto2() {
  if (typeof __require === "function") {
    try {
      return __require("crypto");
    } catch (_error) {
      return null;
    }
  }
  return null;
}
function getNodeUtil() {
  if (typeof __require === "function") {
    try {
      return __require("util");
    } catch (_error) {
      return null;
    }
  }
  return null;
}
function toUint8Array(buffer) {
  if (buffer instanceof Uint8Array) {
    return buffer;
  }
  return new Uint8Array(buffer);
}
function toBase64(bytes) {
  if (typeof btoa === "function") {
    let binary = "";
    const arr = toUint8Array(bytes);
    for (let i = 0; i < arr.length; i += 1) {
      binary += String.fromCharCode(arr[i]);
    }
    return btoa(binary);
  }
  return Buffer.from(bytes).toString("base64");
}
function fromBase64(value) {
  if (!value) {
    return new Uint8Array();
  }
  if (typeof atob === "function") {
    const binary = atob(value);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i += 1) {
      bytes[i] = binary.charCodeAt(i);
    }
    return bytes;
  }
  return new Uint8Array(Buffer.from(value, "base64"));
}
function getCrypto() {
  if (typeof crypto !== "undefined" && crypto.subtle) {
    return crypto;
  }
  const nodeCrypto = getNodeCrypto2();
  if (nodeCrypto?.webcrypto?.subtle) {
    return nodeCrypto.webcrypto;
  }
  throw new Error("CRYPTO_UNAVAILABLE");
}
function createTextEncoder() {
  if (typeof TextEncoder !== "undefined") {
    return new TextEncoder();
  }
  const util = getNodeUtil();
  if (util?.TextEncoder) {
    return new util.TextEncoder();
  }
  throw new Error("TEXT_ENCODER_UNAVAILABLE");
}
function createTextDecoder() {
  if (typeof TextDecoder !== "undefined") {
    return new TextDecoder();
  }
  const util = getNodeUtil();
  if (util?.TextDecoder) {
    return new util.TextDecoder();
  }
  throw new Error("TEXT_DECODER_UNAVAILABLE");
}
async function storageGet3(keys) {
  const area = getStorageArea();
  if (!area) {
    if (Array.isArray(keys)) {
      return keys.reduce((acc, key) => {
        acc[key] = memoryStore2.get(key);
        return acc;
      }, {});
    }
    if (typeof keys === "string") {
      return { [keys]: memoryStore2.get(keys) };
    }
    if (keys && typeof keys === "object") {
      return Object.keys(keys).reduce((acc, key) => {
        acc[key] = memoryStore2.get(key) ?? keys[key];
        return acc;
      }, {});
    }
    return {};
  }
  const result = area.get(keys);
  if (result && typeof result.then === "function") {
    return result;
  }
  return new Promise((resolve, reject) => {
    area.get(keys, (items) => {
      if (chrome?.runtime?.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
        return;
      }
      resolve(items || {});
    });
  });
}
async function storageSet3(items) {
  if (!items || typeof items !== "object") {
    return;
  }
  const area = getStorageArea();
  if (!area) {
    Object.entries(items).forEach(([key, value]) => {
      memoryStore2.set(key, value);
    });
    return;
  }
  const result = area.set(items);
  if (result && typeof result.then === "function") {
    await result;
    return;
  }
  await new Promise((resolve, reject) => {
    area.set(items, () => {
      if (chrome?.runtime?.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
        return;
      }
      resolve();
    });
  });
}
async function storageRemove2(keys) {
  const area = getStorageArea();
  if (!area) {
    if (Array.isArray(keys)) {
      keys.forEach((key) => memoryStore2.delete(key));
    } else {
      memoryStore2.delete(keys);
    }
    return;
  }
  const result = area.remove(keys);
  if (result && typeof result.then === "function") {
    await result;
    return;
  }
  await new Promise((resolve, reject) => {
    area.remove(keys, () => {
      if (chrome?.runtime?.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
        return;
      }
      resolve();
    });
  });
}
async function getSecretMaterial() {
  const cached = await storageGet3([SECRET_KEY]);
  const stored = cached?.[SECRET_KEY];
  if (stored && typeof stored === "string") {
    return fromBase64(stored);
  }
  const cryptoApi = getCrypto();
  const secret = new Uint8Array(32);
  cryptoApi.getRandomValues(secret);
  await storageSet3({ [SECRET_KEY]: toBase64(secret) });
  return secret;
}
async function getCryptoKey() {
  const cryptoApi = getCrypto();
  const material = await getSecretMaterial();
  return cryptoApi.subtle.importKey("raw", material, { name: "AES-GCM" }, false, ["encrypt", "decrypt"]);
}
async function encryptToken(token) {
  const cryptoApi = getCrypto();
  const key = await getCryptoKey();
  const iv = new Uint8Array(12);
  cryptoApi.getRandomValues(iv);
  const encoder = createTextEncoder();
  const cipherBuffer = await cryptoApi.subtle.encrypt({ name: "AES-GCM", iv }, key, encoder.encode(token));
  return {
    iv: toBase64(iv),
    data: toBase64(toUint8Array(cipherBuffer))
  };
}
async function decryptToken(payload) {
  if (!payload || typeof payload !== "object") {
    return null;
  }
  const { iv, data } = payload;
  if (!iv || !data) {
    return null;
  }
  try {
    const cryptoApi = getCrypto();
    const key = await getCryptoKey();
    const decrypted = await cryptoApi.subtle.decrypt({ name: "AES-GCM", iv: fromBase64(iv) }, key, fromBase64(data));
    const decoder = createTextDecoder();
    return decoder.decode(decrypted);
  } catch (error) {
    logger_default.debug("tokenStore.decryptFailed", error?.message || error);
    return null;
  }
}
function mapError(code) {
  switch (code) {
    case "HF_INVALID_TOKEN":
      return { code, message: "Invalid Hugging Face token \u2014 update it in Settings." };
    case "HF_MODEL_NOT_FOUND":
      return { code, message: 'Model not found \u2014 try "gpt2" or verify the model name.' };
    case "HF_EMPTY_RESPONSE":
      return { code, message: "Model returned no output \u2014 try again or switch models." };
    case "HF_SERVER_ERROR":
      return { code, message: "Temporary server issue \u2014 try again shortly." };
    case "HF_NETWORK_ERROR":
    default:
      return { code: code || "HF_NETWORK_ERROR", message: "Network error \u2014 retry once your connection is stable." };
  }
}
function emitTelemetry(event, payload) {
  try {
    telemetry_default.send(event, payload);
  } catch (_error) {
  }
}
async function setToken(token) {
  if (!token) {
    await clearToken();
    emitTelemetry("token_test_cleared", {});
    return { ok: true, message: "Token cleared." };
  }
  if (!hfClient_default?.generate) {
    throw new Error("HF_CLIENT_UNAVAILABLE");
  }
  try {
    const validation = await hfClient_default.generate("gpt2", token, "Test", {
      parameters: {
        max_new_tokens: 1,
        return_full_text: false
      }
    });
    logger_default.debug("tokenStore.validationStatus", validation.status);
    emitTelemetry("token_test_success", { status: validation.status });
  } catch (error) {
    const mapped = mapError(error?.code || error?.message || "HF_NETWORK_ERROR");
    logger_default.debug("tokenStore.validationFailed", mapped.code);
    emitTelemetry("token_test_fail", { code: mapped.code });
    return { ok: false, code: mapped.code, message: mapped.message };
  }
  try {
    const encrypted = await encryptToken(token);
    await storageSet3({ [STORE_KEY]: encrypted });
    return { ok: true, message: "Token saved securely." };
  } catch (error) {
    logger_default.debug("tokenStore.storeFailed", error?.message || error);
    return { ok: false, code: "TOKEN_STORE_FAILED", message: "Unable to store the token on this device." };
  }
}
async function getToken() {
  try {
    const stored = await storageGet3([STORE_KEY]);
    return await decryptToken(stored?.[STORE_KEY]);
  } catch (error) {
    logger_default.debug("tokenStore.readFailed", error?.message || error);
    return null;
  }
}
async function clearToken() {
  await storageRemove2([STORE_KEY]);
}
var tokenStore = {
  setToken,
  getToken,
  clearToken
};
if (typeof globalThis !== "undefined") {
  globalThis.tokenStore = tokenStore;
  globalThis.tokenStorage = tokenStore;
}
var tokenStore_default = tokenStore;

// services/supabase.js
async function postJson(endpoint, payload) {
  const { functionsUrl } = await getRuntimeSupabaseConfig();
  if (!functionsUrl) {
    throw new Error("Supabase functions URL is not configured.");
  }
  const url = `${functionsUrl.replace(/\/$/, "")}/${endpoint.replace(/^\//, "")}`;
  try {
    const response = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(errorText || `Request failed with status ${response.status}`);
    }
    return response.json();
  } catch (error) {
    debugLog("supabase.rpcFailed", { endpoint, message: error?.message || error });
    throw error;
  }
}
async function verifyLTD(licenseKey, email) {
  return postJson("verify_ltd", { licenseKey, email });
}
async function generateContent(prompt, useCase = "general", extras = {}) {
  const safePrompt = typeof prompt === "string" ? prompt : String(prompt ?? "");
  const payload = Object.assign({}, extras, {
    prompt: safePrompt,
    useCase: typeof useCase === "string" && useCase.trim() ? useCase.trim() : "general"
  });
  return postJson("generate", payload);
}

// background/listeners.js
var HISTORY_STORAGE_KEY = "clipboardHistory";
var LICENSE_STORAGE_KEY = "userLicense";
var HISTORY_LIMIT = 50;
var HISTORY_TEXT_LIMIT = 8e3;
if (typeof chrome !== "undefined") {
  chrome.runtime.onMessage.addListener((request, _sender, sendResponse) => {
    (async () => {
      try {
        const action = request?.action || request?.type;
        switch (action) {
          case "generate":
            await handleGenerate(request, sendResponse);
            return;
          case "generateContent":
            sendResponse(await handleSupabaseGenerate(request));
            return;
          case "getClipboardHistory":
            sendResponse(await getClipboardHistory());
            return;
          case "save_clipboard":
            sendResponse(await handleSaveClipboard(request));
            return;
          case "clearHistory":
            sendResponse(await clearClipboardHistory());
            return;
          case "deleteHistoryItem":
            sendResponse(await deleteHistoryItem(request));
            return;
          case "updateHistoryItem":
            sendResponse(await updateHistoryItem(request));
            return;
          case "setToken":
            sendResponse(await handleSetToken(request));
            return;
          case "getToken":
            sendResponse(await handleGetToken());
            return;
          case "clearToken":
            sendResponse(await handleClearToken());
            return;
          case "verifyLicense":
          case "verifyLicenseKey":
            sendResponse(await handleLicenseActivation(request));
            return;
          case "verifyLTDLicense":
            sendResponse(await handleLTDVerification(request));
            return;
          case "verifyGumroadLicense":
            sendResponse(await handleGumroadVerification(request));
            return;
          case "signInWithGoogle":
            sendResponse(await handleGoogleSignIn());
            return;
          case "saveLTDToCloud":
            sendResponse(await handleSaveLTDToCloud(request));
            return;
          case "saveProToCloud":
            sendResponse(await handleSaveProToCloud(request));
            return;
          case "checkProStatus":
            sendResponse(await handleCheckProStatus());
            return;
          case "getTier":
            sendResponse({ ok: true, tier: await getCurrentTier() });
            return;
          case "ping":
            sendResponse({ ok: true, ts: Date.now() });
            return;
          default:
            sendResponse({ ok: false, code: "UNKNOWN_ACTION" });
        }
      } catch (error) {
        debugLog("background.listenerError", error?.message || error);
        sendResponse({ ok: false, error: error?.message || "Unknown error." });
      }
    })();
    return true;
  });
  chrome.contextMenus?.onClicked?.addListener(async (info, tab) => {
    if (info.menuItemId === "saveToClipboard" && info.selectionText) {
      await saveToHistory(info.selectionText, { source: "context-menu" });
    }
    if (info.menuItemId === "savePageUrlToClipboard" && tab?.url) {
      const text = tab.title ? `${tab.url}
Title: ${tab.title}` : tab.url;
      await saveToHistory(text, { source: "context-menu" });
    }
  });
}
async function handleGenerate(request, sendResponse) {
  const { token, source } = await getEffectiveToken();
  if (!token) {
    sendResponse({ outputs: [], error: "AI is temporarily unavailable. Try again soon.", code: "HF_TOKEN_MISSING" });
    return;
  }
  const prompt = sanitizeText(String(request.input || "")).slice(0, 4e3);
  const desired = clampResponses(request.responses);
  const modelName = typeof request.model === "string" && request.model.trim() ? request.model.trim() : "gpt2";
  try {
    const generation = await hfClient_default.generate(modelName, token, prompt, {
      parameters: {
        num_return_sequences: desired,
        max_new_tokens: 60,
        return_full_text: false,
        temperature: 0.8
      }
    });
    if (generation?.ok === false) {
      const friendly = generation?.error?.friendlyMessage || generation?.error?.message || "Quota exceeded. Try again later.";
      const code = generation?.error?.code || "HF_QUOTA_EXCEEDED";
      sendResponse({ outputs: [], error: friendly, code, remainingQuota: generation?.remaining ?? null });
      return;
    }
    const outputs = extractOutputs(generation?.data, desired);
    if (!outputs.length) {
      sendResponse({ outputs: [], error: "Model returned no output.", code: "HF_EMPTY_RESPONSE", remainingQuota: generation?.remaining ?? null });
      return;
    }
    sendResponse({
      outputs,
      error: null,
      code: null,
      remainingQuota: generation?.remaining ?? null,
      tokenSource: source
    });
  } catch (error) {
    const mapped = mapModelError(error);
    debugLog("background.generateFailed", mapped.code);
    sendResponse({ outputs: [], error: mapped.message, code: mapped.code });
  }
}
async function handleSupabaseGenerate(request) {
  const prompt = sanitizeText(String(request?.prompt || "")).slice(0, 4e3);
  if (!prompt) {
    return { success: false, error: "Prompt is required." };
  }
  const useCase = sanitizeText(String(request?.useCase || "general")) || "general";
  try {
    const response = await generateContent(prompt, useCase);
    const outputs = Array.isArray(response?.outputs) ? response.outputs.filter(Boolean).map(formatModelOutput) : [];
    const payloadOutputs = outputs.length ? outputs : normalizeGenerateResponse(response);
    return { success: true, outputs: payloadOutputs, content: payloadOutputs };
  } catch (error) {
    debugLog("background.supabaseGenerateFailed", error?.message || error);
    return { success: false, error: error?.message || "Generation failed." };
  }
}
async function handleSaveClipboard(request) {
  const text = sanitizeText(String(request?.text || "")).slice(0, HISTORY_TEXT_LIMIT);
  if (!text) {
    return { status: "skipped" };
  }
  const item = await saveToHistory(text, { source: request?.source });
  return { status: item ? "saved" : "skipped", item };
}
async function handleSetToken(request) {
  const token = typeof request?.token === "string" ? request.token.trim() : "";
  try {
    const result = await tokenStore_default.setToken(token);
    return result || { ok: true };
  } catch (error) {
    debugLog("background.setTokenFailed", error?.message || error);
    return { ok: false, code: "TOKEN_STORE_FAILED", message: "Unable to store token on this device." };
  }
}
async function handleGetToken() {
  const { token, source } = await getEffectiveToken();
  const hasUserToken = source === "user";
  const hasSharedToken = source === "shared";
  return {
    ok: true,
    token: hasUserToken ? token : null,
    hasToken: Boolean(token),
    hasUserToken,
    hasSharedToken,
    source
  };
}
async function handleClearToken() {
  try {
    await tokenStore_default.clearToken();
    return { ok: true };
  } catch (error) {
    debugLog("background.clearTokenFailed", error?.message || error);
    return { ok: false };
  }
}
async function clearClipboardHistory() {
  await chrome.storage.local.set({ [HISTORY_STORAGE_KEY]: [] });
  return { success: true };
}
async function deleteHistoryItem(payload = {}) {
  const result = await chrome.storage.local.get([HISTORY_STORAGE_KEY]);
  const history = Array.isArray(result[HISTORY_STORAGE_KEY]) ? result[HISTORY_STORAGE_KEY] : [];
  const numericId = parseNumericId(payload.id);
  const removalText = typeof payload.text === "string" ? payload.text : "";
  const filtered = history.filter((item) => {
    if (numericId !== null) {
      return Number(item.id) !== numericId;
    }
    if (removalText) {
      return item.text !== removalText;
    }
    return true;
  });
  await chrome.storage.local.set({ [HISTORY_STORAGE_KEY]: filtered });
  return { success: true, removed: history.length > filtered.length, history: filtered };
}
async function updateHistoryItem(payload = {}) {
  const numericId = parseNumericId(payload.id);
  const text = sanitizeText(String(payload.text || "")).slice(0, HISTORY_TEXT_LIMIT);
  if (!text) {
    return { success: false, error: "empty" };
  }
  const result = await chrome.storage.local.get([HISTORY_STORAGE_KEY]);
  const history = Array.isArray(result[HISTORY_STORAGE_KEY]) ? result[HISTORY_STORAGE_KEY] : [];
  const index = history.findIndex((item) => numericId !== null ? Number(item.id) === numericId : item.text === text);
  if (index === -1) {
    return { success: false, error: "not_found" };
  }
  const updatedItem = {
    ...history[index],
    text,
    timestamp: (/* @__PURE__ */ new Date()).toISOString()
  };
  history[index] = updatedItem;
  const limit = await getHistoryLimit();
  const deduped = history.filter((entry, position) => position === history.findIndex((candidate) => candidate.id === entry.id)).map((entry) => ({
    ...entry,
    text: sanitizeText(String(entry.text || "")).slice(0, HISTORY_TEXT_LIMIT)
  })).slice(0, limit);
  await chrome.storage.local.set({ [HISTORY_STORAGE_KEY]: deduped });
  return { success: true, item: updatedItem, history: deduped };
}
async function getClipboardHistory() {
  const result = await chrome.storage.local.get([HISTORY_STORAGE_KEY]);
  return { history: Array.isArray(result[HISTORY_STORAGE_KEY]) ? result[HISTORY_STORAGE_KEY] : [] };
}
async function handleLicenseActivation(request = {}) {
  const licenseKey = typeof request.licenseKey === "string" ? request.licenseKey.trim() : "";
  const email = typeof request.email === "string" ? request.email.trim() : "";
  if (!licenseKey) {
    return { ok: false, error: "License key required." };
  }
  try {
    const result = await verifyLTD(licenseKey, email);
    const tier = result?.tier || "free";
    await setCurrentTier(tier);
    await persistLicense({
      key: licenseKey,
      email,
      tier,
      status: result?.status || "valid",
      verifiedAt: (/* @__PURE__ */ new Date()).toISOString()
    });
    return { ok: true, tier, status: result?.status || "valid", meta: result?.meta || null };
  } catch (error) {
    debugLog("background.verifyLicenseFailed", error?.message || error);
    return { ok: false, error: error?.message || "License verification failed." };
  }
}
async function saveToHistory(text, meta = {}) {
  const item = {
    id: Date.now(),
    text,
    timestamp: (/* @__PURE__ */ new Date()).toISOString(),
    meta
  };
  const result = await chrome.storage.local.get([HISTORY_STORAGE_KEY]);
  const history = Array.isArray(result[HISTORY_STORAGE_KEY]) ? result[HISTORY_STORAGE_KEY] : [];
  const updated = [item, ...history].slice(0, HISTORY_LIMIT);
  await chrome.storage.local.set({ [HISTORY_STORAGE_KEY]: updated });
  try {
    chrome.runtime?.sendMessage?.({ action: "clipboard:saved", item });
  } catch (_error) {
  }
  return item;
}
async function getEffectiveToken() {
  const userToken = await readUserToken();
  if (userToken) {
    return { token: userToken, source: "user" };
  }
  const shared = await getRuntimeHfToken();
  if (shared) {
    return { token: shared, source: "shared" };
  }
  return { token: null, source: null };
}
async function readUserToken() {
  try {
    const token = await tokenStore_default.getToken();
    if (token) {
      return token;
    }
  } catch (error) {
    debugLog("background.userTokenReadFailed", error?.message || error);
  }
  if (!chrome?.storage?.local?.get) {
    return null;
  }
  try {
    const legacy = await new Promise((resolve) => {
      try {
        chrome.storage.local.get(["userHfToken"], (value) => {
          if (chrome.runtime?.lastError) {
            resolve(null);
            return;
          }
          resolve(typeof value?.userHfToken === "string" ? value.userHfToken.trim() : null);
        });
      } catch (_error) {
        resolve(null);
      }
    });
    if (legacy) {
      await tokenStore_default.setToken(legacy);
      chrome.storage.local.remove?.(["userHfToken"]);
      return legacy;
    }
  } catch (error) {
    debugLog("background.legacyTokenMigrationFailed", error?.message || error);
  }
  return null;
}
async function persistLicense(payload) {
  try {
    await chrome.storage.local.set({ [LICENSE_STORAGE_KEY]: payload });
  } catch (error) {
    debugLog("background.persistLicenseFailed", error?.message || error);
  }
}
function clampResponses(responses) {
  const numeric = Number.parseInt(responses, 10);
  if (!Number.isFinite(numeric)) {
    return 1;
  }
  return Math.min(Math.max(numeric, 1), 5);
}
function parseNumericId(value) {
  const numeric = typeof value === "string" ? Number.parseInt(value, 10) : value;
  return Number.isFinite(numeric) ? numeric : null;
}
async function getHistoryLimit() {
  if (!chrome?.storage?.sync?.get) {
    return HISTORY_LIMIT;
  }
  try {
    const result = await new Promise((resolve) => {
      try {
        chrome.storage.sync.get(["smartClipboard_historyLimit"], (items) => {
          if (chrome.runtime?.lastError) {
            resolve({});
            return;
          }
          resolve(items || {});
        });
      } catch (_error) {
        resolve({});
      }
    });
    const parsed = Number.parseInt(result.smartClipboard_historyLimit, 10);
    return Number.isFinite(parsed) && parsed > 0 ? parsed : HISTORY_LIMIT;
  } catch (_error) {
    return HISTORY_LIMIT;
  }
}
function sanitizeText(text) {
  if (typeof text !== "string") {
    return "";
  }
  return text.replace(/\s+/g, " ").replace(/[\u0000-\u001F\u007F]+/g, " ").trim();
}
function formatModelOutput(raw) {
  const text = sanitizeText(String(raw ?? ""));
  if (!text) {
    return "";
  }
  return text.length > 400 ? `${text.slice(0, 397)}...` : text;
}
function extractOutputs(payload, desired) {
  const limit = Math.max(1, desired);
  const collected = [];
  if (Array.isArray(payload)) {
    payload.forEach((entry) => {
      if (collected.length >= limit) {
        return;
      }
      const text = typeof entry === "string" ? entry : entry?.generated_text || entry?.text || "";
      const normalized = formatModelOutput(text);
      if (normalized) {
        collected.push(normalized);
      }
    });
  } else if (payload && typeof payload === "object") {
    const normalized = formatModelOutput(payload.generated_text || payload.text || "");
    if (normalized) {
      collected.push(normalized);
    }
  }
  return collected.slice(0, limit);
}
function normalizeGenerateResponse(response) {
  if (!response || typeof response !== "object") {
    return [];
  }
  const candidates = [];
  if (typeof response.content === "string") {
    candidates.push(response.content);
  }
  if (typeof response.result === "string") {
    candidates.push(response.result);
  }
  return candidates.map(formatModelOutput).filter(Boolean);
}
function mapModelError(error) {
  const code = error?.code || error?.message || "HF_NETWORK_ERROR";
  switch (code) {
    case "HF_INVALID_TOKEN":
      return { code, message: "Invalid Hugging Face token \u2014 update it in Settings." };
    case "HF_MODEL_NOT_FOUND":
      return { code, message: "Model not found \u2014 try 'gpt2' or verify the model name." };
    case "HF_EMPTY_RESPONSE":
      return { code, message: "The model returned no output. Try again." };
    case "HF_RATE_LIMITED":
      return { code, message: "Rate limited by Hugging Face. Wait a few seconds and retry." };
    case "HF_TIMEOUT":
      return { code, message: "The model request timed out. Try again." };
    case "HF_SERVER_ERROR":
      return { code, message: "Hugging Face servers are busy. Try again shortly." };
    default:
      return { code: "HF_NETWORK_ERROR", message: "Network error contacting Hugging Face. Check your connection and retry." };
  }
}

// New handlers for LTD and Pro activation
async function handleLTDVerification(request) {
  const { licenseKey, email } = request;
  try {
    // Check if license is already used by different email
    const existingLicense = await checkLicenseUsage(licenseKey);
    if (existingLicense && existingLicense.email !== email) {
      return { success: false, error: 'License key already activated with different email' };
    }
    
    const result = await verifyLTD(licenseKey, email);
    return { success: true, ...result };
  } catch (error) {
    return { success: false, error: error?.message || 'LTD verification failed' };
  }
}

async function handleGumroadVerification(request) {
  const { licenseKey } = request;
  try {
    const { verifyGumroadLicense } = await import('./services/gumroad.js');
    const result = await verifyGumroadLicense(licenseKey);
    return { success: result.valid, ...result };
  } catch (error) {
    return { success: false, error: error?.message || 'Gumroad verification failed' };
  }
}

async function handleGoogleSignIn() {
  try {
    const userId = 'user_' + Date.now();
    const email = 'user@example.com';
    
    // Check if user already has LTD/Pro access in Supabase
    const existingAccess = await checkUserAccess(email);
    if (existingAccess) {
      // Auto-restore their tier
      await chrome.storage.local.set({
        userTier: existingAccess.tier,
        userId: userId,
        email: email,
        activatedAt: existingAccess.activatedAt
      });
    }
    
    return { success: true, userId, email, existingAccess };
  } catch (error) {
    return { success: false, error: error?.message || 'Sign-in failed' };
  }
}

async function handleSaveLTDToCloud(request) {
  try {
    const { userId, email, licenseKey, licenseEmail } = request;
    
    // Check if user already has Pro (prevent dual plans)
    const existingAccess = await checkUserAccess(email);
    if (existingAccess && existingAccess.tier === 'pro') {
      return { success: false, error: 'Account already has Pro subscription. Contact support to switch plans.' };
    }
    
    // Save LTD license mapping
    await saveLicenseMapping(licenseKey, email, 'ltd');
    await saveUserAccess(email, 'ltd', Date.now());
    
    return { success: true };
  } catch (error) {
    return { success: false, error: error?.message || 'Failed to save LTD license' };
  }
}

async function handleSaveProToCloud(request) {
  try {
    const { userId, email, licenseKey, gumroadEmail } = request;
    
    // Check if user already has LTD (prevent dual plans)
    const existingAccess = await checkUserAccess(email);
    if (existingAccess && existingAccess.tier === 'ltd') {
      return { success: false, error: 'Account already has Lifetime access. No need for Pro subscription.' };
    }
    
    // Save Pro subscription
    await saveUserAccess(email, 'pro', Date.now());
    
    return { success: true };
  } catch (error) {
    return { success: false, error: error?.message || 'Failed to save Pro subscription' };
  }
}

async function handleCheckProStatus() {
  try {
    const data = await chrome.storage.local.get(['userTier', 'gumroadLicenseKey']);
    if (data.userTier !== 'pro' || !data.gumroadLicenseKey) {
      return { active: false };
    }
    
    const { verifyGumroadLicense } = await import('./services/gumroad.js');
    const result = await verifyGumroadLicense(data.gumroadLicenseKey);
    
    return {
      active: result.valid && !result.access_ended,
      status: result.cancelled ? 'cancelled' : 'active',
      nextBilling: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString()
    };
  } catch (error) {
    return { active: false, error: error?.message };
  }
}

async function checkAllProSubscriptions() {
  const data = await chrome.storage.local.get(['userTier', 'gumroadLicenseKey', 'userId']);
  
  if (data.userTier !== 'pro' || !data.gumroadLicenseKey) {
    return;
  }
  
  debugLog('Checking Pro subscription status...');
  
  try {
    const { verifyGumroadLicense } = await import('./services/gumroad.js');
    const result = await verifyGumroadLicense(data.gumroadLicenseKey);
    
    if (result.valid && !result.cancelled) {
      debugLog('Pro subscription active');
    } else if (result.cancelled) {
      debugLog('Pro subscription cancelled');
      if (result.access_ended) {
        await downgradeToFree('Subscription ended');
      }
    } else {
      debugLog('Pro subscription expired');
      await downgradeToFree('Subscription expired');
    }
  } catch (error) {
    debugLog('Failed to check Pro status:', error?.message || error);
  }
}

async function downgradeToFree(reason) {
  await chrome.storage.local.set({
    userTier: 'free',
    previousTier: 'pro',
    downgradedAt: Date.now(),
    downgradeReason: reason
  });
  
  chrome.notifications?.create({
    type: 'basic',
    iconUrl: 'icons/icon128.png',
    title: 'Pro Subscription Ended',
    message: `Your Pro subscription has ${reason.toLowerCase()}. Click to renew on Gumroad.`,
    buttons: [
      { title: 'Renew Now' },
      { title: 'Dismiss' }
    ],
    requireInteraction: true
  });
}

// Helper functions for license validation
async function checkLicenseUsage(licenseKey) {
  // Mock implementation - replace with actual Supabase query
  // SELECT email FROM license_mappings WHERE license_key = licenseKey
  return null; // Return { email: 'user@example.com' } if found
}

async function checkUserAccess(email) {
  // Mock implementation - replace with actual Supabase query  
  // SELECT tier, activated_at FROM user_access WHERE email = email
  return null; // Return { tier: 'ltd', activatedAt: timestamp } if found
}

async function saveLicenseMapping(licenseKey, email, tier) {
  // Mock implementation - replace with actual Supabase insert
  // INSERT INTO license_mappings (license_key, email, tier) VALUES (licenseKey, email, tier)
}

async function saveUserAccess(email, tier, activatedAt) {
  // Mock implementation - replace with actual Supabase upsert
  // INSERT INTO user_access (email, tier, activated_at) VALUES (email, tier, activatedAt) ON CONFLICT (email) DO UPDATE SET tier = tier, activated_at = activatedAt
}

if (typeof chrome !== 'undefined' && chrome.notifications?.onButtonClicked) {
  chrome.notifications.onButtonClicked.addListener((notificationId, buttonIndex) => {
    if (buttonIndex === 0) {
      chrome.tabs.create({
        url: 'https://yourname.gumroad.com/l/smart-clipboard-pro'
      });
    }
    chrome.notifications.clear(notificationId);
  });
}

// background/lifecycle.js
if (typeof chrome !== "undefined") {
  chrome.runtime.onInstalled.addListener(async (details) => {
    await runMigrations();
    await loadDebugFlag();
    debugLog("background.installed", details.reason);
    setupContextMenus();
    
    // Set up daily Pro subscription check
    chrome.alarms.create('dailyProCheck', {
      periodInMinutes: 1440 // 24 hours
    });
  });
  chrome.runtime.onStartup?.addListener(async () => {
    await runMigrations();
    await loadDebugFlag();
    debugLog("background.startup");
  });
  
  // Handle daily Pro subscription checks
  chrome.alarms?.onAlarm?.addListener(async (alarm) => {
    if (alarm.name === 'dailyProCheck') {
      await checkAllProSubscriptions();
    }
  });
}
function setupContextMenus() {
  if (!chrome.contextMenus?.create) {
    return;
  }
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({
      id: "saveToClipboard",
      title: "Save to Smart Clipboard",
      contexts: ["selection"]
    });
    chrome.contextMenus.create({
      id: "savePageUrlToClipboard",
      title: "Save Page URL to Smart Clipboard",
      contexts: ["page"]
    });
  });
}
