// GPT-5 Refactor: Background orchestration entry.
import './listeners.js';
import './lifecycle.js';
