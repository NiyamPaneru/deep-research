// GPT-5 Refactor: Handles lifecycle events and migrations.
import { runMigrations } from '../storage/migrations.js';
import { loadDebugFlag, debugLog } from '../utils/debug.js';

if (typeof chrome !== 'undefined') {
  chrome.runtime.onInstalled.addListener(async (details) => {
    await runMigrations();
    await loadDebugFlag();
    debugLog('background.installed', details.reason);
    setupContextMenus();
  });

  chrome.runtime.onStartup?.addListener(async () => {
    await runMigrations();
    await loadDebugFlag();
    debugLog('background.startup');
  });
}

function setupContextMenus() {
  if (!chrome.contextMenus?.create) {
    return;
  }

  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({
      id: 'saveToClipboard',
      title: 'Save to Smart Clipboard',
      contexts: ['selection']
    });
    chrome.contextMenus.create({
      id: 'savePageUrlToClipboard',
      title: 'Save Page URL to Smart Clipboard',
      contexts: ['page']
    });
  });
}
