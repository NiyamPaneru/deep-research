// GPT-5 Refactor: Background message listeners.
import { debugLog } from '../utils/debug.js';
import hfClient from '../services/hfClient.js';
import tokenStore from '../services/tokenStore.js';
import { verifyLTD, generateContent as supabaseGenerate } from '../services/supabase.js';
import { getRuntimeHfToken } from '../config.js';
import { getCurrentTier, setCurrentTier } from '../services/tiers/index.js';

const HISTORY_STORAGE_KEY = 'clipboardHistory';
const LICENSE_STORAGE_KEY = 'userLicense';
const HISTORY_LIMIT = 50;
const HISTORY_TEXT_LIMIT = 8000;

if (typeof chrome !== 'undefined') {
  chrome.runtime.onMessage.addListener((request, _sender, sendResponse) => {
    (async () => {
      try {
        const action = request?.action || request?.type;
        switch (action) {
          case 'generate':
            await handleGenerate(request, sendResponse);
            return;
          case 'generateContent':
            sendResponse(await handleSupabaseGenerate(request));
            return;
          case 'getClipboardHistory':
            sendResponse(await getClipboardHistory());
            return;
          case 'save_clipboard':
            sendResponse(await handleSaveClipboard(request));
            return;
          case 'clearHistory':
            sendResponse(await clearClipboardHistory());
            return;
          case 'deleteHistoryItem':
            sendResponse(await deleteHistoryItem(request));
            return;
          case 'updateHistoryItem':
            sendResponse(await updateHistoryItem(request));
            return;
          case 'setToken':
            sendResponse(await handleSetToken(request));
            return;
          case 'getToken':
            sendResponse(await handleGetToken());
            return;
          case 'clearToken':
            sendResponse(await handleClearToken());
            return;
          case 'verifyLicense':
          case 'verifyLicenseKey':
            sendResponse(await handleLicenseActivation(request));
            return;
          case 'getTier':
            sendResponse({ ok: true, tier: await getCurrentTier() });
            return;
          case 'ping':
            sendResponse({ ok: true, ts: Date.now() });
            return;
          default:
            sendResponse({ ok: false, code: 'UNKNOWN_ACTION' });
        }
      } catch (error) {
        debugLog('background.listenerError', error?.message || error);
        sendResponse({ ok: false, error: error?.message || 'Unknown error.' });
      }
    })();
    return true;
  });

  chrome.contextMenus?.onClicked?.addListener(async (info, tab) => {
    if (info.menuItemId === 'saveToClipboard' && info.selectionText) {
      await saveToHistory(info.selectionText, { source: 'context-menu' });
    }
    if (info.menuItemId === 'savePageUrlToClipboard' && tab?.url) {
      const text = tab.title ? `${tab.url}\nTitle: ${tab.title}` : tab.url;
      await saveToHistory(text, { source: 'context-menu' });
    }
  });
}

async function handleGenerate(request, sendResponse) {
  const { token, source } = await getEffectiveToken();
  if (!token) {
    sendResponse({ outputs: [], error: 'AI is temporarily unavailable. Try again soon.', code: 'HF_TOKEN_MISSING' });
    return;
  }

  const prompt = sanitizeText(String(request.input || '')).slice(0, 4000);
  const desired = clampResponses(request.responses);
  const modelName = typeof request.model === 'string' && request.model.trim() ? request.model.trim() : 'gpt2';

  try {
    const generation = await hfClient.generate(modelName, token, prompt, {
      parameters: {
        num_return_sequences: desired,
        max_new_tokens: 60,
        return_full_text: false,
        temperature: 0.8
      }
    });

    if (generation?.ok === false) {
      const friendly = generation?.error?.friendlyMessage || generation?.error?.message || 'Quota exceeded. Try again later.';
      const code = generation?.error?.code || 'HF_QUOTA_EXCEEDED';
      sendResponse({ outputs: [], error: friendly, code, remainingQuota: generation?.remaining ?? null });
      return;
    }

    const outputs = extractOutputs(generation?.data, desired);
    if (!outputs.length) {
      sendResponse({ outputs: [], error: 'Model returned no output.', code: 'HF_EMPTY_RESPONSE', remainingQuota: generation?.remaining ?? null });
      return;
    }

    sendResponse({
      outputs,
      error: null,
      code: null,
      remainingQuota: generation?.remaining ?? null,
      tokenSource: source
    });
  } catch (error) {
    const mapped = mapModelError(error);
    debugLog('background.generateFailed', mapped.code);
    sendResponse({ outputs: [], error: mapped.message, code: mapped.code });
  }
}

async function handleSupabaseGenerate(request) {
  const prompt = sanitizeText(String(request?.prompt || '')).slice(0, 4000);
  if (!prompt) {
    return { success: false, error: 'Prompt is required.' };
  }

  const useCase = sanitizeText(String(request?.useCase || 'general')) || 'general';

  try {
    const response = await supabaseGenerate(prompt, useCase);
    const outputs = Array.isArray(response?.outputs) ? response.outputs.filter(Boolean).map(formatModelOutput) : [];
    const payloadOutputs = outputs.length ? outputs : normalizeGenerateResponse(response);
    return { success: true, outputs: payloadOutputs, content: payloadOutputs };
  } catch (error) {
    debugLog('background.supabaseGenerateFailed', error?.message || error);
    return { success: false, error: error?.message || 'Generation failed.' };
  }
}

async function handleSaveClipboard(request) {
  const text = sanitizeText(String(request?.text || '')).slice(0, HISTORY_TEXT_LIMIT);
  if (!text) {
    return { status: 'skipped' };
  }
  const item = await saveToHistory(text, { source: request?.source });
  return { status: item ? 'saved' : 'skipped', item };
}

async function handleSetToken(request) {
  const token = typeof request?.token === 'string' ? request.token.trim() : '';
  try {
    const result = await tokenStore.setToken(token);
    return result || { ok: true };
  } catch (error) {
    debugLog('background.setTokenFailed', error?.message || error);
    return { ok: false, code: 'TOKEN_STORE_FAILED', message: 'Unable to store token on this device.' };
  }
}

async function handleGetToken() {
  const { token, source } = await getEffectiveToken();
  const hasUserToken = source === 'user';
  const hasSharedToken = source === 'shared';
  return {
    ok: true,
    token: hasUserToken ? token : null,
    hasToken: Boolean(token),
    hasUserToken,
    hasSharedToken,
    source
  };
}

async function handleClearToken() {
  try {
    await tokenStore.clearToken();
    return { ok: true };
  } catch (error) {
    debugLog('background.clearTokenFailed', error?.message || error);
    return { ok: false };
  }
}

async function clearClipboardHistory() {
  await chrome.storage.local.set({ [HISTORY_STORAGE_KEY]: [] });
  return { success: true };
}

async function deleteHistoryItem(payload = {}) {
  const result = await chrome.storage.local.get([HISTORY_STORAGE_KEY]);
  const history = Array.isArray(result[HISTORY_STORAGE_KEY]) ? result[HISTORY_STORAGE_KEY] : [];

  const numericId = parseNumericId(payload.id);
  const removalText = typeof payload.text === 'string' ? payload.text : '';

  const filtered = history.filter((item) => {
    if (numericId !== null) {
      return Number(item.id) !== numericId;
    }
    if (removalText) {
      return item.text !== removalText;
    }
    return true;
  });

  await chrome.storage.local.set({ [HISTORY_STORAGE_KEY]: filtered });
  return { success: true, removed: history.length > filtered.length, history: filtered };
}

async function updateHistoryItem(payload = {}) {
  const numericId = parseNumericId(payload.id);
  const text = sanitizeText(String(payload.text || '')).slice(0, HISTORY_TEXT_LIMIT);
  if (!text) {
    return { success: false, error: 'empty' };
  }

  const result = await chrome.storage.local.get([HISTORY_STORAGE_KEY]);
  const history = Array.isArray(result[HISTORY_STORAGE_KEY]) ? result[HISTORY_STORAGE_KEY] : [];
  const index = history.findIndex((item) => (numericId !== null ? Number(item.id) === numericId : item.text === text));
  if (index === -1) {
    return { success: false, error: 'not_found' };
  }

  const updatedItem = {
    ...history[index],
    text,
    timestamp: new Date().toISOString()
  };

  history[index] = updatedItem;
  const limit = await getHistoryLimit();
  const deduped = history
    .filter((entry, position) => position === history.findIndex((candidate) => candidate.id === entry.id))
    .map((entry) => ({
      ...entry,
      text: sanitizeText(String(entry.text || '')).slice(0, HISTORY_TEXT_LIMIT)
    }))
    .slice(0, limit);

  await chrome.storage.local.set({ [HISTORY_STORAGE_KEY]: deduped });
  return { success: true, item: updatedItem, history: deduped };
}

async function getClipboardHistory() {
  const result = await chrome.storage.local.get([HISTORY_STORAGE_KEY]);
  return { history: Array.isArray(result[HISTORY_STORAGE_KEY]) ? result[HISTORY_STORAGE_KEY] : [] };
}

async function handleLicenseActivation(request = {}) {
  const licenseKey = typeof request.licenseKey === 'string' ? request.licenseKey.trim() : '';
  const email = typeof request.email === 'string' ? request.email.trim() : '';
  if (!licenseKey) {
    return { ok: false, error: 'License key required.' };
  }

  try {
    const result = await verifyLTD(licenseKey, email);
    const tier = result?.tier || 'free';
    await setCurrentTier(tier);
    await persistLicense({
      key: licenseKey,
      email,
      tier,
      status: result?.status || 'valid',
      verifiedAt: new Date().toISOString()
    });
    return { ok: true, tier, status: result?.status || 'valid', meta: result?.meta || null };
  } catch (error) {
    debugLog('background.verifyLicenseFailed', error?.message || error);
    return { ok: false, error: error?.message || 'License verification failed.' };
  }
}

async function saveToHistory(text, meta = {}) {
  const item = {
    id: Date.now(),
    text,
    timestamp: new Date().toISOString(),
    meta
  };

  const result = await chrome.storage.local.get([HISTORY_STORAGE_KEY]);
  const history = Array.isArray(result[HISTORY_STORAGE_KEY]) ? result[HISTORY_STORAGE_KEY] : [];
  const updated = [item, ...history].slice(0, HISTORY_LIMIT);
  await chrome.storage.local.set({ [HISTORY_STORAGE_KEY]: updated });

  try {
    chrome.runtime?.sendMessage?.({ action: 'clipboard:saved', item });
  } catch (_error) {
    // best effort broadcast
  }

  return item;
}

async function getEffectiveToken() {
  const userToken = await readUserToken();
  if (userToken) {
    return { token: userToken, source: 'user' };
  }

  const shared = await getRuntimeHfToken();
  if (shared) {
    return { token: shared, source: 'shared' };
  }

  return { token: null, source: null };
}

async function readUserToken() {
  try {
    const token = await tokenStore.getToken();
    if (token) {
      return token;
    }
  } catch (error) {
    debugLog('background.userTokenReadFailed', error?.message || error);
  }

  if (!chrome?.storage?.local?.get) {
    return null;
  }

  try {
    const legacy = await new Promise((resolve) => {
      try {
        chrome.storage.local.get(['userHfToken'], (value) => {
          if (chrome.runtime?.lastError) {
            resolve(null);
            return;
          }
          resolve(typeof value?.userHfToken === 'string' ? value.userHfToken.trim() : null);
        });
      } catch (_error) {
        resolve(null);
      }
    });

    if (legacy) {
      await tokenStore.setToken(legacy);
      chrome.storage.local.remove?.(['userHfToken']);
      return legacy;
    }
  } catch (error) {
    debugLog('background.legacyTokenMigrationFailed', error?.message || error);
  }

  return null;
}

async function persistLicense(payload) {
  try {
    await chrome.storage.local.set({ [LICENSE_STORAGE_KEY]: payload });
  } catch (error) {
    debugLog('background.persistLicenseFailed', error?.message || error);
  }
}

function clampResponses(responses) {
  const numeric = Number.parseInt(responses, 10);
  if (!Number.isFinite(numeric)) {
    return 1;
  }
  return Math.min(Math.max(numeric, 1), 5);
}

function parseNumericId(value) {
  const numeric = typeof value === 'string' ? Number.parseInt(value, 10) : value;
  return Number.isFinite(numeric) ? numeric : null;
}

async function getHistoryLimit() {
  if (!chrome?.storage?.sync?.get) {
    return HISTORY_LIMIT;
  }

  try {
    const result = await new Promise((resolve) => {
      try {
        chrome.storage.sync.get(['smartClipboard_historyLimit'], (items) => {
          if (chrome.runtime?.lastError) {
            resolve({});
            return;
          }
          resolve(items || {});
        });
      } catch (_error) {
        resolve({});
      }
    });

    const parsed = Number.parseInt(result.smartClipboard_historyLimit, 10);
    return Number.isFinite(parsed) && parsed > 0 ? parsed : HISTORY_LIMIT;
  } catch (_error) {
    return HISTORY_LIMIT;
  }
}

function sanitizeText(text) {
  if (typeof text !== 'string') {
    return '';
  }
  return text.replace(/\s+/g, ' ').replace(/[\u0000-\u001F\u007F]+/g, ' ').trim();
}

function formatModelOutput(raw) {
  const text = sanitizeText(String(raw ?? ''));
  if (!text) {
    return '';
  }
  return text.length > 400 ? `${text.slice(0, 397)}...` : text;
}

function extractOutputs(payload, desired) {
  const limit = Math.max(1, desired);
  const collected = [];
  if (Array.isArray(payload)) {
    payload.forEach((entry) => {
      if (collected.length >= limit) {
        return;
      }
      const text = typeof entry === 'string' ? entry : entry?.generated_text || entry?.text || '';
      const normalized = formatModelOutput(text);
      if (normalized) {
        collected.push(normalized);
      }
    });
  } else if (payload && typeof payload === 'object') {
    const normalized = formatModelOutput(payload.generated_text || payload.text || '');
    if (normalized) {
      collected.push(normalized);
    }
  }
  return collected.slice(0, limit);
}

function normalizeGenerateResponse(response) {
  if (!response || typeof response !== 'object') {
    return [];
  }

  const candidates = [];
  if (typeof response.content === 'string') {
    candidates.push(response.content);
  }
  if (typeof response.result === 'string') {
    candidates.push(response.result);
  }
  return candidates.map(formatModelOutput).filter(Boolean);
}

function mapModelError(error) {
  const code = error?.code || error?.message || 'HF_NETWORK_ERROR';
  switch (code) {
    case 'HF_INVALID_TOKEN':
      return { code, message: 'Invalid Hugging Face token — update it in Settings.' };
    case 'HF_MODEL_NOT_FOUND':
      return { code, message: "Model not found — try 'gpt2' or verify the model name." };
    case 'HF_EMPTY_RESPONSE':
      return { code, message: 'The model returned no output. Try again.' };
    case 'HF_RATE_LIMITED':
      return { code, message: 'Rate limited by Hugging Face. Wait a few seconds and retry.' };
    case 'HF_TIMEOUT':
      return { code, message: 'The model request timed out. Try again.' };
    case 'HF_SERVER_ERROR':
      return { code, message: 'Hugging Face servers are busy. Try again shortly.' };
    default:
      return { code: 'HF_NETWORK_ERROR', message: 'Network error contacting Hugging Face. Check your connection and retry.' };
  }
}
