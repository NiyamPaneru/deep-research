#!/usr/bin/env node
/* eslint-disable no-console */
// GPT-5 Refactor: Build script bundles background worker for MV3 compliance.
const path = require('path');
const fs = require('fs');
const esbuild = require('esbuild');

async function build() {
  const projectRoot = process.cwd();
  const entry = path.join(projectRoot, 'background.sw.entry.js');
  const outFile = path.join(projectRoot, 'background-sw.js');

  if (!fs.existsSync(entry)) {
    console.error('Background entry file missing:', entry);
    process.exit(1);
  }

  try {
    await esbuild.build({
      entryPoints: [entry],
      bundle: true,
      format: 'esm',
      target: ['chrome117'],
      outfile: outFile,
      sourcemap: false,
      minify: false,
      platform: 'browser',
      define: {
        'process.env.NODE_ENV': '"production"'
      }
    });
    console.log('Bundled background worker to', outFile);
  } catch (error) {
    console.error('Failed to bundle background worker:', error);
    process.exit(1);
  }
}

build();
