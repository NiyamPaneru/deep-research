# Release Checklist

Manual steps required before shipping Smart Clipboard AI:

1. **Supabase Functions**
   - Deploy updated Edge Functions (`verify_ltd`, `generate`, etc.).
   - Ensure environment variables (service role key, RocketHub credentials) are set in Supabase dashboard.
2. **Token Rotation**
   - Rotate Hugging Face shared token and update secure storage.
   - Rotate Supabase anon/service keys if necessary.
3. **RocketHub LTD CSV**
   - Upload the latest license CSV to the validation service.
   - Verify sample license succeeds and revoked key fails.
4. **Chrome Web Store**
   - Run `npm run build` then `npm run package`.
   - Upload `dist/` package to the Chrome Web Store Developer Console.
   - Provide release notes summarizing tier changes and bug fixes.
5. **Google OAuth**
   - Confirm OAuth consent screen and scopes for Google Sign-In remain verified.
   - Ensure redirect URIs match `AUTH_REDIRECT_URL`.
6. **Testing**
   - Execute `npm test` and manual smoke tests in Chrome (free, LTD, pro flows).
   - Validate migrations on existing user profile (localStorage -> chrome.storage).
7. **Post-Release Monitoring**
   - Monitor Supabase logs and quota metrics.
   - Enable debug flag for targeted users if troubleshooting needed.
8. **TODO**
   - Add ESLint/Prettier configuration in future sprint for consistent linting.
