# Smart Clipboard AI

A Chrome extension that enhances your clipboard with AI-powered text generation, smart history management, and personalized humor.

## Features

### 🧠 AI Text Generation
- Generate text using Hugging Face models
- BYOK (Bring Your Own Key) support
- Fallback to shared tokens
- 3 free generations daily

### 📋 Smart Clipboard Management
- Auto-save copied text (Ctrl+C detection)
- Searchable history with fuzzy matching
- Persistent storage across sessions
- Quick access popup interface

### 😄 Personalized Humor
- Context-aware jokes and messages
- Customizable humor settings (playful/neutral/off)
- Gen-Z style humor with personality
- Jokes for different app states

### ⚙️ Customization
- Personalization settings
- Auto-save toggle
- Humor preferences
- Token management

## Quick Start

1. **Install Extension**: Load unpacked in Chrome Developer Mode
2. **Set Up AI** (Optional): Add your Hugging Face token in settings
3. **Enable Auto-save**: Go to Settings → Personalization → Auto-save clipboard
4. **Start Using**: Copy text anywhere, access via extension popup

## Project Structure

```
├── manifest.json          # Extension manifest
├── popup.html/js/css      # Main popup interface
├── settings.html/js       # Settings page
├── history.html/js        # Clipboard history
├── background/            # Service worker
├── content/               # Content scripts
├── services/              # Core services
├── src/humor/             # Humor system
└── tests/                 # Test files
```

## Development

```bash
npm install
npm test
npm run build
```

## License

MIT License - See LICENSE file for details