'use strict';

(function initPopup(globalScope) {
  if (typeof document === 'undefined') {
    return;
  }

  const flow = typeof globalScope.generateFlow === 'object' && globalScope.generateFlow
    ? globalScope.generateFlow
    : { startCall: () => {}, endCall: () => {} };
  const clipboardManager = globalScope.clipboardManager || null;

  let humorManager = null;
  let humorUnsubscribe = null;
  const humorState = {
    latest: null,
    enabled: true
  };
  const THEME_STORAGE_KEY = 'smart_clipboard_theme';

  const state = {
    history: [],
    latest: null,
    monitoring: false,
    aiOutputs: [],
    hasUserToken: false,
    hasSharedToken: false,
    demoMode: false,
    lastRenderedClipboardId: null,
    humorEnabled: true,
    activeJoke: null,
    emptyStateJoke: null,
    emptyStateFetch: null
  };

  const dom = {};
  const timers = {
    status: null,
    aiStatus: null
  };

  function logDebug(event, payload) {
    try {
      if (typeof globalScope.debugLog === 'function') {
        globalScope.debugLog(event, payload);
      }
    } catch (_error) {
      // swallow logging failures
    }
  }

  document.addEventListener('DOMContentLoaded', initialize);

  function initialize() {
    cacheDom();
    bindEvents();
    prepareMonitoringControls();
    initializeStatusRegions();
    applySavedTheme();
    observeRuntimeMessages();
  void initializeHumor();

    loadHistory();
    checkTokenStatus();
    updateCopyPreviewAvailability(false);

    if (typeof window !== 'undefined' && window.addEventListener) {
      window.addEventListener('focus', () => {
        void checkTokenStatus();
      });
      window.addEventListener('unload', () => {
        if (typeof humorUnsubscribe === 'function') {
          humorUnsubscribe();
          humorUnsubscribe = null;
        }
        humorManager?.destroy?.();
      });
    }
  }

  function cacheDom() {
    dom.themeToggle = document.getElementById('theme-btn');
    dom.settingsAction = document.getElementById('settings-btn');
    dom.historyAction = document.getElementById('history-btn');
  dom.historyShortcut = document.getElementById('open-history-btn');

    dom.clipboardPreview = document.getElementById('clipboard-preview');
    dom.clipboardText = document.getElementById('clipboard-text');
    dom.clipboardTimestamp = document.getElementById('clipboard-time');
    dom.copyButton = document.getElementById('copy-btn');


    dom.prompt = document.getElementById('ai-prompt');
    dom.generateButton = document.getElementById('generate-btn');
    dom.generateSpinner = document.getElementById('generate-spinner');
    dom.clearPrompt = document.getElementById('clear-prompt-btn');
    dom.quickChipContainer = document.querySelector('.quick-chips');

    dom.aiStatusBadge = document.getElementById('ai-status-badge');
    dom.aiMessage = document.getElementById('ai-message');
    dom.aiOutputsSection = document.getElementById('ai-outputs');
    dom.aiOutputList = document.getElementById('outputs-list');
    dom.clearOutputs = document.getElementById('clear-outputs-btn');

    dom.statusText = document.getElementById('status-text');
    dom.popupHumorText = document.getElementById('popup-humor-text');
    dom.moveToHistoryBtn = document.getElementById('move-to-history-btn');
    dom.metricClipboardLength = document.getElementById('metric-clipboard-length');
    dom.metricReadingTime = document.getElementById('metric-reading-time');

    if (dom.generateSpinner && !dom.generateSpinner.dataset.spinner) {
      dom.generateSpinner.dataset.spinner = 'generate';
    }
  }
  function bindEvents() {
    dom.themeToggle?.addEventListener('click', handleThemeToggle);

    dom.copyButton?.addEventListener('click', () => {
      void handleCopyPreview();
    });



    dom.generateButton?.addEventListener('click', () => {
      void handleGenerate();
    });

    dom.clearPrompt?.addEventListener('click', handleClearPrompt);
    dom.aiOutputList?.addEventListener('click', handleOutputAction);
    dom.clearOutputs?.addEventListener('click', handleClearOutputs);
    dom.quickChipContainer?.addEventListener('click', handleChipClick);

    dom.historyAction?.addEventListener('click', () => openExtensionPage('history.html'));
    dom.historyShortcut?.addEventListener('click', () => openExtensionPage('history.html'));
    dom.settingsAction?.addEventListener('click', () => openExtensionPage('settings.html'));
    dom.moveToHistoryBtn?.addEventListener('click', handleMoveToHistory);
  }
  function prepareMonitoringControls() {
    // Auto-save removed for privacy and storage concerns
  }

  async function applySavedTheme() {
    const stored = await readStoredTheme();
    const preferred = stored || detectPreferredTheme();
    setTheme(preferred);
  }
  function detectPreferredTheme() {
    try {
      return globalScope.matchMedia && globalScope.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
    } catch (_error) {
      return 'light';
    }
  }
  function setTheme(candidate) {
    const theme = candidate === 'dark' ? 'dark' : 'light';
    document.documentElement?.setAttribute('data-theme', theme);
    document.body?.setAttribute('data-theme', theme);
    updateThemeToggle(theme);
    void persistTheme(theme);
  }
  function updateThemeToggle(theme) {
    if (!dom.themeToggle) {
      return;
    }
    const isDark = theme === 'dark';
    dom.themeToggle.textContent = isDark ? '🌞' : '🌙';
    dom.themeToggle.setAttribute('aria-label', isDark ? 'Switch to light theme' : 'Switch to dark theme');
  }
  async function handleThemeToggle() {
    const current = document.documentElement?.getAttribute('data-theme') || 'light';
    const next = current === 'dark' ? 'light' : 'dark';
    setTheme(next);
  }
  async function readStoredTheme() {
    if (typeof chrome === 'undefined' || !chrome.storage?.local) {
      try {
        return globalScope.localStorage?.getItem(THEME_STORAGE_KEY) || null;
      } catch (_error) {
        return null;
      }
    }

    return new Promise((resolve) => {
      try {
        chrome.storage.local.get({ [THEME_STORAGE_KEY]: null }, (result) => {
          if (chrome.runtime?.lastError) {
            resolve(null);
            return;
          }
          resolve(result?.[THEME_STORAGE_KEY] || null);
        });
      } catch (_error) {
        resolve(null);
      }
    });
  }

  async function persistTheme(theme) {
    if (typeof chrome === 'undefined' || !chrome.storage?.local) {
      try {
        globalScope.localStorage?.setItem(THEME_STORAGE_KEY, theme);
      } catch (_error) {
        // ignore persistence failures
      }
      return;
    }

    try {
      await new Promise((resolve) => {
        chrome.storage.local.set({ [THEME_STORAGE_KEY]: theme }, () => resolve());
      });
    } catch (_error) {
      // ignore persistence failures
    }
  }
  function observeRuntimeMessages() {
    if (typeof chrome === 'undefined' || !chrome.runtime?.onMessage?.addListener) {
      return;
    }

    chrome.runtime.onMessage.addListener((message) => {
      if (message?.action === 'clipboard:saved' && message.item) {
        handleIncomingHistoryItem(message.item);
      }

      if (message?.action === 'updateMonitoring') {
        setMonitoringState(Boolean(message.enabled));
      }
    });
  }

  async function initializeHumor() {
    if (!dom.popupHumorText) {
      return;
    }

    if (!globalScope.HumorManager || !globalScope.humorManager) {
      dom.popupHumorText.textContent = '';
      dom.popupHumorText.classList.add('hidden');
      return;
    }

    try {
      humorManager = new globalScope.HumorManager({ channel: 'daily' });
      await humorManager.init();
      humorUnsubscribe = humorManager.watch(handleHumorTick, { replay: true });
      ensureEmptyStateHumor();
    } catch (_error) {
      humorManager = null;
      dom.popupHumorText.classList.add('hidden');
    }
  }

  function handleHumorTick(payload) {
    state.humorEnabled = Boolean(payload?.settings?.humorEnabled);
    state.activeJoke = payload?.joke || null;
    renderHumor();
  }

  function renderHumor() {
    if (!dom.popupHumorText) {
      return;
    }

    if (!state.humorEnabled || !state.activeJoke?.text) {
      dom.popupHumorText.textContent = '';
      dom.popupHumorText.classList.add('hidden');
      return;
    }

    dom.popupHumorText.textContent = state.activeJoke.text;
    dom.popupHumorText.classList.remove('hidden');
  }

  function ensureEmptyStateHumor() {
    if (!globalScope.humorManager || state.emptyStateFetch) {
      return;
    }

    state.emptyStateFetch = globalScope.humorManager.getJoke('empty-state', { force: false })
      .then((joke) => {
        if (joke && joke.text) {
          state.emptyStateJoke = joke;
          if (!state.latest) {
            renderClipboardPreview();
          }
        }
      })
      .finally(() => {
        state.emptyStateFetch = null;
      });
  }







  async function loadHistory() {
    const response = await sendMessage('getClipboardHistory');
    const rawHistory = Array.isArray(response?.history) ? response.history : [];
    const normalizedHistory = rawHistory
      .map((entry) => normalizeHistoryItem(entry))
      .filter(Boolean);
    state.history = normalizedHistory;
    state.latest = normalizedHistory.length ? normalizedHistory[0] : null;
    renderClipboardPreview();
  }
  function handleIncomingHistoryItem(item) {
    const normalized = normalizeHistoryItem(item);
    if (!normalized) {
      return;
    }

    state.history = insertOrUpdateHistory(state.history, normalized);
    state.latest = state.history[0] || null;
    renderClipboardPreview();
  }
  function normalizeHistoryItem(item) {
    if (!item) {
      return null;
    }
    const text = typeof item.text === 'string' ? item.text : '';
    if (!text.trim()) {
      return null;
    }
    const id = typeof item.id === 'number' || typeof item.id === 'string' ? item.id : Date.now();
    const timestamp = item.timestamp instanceof Date ? item.timestamp.toISOString() : (item.timestamp || new Date().toISOString());
    const source = typeof item.source === 'string' && item.source.trim() ? item.source.trim() : 'unknown';

    return {
      id,
      text,
      timestamp,
      source
    };
  }
  function insertOrUpdateHistory(list, entry) {
    const next = Array.isArray(list) ? list.slice(0) : [];
    const existingIndex = next.findIndex((item) => item.id === entry.id);
    if (existingIndex !== -1) {
      next.splice(existingIndex, 1);
    }
    next.unshift(entry);
    return next.slice(0, 50);
  }
  function renderClipboardPreview() {
    if (!dom.clipboardPreview) {
      return;
    }

    const item = state.latest;
    const hasText = Boolean(item?.text);
    dom.clipboardPreview.classList.toggle('has-content', hasText);
    
    if (dom.clipboardText) {
      if (hasText) {
        dom.clipboardText.textContent = item.text;
        dom.clipboardText.classList.add('has-content');
        dom.clipboardText.classList.remove('is-joke');
      } else {
        const fallback = state.emptyStateJoke?.text || 'Nothing in clipboard yet';
        dom.clipboardText.textContent = fallback;
        dom.clipboardText.classList.remove('has-content');
        dom.clipboardText.classList.toggle('is-joke', Boolean(state.emptyStateJoke));
        ensureEmptyStateHumor();
      }
    }

    if (dom.clipboardTimestamp) {
      dom.clipboardTimestamp.textContent = hasText ? formatTimestamp(item.timestamp) : '';
    }

    if (dom.moveToHistoryBtn) {
      dom.moveToHistoryBtn.classList.toggle('hidden', !hasText);
    }

    if (hasText && item?.id !== state.lastRenderedClipboardId) {
      flashClipboardPreview();
      state.lastRenderedClipboardId = item.id;
    }

    if (!hasText) {
      state.lastRenderedClipboardId = null;
    }

    updateCopyPreviewAvailability(hasText);
    updateClipboardMetrics();
  }

  function flashClipboardPreview() {
    if (!dom.clipboardPreview) {
      return;
    }

    dom.clipboardPreview.classList.remove('is-updated');
    // Force reflow so the animation restarts even for identical IDs
    void dom.clipboardPreview.offsetWidth;
    dom.clipboardPreview.classList.add('is-updated');
  }
  function formatTimestamp(timestamp) {
    if (!timestamp) {
      return 'Saved just now';
    }

    try {
      const date = new Date(timestamp);
      if (Number.isNaN(date.getTime())) {
        return 'Saved just now';
      }

      const diff = Date.now() - date.getTime();
      if (diff < 45 * 1000) {
        return 'Saved just now';
      }
      if (diff < 60 * 60 * 1000) {
        const minutes = Math.round(diff / (60 * 1000));
        return minutes === 1 ? 'Saved 1 minute ago' : `Saved ${minutes} minutes ago`;
      }
      if (diff < 24 * 60 * 60 * 1000) {
        const hours = Math.round(diff / (60 * 60 * 1000));
        return hours === 1 ? 'Saved 1 hour ago' : `Saved ${hours} hours ago`;
      }
      return `Saved ${date.toLocaleString()}`;
    } catch (_error) {
      return 'Saved just now';
    }
  }
  function updateCopyPreviewAvailability(hasText) {
    if (!dom.copyButton) {
      return;
    }
    const disabled = !hasText;
    dom.copyButton.disabled = disabled;
    dom.copyButton.setAttribute('aria-disabled', String(disabled));
  }

  function updateClipboardMetrics() {
    const latestText = state.latest?.text || '';

    if (dom.metricClipboardLength) {
      const length = latestText.length;
      dom.metricClipboardLength.textContent = `${length} chars`;
    }

    if (dom.metricReadingTime) {
      const words = latestText.trim() ? latestText.trim().split(/\s+/).length : 0;
      const minutesFloat = words / 200; // 200 words per minute baseline
      const totalSeconds = Math.round(minutesFloat * 60);
      let label = '≈0s read';
      if (totalSeconds >= 60) {
        const mins = Math.floor(totalSeconds / 60);
        const secs = totalSeconds % 60;
        label = secs ? `≈${mins}m ${secs}s read` : `≈${mins}m read`;
      } else if (totalSeconds > 0) {
        label = `≈${totalSeconds}s read`;
      }
      dom.metricReadingTime.textContent = label;
    }
  }


  async function handleCopyPreview() {
    if (!state.latest || !state.latest.text) {
      renderStatus('Nothing to copy yet', true);
      return;
    }

    const success = await copyText(state.latest.text);
    renderStatus(success ? 'Copied latest item' : 'Copy failed', !success);
  }
  async function copyText(text) {
    if (!text) {
      return false;
    }

    try {
      if (clipboardManager?.copyToClipboard) {
        const result = await clipboardManager.copyToClipboard(text);
        return result !== false;
      }

      if (navigator.clipboard?.writeText) {
        await navigator.clipboard.writeText(text);
        return true;
      }
    } catch (error) {
      logDebug('popup.clipboardWriteFailed', error?.message || error);
    }

    return false;
  }
  function setPromptValue(value) {
    if (!dom.prompt) {
      return;
    }
    dom.prompt.value = value;
    if (value) {
      dom.prompt.focus();
    }
  }
  function handleClearPrompt() {
    setPromptValue('');
    renderAiStatus('Prompt cleared.', false, { badge: 'ready' });
  }
  async function checkTokenStatus() {
    const response = await sendMessage('getToken');
    logDebug('popup.tokenStatusResponse', { hasToken: Boolean(response?.hasToken), source: response?.source });

    const hasUserToken = Boolean(response?.hasUserToken);
    const hasSharedToken = Boolean(response?.hasSharedToken);
    const hasToken = hasUserToken || hasSharedToken;

    state.hasUserToken = hasUserToken;
    state.hasSharedToken = hasSharedToken;
    state.demoMode = !hasUserToken && hasSharedToken;

    setGenerateAvailability(hasToken);

    if (!hasToken) {
      renderAiStatus('No AI token found. Add your Hugging Face token in Settings.', true, { persistent: true, badge: 'disabled' });
    } else {
      const tokenType = hasUserToken ? 'your token' : 'shared token';
      renderAiStatus(`AI ready with ${tokenType}. Type a prompt to get started.`, false, { persistent: true, badge: 'ready' });
    }
  }
  function updateDemoBadge() {
    // Demo badge removed from UI
  }
  function setGenerateAvailability(isEnabled) {
    if (!dom.generateButton) {
      return;
    }
    const enabled = Boolean(isEnabled);
    dom.generateButton.disabled = !enabled;
    dom.generateButton.setAttribute('aria-disabled', String(!enabled));
    if (!enabled) {
      dom.generateButton.title = 'Add a Hugging Face key in Settings to enable AI.';
    } else {
      dom.generateButton.removeAttribute('title');
    }
  }
  async function handleGenerate() {
    const prompt = (dom.prompt?.value || '').trim();
    if (!prompt) {
      renderAiStatus('Add a prompt or load the latest clipboard item first.', true, { badge: 'error' });
      return;
    }

    if (!state.hasUserToken && !state.hasSharedToken) {
      renderAiStatus('Add your Hugging Face key from Settings to run AI.', true, { persistent: true, badge: 'disabled' });
      return;
    }

    if (typeof chrome === 'undefined' || !chrome.runtime?.sendMessage) {
      renderAiStatus('AI is unavailable in this environment.', true, { persistent: true, badge: 'error' });
      return;
    }

    flow.startCall(dom.generateButton);
    renderAiStatus('Generating…', false, { badge: 'busy' });
    logDebug('popup.generateRequested', { promptLength: prompt.length });

    try {
      const response = await sendMessage('generate', { input: prompt, responses: 2 });
      logDebug('popup.generateResponse', { hasError: Boolean(response?.error), code: response?.code });
      
      if (response?.error) {
        logDebug('popup.generateRejected', { message: response.error, code: response.code });
        const mapped = mapGenerationError(response);
        if (mapped.disable) {
          state.hasUserToken = false;
          state.hasSharedToken = state.demoMode;
          setGenerateAvailability(false);
        }
        renderAiStatus(mapped.message, true, { persistent: mapped.persistent, badge: 'error' });
        return;
      }

      const outputs = Array.isArray(response?.outputs) ? response.outputs.filter(Boolean) : [];
      logDebug('popup.generateOutputs', { count: outputs.length });
      
      if (!outputs.length) {
        renderAiStatus('No output returned. Try a longer or clearer prompt.', true, { badge: 'error' });
        state.aiOutputs = [];
        renderOutputs(state.aiOutputs);
        return;
      }

      state.aiOutputs = outputs.map((text, index) => ({
        id: Date.now() + index,
        text: String(text)
      }));

      renderOutputs(state.aiOutputs);

      if (typeof response?.remainingQuota === 'number') {
        renderStatus(`Demo uses left: ${response.remainingQuota}`);
      }

      renderAiStatus('AI generation completed successfully', false, { badge: 'ready' });
    } catch (error) {
      logDebug('popup.generateException', error?.message || error);
      const mapped = mapGenerationError(error);
      if (mapped.disable) {
        setGenerateAvailability(false);
      }
      renderAiStatus(mapped.message || 'The AI service is unreachable right now.', true, { persistent: mapped.persistent, badge: 'error' });
    } finally {
      flow.endCall(dom.generateButton);
    }
  }
  function mapGenerationError(payload) {
    if (!payload) {
      return { message: 'Generation failed. Try again.', persistent: false, disable: false, code: null };
    }

    const code = typeof payload === 'object' && payload !== null ? payload.code : null;
    const baseMessage = typeof payload === 'object' && payload !== null
      ? (typeof payload.error === 'string' ? payload.error : typeof payload.message === 'string' ? payload.message : '')
      : String(payload);

    switch (code) {
      case 'HF_INVALID_TOKEN':
        return {
          message: 'AI service is temporarily unavailable. Try again in a moment.',
          persistent: false,
          disable: false,
          code
        };
      case 'HF_TOKEN_MISSING':
        return {
          message: 'AI is temporarily unavailable. Try again soon.',
          persistent: true,
          disable: true,
          code
        };
      case 'QUOTA_EXCEEDED':
        return {
          message: 'Free plan limit reached — wait for the 36-hour reset.',
          persistent: true,
          disable: false,
          code
        };
      case 'HF_MODEL_NOT_FOUND':
        return {
          message: "Model not found. Try 'gpt2' or adjust your settings.",
          persistent: false,
          disable: false,
          code
        };
      case 'HF_EMPTY_RESPONSE':
        return {
          message: 'Model returned no output. Try again with a longer prompt.',
          persistent: false,
          disable: false,
          code
        };
      case 'HF_SERVER_ERROR':
        return {
          message: 'Model is busy right now. Try again shortly.',
          persistent: false,
          disable: false,
          code
        };
      case 'HF_NETWORK_ERROR':
        return {
          message: 'Network hiccup reaching Hugging Face. Check your connection and retry.',
          persistent: false,
          disable: false,
          code
        };
      default:
        break;
    }

    if (!baseMessage) {
      return { message: 'Generation failed. Try again.', persistent: false, disable: false, code };
    }

    return { message: baseMessage, persistent: false, disable: false, code };
  }
  function renderOutputs(outputs) {
    if (!dom.aiOutputList) {
      return;
    }

    dom.aiOutputList.innerHTML = '';

    if (!Array.isArray(outputs) || !outputs.length) {
      dom.aiOutputsSection?.classList.add('hidden');
  dom.clearOutputs?.setAttribute('disabled', 'true');
  updateClipboardMetrics();
      return;
    }

    dom.aiOutputsSection?.classList.remove('hidden');
    dom.clearOutputs?.removeAttribute('disabled');

    const fragment = document.createDocumentFragment();
    outputs.forEach((entry, index) => {
      const item = document.createElement('div');
      item.className = 'output-item output-item--enter';
      if (state.demoMode) {
        item.classList.add('output-item--demo');
      }

      const text = document.createElement('div');
      text.className = 'output-text';
      text.textContent = entry.text;
      item.appendChild(text);

      const actions = document.createElement('div');
      actions.className = 'output-actions';

      const copyButton = document.createElement('button');
      copyButton.type = 'button';
      copyButton.className = 'btn btn-secondary btn-copy';
      copyButton.dataset.action = 'copy';
      copyButton.dataset.index = String(index);
      copyButton.textContent = 'Copy';
      actions.appendChild(copyButton);

      const saveButton = document.createElement('button');
      saveButton.type = 'button';
      saveButton.className = 'btn btn-secondary btn-copy';
      saveButton.dataset.action = 'save';
      saveButton.dataset.index = String(index);
      saveButton.textContent = 'Save';
      actions.appendChild(saveButton);

      item.appendChild(actions);
      fragment.appendChild(item);

      item.addEventListener('animationend', () => {
        item.classList.remove('output-item--enter');
      }, { once: true });
    });

  dom.aiOutputList.appendChild(fragment);
  updateClipboardMetrics();
  }
  function handleOutputAction(event) {
    const button = event.target?.closest('button[data-action]');
    if (!button) {
      return;
    }

    const index = Number(button.dataset.index);
    const output = state.aiOutputs[index];
    if (!output) {
      return;
    }

    const action = button.dataset.action;
    if (action === 'copy') {
      void copyAiOutput(output.text);
    } else if (action === 'save') {
      void saveAiOutput(output.text);
    }
  }

  function handleClearOutputs() {
    if (!state.aiOutputs.length) {
      renderStatus('No AI results to clear right now.');
      return;
    }

    state.aiOutputs = [];
    renderOutputs(state.aiOutputs);
    renderAiStatus('AI results cleared.', false, { badge: 'ready' });
  }

  function handleChipClick(event) {
    const chip = event.target?.closest('.chip');
    if (!chip) {
      return;
    }

    const preset = (chip.dataset.prompt || chip.textContent || '').trim();
    if (!preset) {
      return;
    }

    const latestText = state.latest?.text ? `:\n\n${state.latest.text}` : '';
    setPromptValue(`${preset}${latestText}`);
    renderAiStatus('Loaded a quick action prompt for you.', false, { badge: 'ready' });
  }
  async function copyAiOutput(text) {
    const success = await copyText(text);
    renderStatus(success ? 'AI output copied' : 'Copy failed', !success);
  }
  async function saveAiOutput(text) {
    if (!text) {
      renderStatus('Nothing to save', true);
      return;
    }

    const response = await sendMessage('save_clipboard', { text, source: 'popup-ai' });
    if (response?.status === 'saved' && response.item) {
      handleIncomingHistoryItem(response.item);
      renderStatus('Saved to history');
      return;
    }

    renderStatus('Could not save to history', true);
  }
  function openExtensionPage(page) {
    const target = typeof chrome !== 'undefined' && chrome.runtime?.getURL ? chrome.runtime.getURL(page) : page;
    if (typeof chrome !== 'undefined' && chrome.tabs?.create) {
      chrome.tabs.create({ url: target });
      return;
    }
    globalScope.open(target, '_blank', 'noopener');
  }
  function sendMessage(action, payload = {}, retries = 3) {
    if (typeof chrome === 'undefined' || !chrome.runtime?.sendMessage) {
      return Promise.resolve(null);
    }

    return new Promise((resolve) => {
      const attempt = () => {
        try {
          chrome.runtime.sendMessage({ action, ...payload }, (response) => {
            if (chrome.runtime?.lastError) {
              const error = chrome.runtime.lastError.message;
              if (error.includes('Could not establish connection') && retries > 0) {
                setTimeout(() => {
                  sendMessage(action, payload, retries - 1).then(resolve);
                }, 200);
                return;
              }
              resolve(null);
              return;
            }
            resolve(response);
          });
        } catch (error) {
          if (retries > 0) {
            setTimeout(() => {
              sendMessage(action, payload, retries - 1).then(resolve);
            }, 200);
            return;
          }
          resolve(null);
        }
      };
      attempt();
    });
  }
  function renderStatus(message, isError = false) {
    if (!dom.statusText) {
      return;
    }

    clearTimeout(timers.status);

    const text = String(message || '').trim();
    dom.statusText.textContent = text;
    dom.statusText.classList.toggle('error', Boolean(isError) && Boolean(text));
    dom.statusText.classList.toggle('success', !isError && Boolean(text));

    if (!text) {
      dom.statusText.classList.remove('error', 'success');
      return;
    }

    const delay = isError ? 4000 : 2500;
    timers.status = globalScope.setTimeout(() => {
      dom.statusText.textContent = '';
      dom.statusText.classList.remove('error', 'success');
    }, delay);
  }

  function resolveBadgeState(isError, override) {
    const candidate = typeof override === 'string' ? override.toLowerCase() : '';
    if (isError) {
      return candidate || 'error';
    }
    if (candidate) {
      return candidate;
    }
    return 'ready';
  }

  function updateAiStatusBadge(state) {
    if (!dom.aiStatusBadge) {
      return;
    }

    const normalized = typeof state === 'string' ? state.toLowerCase() : 'ready';
    const badgeMap = {
      ready: { text: 'Ready', className: 'ready' },
      busy: { text: 'Working', className: 'busy' },
      error: { text: 'Error', className: 'error' },
      disabled: { text: 'Offline', className: 'disabled' }
    };

    const { text, className } = badgeMap[normalized] || badgeMap.ready;
    dom.aiStatusBadge.textContent = text;
    dom.aiStatusBadge.classList.remove('ready', 'busy', 'error', 'disabled');
    dom.aiStatusBadge.classList.add(className);
  }

  function renderAiStatus(message, isError = false, options = {}) {
    if (!dom.aiMessage) {
      return;
    }

    clearTimeout(timers.aiStatus);

    const text = String(message || '');
    const persistent = Boolean(options?.persistent);

    dom.aiMessage.textContent = text;
    dom.aiMessage.classList.toggle('error', Boolean(isError) && Boolean(text));
    dom.aiMessage.classList.toggle('success', !isError && Boolean(text));

    const badgeState = resolveBadgeState(isError, options?.badge);
    updateAiStatusBadge(badgeState);

    if (persistent) {
      dom.aiMessage.dataset.persistent = 'true';
      return;
    }

    delete dom.aiMessage.dataset.persistent;

    if (!text) {
      dom.aiMessage.classList.remove('error', 'success');
      return;
    }

    const delay = isError ? 5000 : 3000;
    timers.aiStatus = globalScope.setTimeout(() => {
      if (dom.aiMessage.dataset?.persistent === 'true') {
        return;
      }
      dom.aiMessage.textContent = '';
      dom.aiMessage.classList.remove('error', 'success');
      updateAiStatusBadge('ready');
    }, delay);
  }

  async function handleMoveToHistory() {
    if (!state.latest || !state.latest.text) {
      renderStatus('Nothing to move to history', true);
      return;
    }

    // Add visual feedback first
    if (dom.moveToHistoryBtn) {
      const originalText = dom.moveToHistoryBtn.textContent;
      dom.moveToHistoryBtn.textContent = '✓ Moved!';
      dom.moveToHistoryBtn.style.background = 'var(--success)';
      dom.moveToHistoryBtn.style.color = 'white';
      
      setTimeout(() => {
        dom.moveToHistoryBtn.textContent = originalText;
        dom.moveToHistoryBtn.style.background = '';
        dom.moveToHistoryBtn.style.color = '';
      }, 1500);
    }

  // Clear the current clipboard preview and refresh empty-state humor
    state.latest = null;
    renderClipboardPreview();
  ensureEmptyStateHumor();
    
    // Show success feedback
    renderStatus('Moved to history! 📚', false);
  }

  function initializeStatusRegions() {
    if (dom.statusText) {
      dom.statusText.textContent = '';
      dom.statusText.classList.remove('error', 'success');
    }
    if (dom.aiMessage) {
      dom.aiMessage.textContent = '';
      dom.aiMessage.classList.remove('error', 'success');
      delete dom.aiMessage.dataset.persistent;
    }
    updateAiStatusBadge('ready');
    dom.clearOutputs?.setAttribute('disabled', 'true');
  }
})(typeof window !== 'undefined' ? window : (typeof globalThis !== 'undefined' ? globalThis : this));
