# Smart Clipboard AI - Technology Stack

## Programming Languages & Versions

### Primary Languages
- **JavaScript (ES2020+)**: Core extension logic and UI interactions
- **TypeScript**: Supabase Edge Functions with strict type checking
- **HTML5**: Extension popup and settings interfaces
- **CSS3**: Responsive styling with modern features

### Runtime Environments
- **Chrome Extension Manifest V3**: Latest extension platform
- **Node.js**: Development tooling and local server
- **Deno**: Supabase Edge Functions runtime environment

## Core Technologies

### Chrome Extension Platform
- **Manifest Version**: 3 (latest standard)
- **Service Worker**: Background processing and API integration
- **Chrome APIs**: Storage, contextMenus, activeTab, tabs, scripting
- **Host Permissions**: Hugging Face API and custom domain access

### AI & Machine Learning
- **Hugging Face Inference API**: Primary content generation service
- **Models**: Text generation models via Inference API
- **Fallback System**: Deterministic content generation for offline scenarios

### Backend Services
- **Supabase**: Backend-as-a-Service platform
  - Edge Functions for serverless AI processing
  - Authentication and user management
  - Real-time database capabilities
- **Stripe**: Payment processing and subscription management

### Storage Solutions
- **Chrome Storage API**: Extension data persistence
  - `chrome.storage.local`: User preferences and history
  - `chrome.storage.sync`: Cross-device synchronization
- **LocalStorage**: Fallback storage mechanism
- **Supabase Database**: Cloud storage for premium users

## Build System & Dependencies

### Package Management
```json
{
  "name": "smart-clipboard-ai",
  "version": "1.0.0",
  "dependencies": {
    "stripe": "^18.5.0"
  },
  "devDependencies": {
    "http-server": "^14.1.1"
  }
}
```

### Build Scripts
- **`npm start`**: Launch local development server
- **`npm run package`**: Create extension package for distribution
- **`npm run setup-icons`**: Initialize icon directory structure
- **`npm run clean`**: Remove build artifacts

### Development Tools
- **Supabase CLI**: Backend service management and deployment
- **Chrome DevTools**: Extension debugging and testing
- **HTTP Server**: Local development and testing server

## Development Commands

### Extension Development
```bash
# Load extension in Chrome
# 1. Open chrome://extensions/
# 2. Enable Developer mode
# 3. Click "Load unpacked"
# 4. Select project directory

# Package extension for distribution
npm run package

# Clean build artifacts
npm run clean
```

### Supabase Backend
```bash
# Initialize Supabase project
supabase init

# Link to remote project
supabase link --project-ref your-project-id

# Deploy Edge Functions
supabase functions deploy generate

# Set environment variables
supabase secrets set HUGGING_FACE_API_KEY=your_token_here

# Alternative using npx (no installation)
npx supabase functions deploy generate
```

### Local Testing
```bash
# Start development server
npm start

# Test extension functionality
# Open extension-tester.html in browser

# Debug service worker
# Chrome DevTools → Extensions → Inspect views → service worker
```

## API Integrations

### Hugging Face API
- **Endpoint**: `https://api-inference.huggingface.co/models/`
- **Authentication**: Bearer token in Authorization header
- **Models**: Text generation models with configurable parameters
- **Rate Limiting**: Handled with quota system and fallback mechanisms

### Supabase Services
- **Edge Functions**: Serverless TypeScript/JavaScript execution
- **Authentication**: OAuth providers (Google, GitHub, email)
- **Database**: PostgreSQL with real-time subscriptions
- **Storage**: File storage for user data

### Chrome Extension APIs
- **Storage**: Persistent data across browser sessions
- **Context Menus**: Right-click integration for text selection
- **Tabs & Scripting**: Content interaction and injection
- **Runtime Messaging**: Component communication

## Security Implementation

### Data Protection
- **Content Sanitization**: All user and AI-generated text sanitized
- **Token Handling**: Hugging Face keys stored locally in Chrome storage using AES-GCM encryption with user disclosure
- **HTTPS Only**: All external API calls use secure connections
- **Input Validation**: User input validated before processing

### Authentication Security
- **OAuth 2.0**: Industry-standard authentication flow
- **Token Management**: Secure token storage and refresh mechanisms
- **Session Management**: Proper session lifecycle handling

### Extension Security
- **Content Security Policy**: Strict CSP headers in manifest
- **Minimal Permissions**: Only required permissions requested
- **Sandboxed Execution**: Service worker isolation

## Performance Optimizations

### Caching Strategies
- **Local Storage**: Frequently accessed data cached locally
- **Quota Tracking**: Efficient usage monitoring with minimal overhead
- **Background Processing**: Long-running operations handled in service worker

### Network Optimization
- **Request Batching**: Multiple generations in single API call when possible
- **Fallback Mechanisms**: Offline content generation for reliability
- **Error Handling**: Graceful degradation on network failures

### Memory Management
- **Efficient Data Structures**: Optimized storage formats
- **Cleanup Procedures**: Proper resource cleanup and garbage collection
- **Lazy Loading**: Components loaded on demand

## Development Environment Setup

### Prerequisites
- **Chrome Browser**: Latest version with developer mode enabled
- **Node.js**: Version 16+ for development tooling
- **Supabase Account**: For backend services (optional)
- **Hugging Face Account**: For AI API access

### Configuration Files
- **config.js**: API endpoints and configuration (use config.example.js as template)
- **manifest.json**: Extension permissions and metadata
- **supabase/config.toml**: Supabase project configuration

### Environment Variables
- **HUGGING_FACE_API_KEY**: AI service authentication
- **SUPABASE_URL**: Backend service endpoint
- **SUPABASE_ANON_KEY**: Public API key for client access