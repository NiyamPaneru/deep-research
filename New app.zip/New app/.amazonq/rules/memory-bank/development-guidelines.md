# Smart Clipboard - Development Guidelines

## Code Style & Standards

### JavaScript Guidelines
- **ES6+ Features**: Use modern JavaScript (const/let, arrow functions, async/await)
- **No External Dependencies**: Vanilla JavaScript only for core functionality
- **Error Handling**: Always wrap async operations in try/catch
- **Consistent Naming**: camelCase for variables, PascalCase for constructors
- **Comments**: JSDoc for functions, inline comments for complex logic

### HTML/CSS Guidelines
- **Semantic HTML**: Use proper HTML5 elements with ARIA attributes
- **CSS Custom Properties**: Use CSS variables for theming
- **Mobile-First**: Responsive design starting from mobile
- **Accessibility**: WCAG 2.1 AA compliance minimum
- **Performance**: Minimize reflows and repaints

## Project Conventions

### File Organization
```
├── Core Files (root level)
│   ├── manifest.json         # Extension config
│   ├── popup.html           # Main UI
│   ├── popup.js             # UI controller
│   ├── styles.css           # All styles
│   └── background.js        # Service worker
├── Services (modular)
│   ├── clipboardManager.js  # Clipboard logic
│   ├── quotaHelper.js       # Usage tracking
│   └── services/            # API integrations
└── Documentation
    └── .amazonq/rules/      # AI assistant context
```

### Naming Conventions
- **Files**: kebab-case (clipboard-manager.js)
- **Functions**: camelCase (handleClipboardChange)
- **Constants**: UPPER_SNAKE_CASE (MAX_CLIPBOARD_ITEMS)
- **CSS Classes**: kebab-case with BEM (clipboard-card--active)
- **IDs**: kebab-case (clipboard-toggle)

### Git Workflow
- **Branch Naming**: feature/description, fix/issue-number, docs/update-type
- **Commit Messages**: Conventional commits (feat:, fix:, docs:, style:, refactor:)
- **Pull Requests**: Include description, testing notes, and screenshots
- **Code Review**: Required for all changes to main branch

## Development Principles

### 1. Clipboard-First Development
- **Core Value**: Clipboard features must always work, even if AI fails
- **Progressive Enhancement**: Build clipboard features first, add AI second
- **Graceful Degradation**: AI failures should not break clipboard functionality
- **User Messaging**: Always emphasize clipboard features as primary value

### 2. Privacy by Design
- **Local Storage**: Default to local storage for all user data
- **Minimal Permissions**: Request only necessary browser permissions
- **No Tracking**: Avoid user identification or behavior tracking
- **Transparent Data**: Users should know what data is stored where

### 3. Performance First
- **Fast Loading**: Extension should load in under 2 seconds
- **Responsive UI**: All interactions should respond within 100ms
- **Memory Efficient**: Limit clipboard history to prevent memory bloat
- **Battery Conscious**: Minimize background processing

### 4. Accessibility Standards
- **Keyboard Navigation**: All features accessible via keyboard
- **Screen Readers**: Proper ARIA labels and semantic HTML
- **Color Contrast**: Minimum 4.5:1 contrast ratio
- **Focus Management**: Clear focus indicators and logical tab order

## Feature Development Process

### 1. Planning Phase
- **User Story**: Write clear user story with acceptance criteria
- **Technical Design**: Document approach and potential issues
- **UI Mockups**: Create wireframes for new UI elements
- **Testing Plan**: Define how feature will be tested

### 2. Implementation Phase
- **Feature Branch**: Create branch from main
- **Incremental Commits**: Small, focused commits with clear messages
- **Self-Testing**: Test feature thoroughly during development
- **Code Review**: Submit PR when feature is complete

### 3. Testing Phase
- **Unit Tests**: Write tests for core logic
- **Integration Tests**: Test feature with existing functionality
- **Manual Testing**: Test in real browser environment
- **Accessibility Testing**: Verify keyboard and screen reader support

### 4. Deployment Phase
- **Version Bump**: Update manifest.json version
- **Release Notes**: Document changes for users
- **Monitoring**: Watch for errors after release
- **Rollback Plan**: Be ready to revert if issues arise

## Code Quality Standards

### Error Handling
```javascript
// Good: Comprehensive error handling
async function saveClipboardItem(text) {
  try {
    const item = createClipboardItem(text);
    await storageHelper.storageSet({ [HISTORY_KEY]: item });
    return { success: true, item };
  } catch (error) {
    logger.debug('saveClipboardItem failed', error);
    return { success: false, error: error.message };
  }
}

// Bad: No error handling
async function saveClipboardItem(text) {
  const item = createClipboardItem(text);
  await storageHelper.storageSet({ [HISTORY_KEY]: item });
  return item;
}
```

### Async/Await Usage
```javascript
// Good: Proper async/await
async function loadHistory() {
  try {
    const data = await storageHelper.storageGet({ history: [] });
    return data.history;
  } catch (error) {
    console.warn('Failed to load history:', error);
    return [];
  }
}

// Bad: Mixing promises and async/await
async function loadHistory() {
  return storageHelper.storageGet({ history: [] })
    .then(data => data.history)
    .catch(error => {
      console.warn('Failed to load history:', error);
      return [];
    });
}
```

### UI State Management
```javascript
// Good: Clear state updates
function updateClipboardUI() {
  const isActive = state.clipboardMonitoring;
  
  // Update button
  dom.clipboardToggle.textContent = isActive ? 'Pause' : 'Start';
  dom.clipboardToggle.setAttribute('aria-pressed', String(isActive));
  
  // Update status
  dom.clipboardStatus.textContent = isActive 
    ? 'Auto-capturing clipboard' 
    : 'Auto-capture paused';
    
  // Update visual state
  dom.clipboardCard.classList.toggle('monitoring-active', isActive);
}

// Bad: Scattered state updates
function updateClipboardUI() {
  if (state.clipboardMonitoring) {
    dom.clipboardToggle.textContent = 'Pause';
    dom.clipboardStatus.textContent = 'Auto-capturing clipboard';
  } else {
    dom.clipboardToggle.textContent = 'Start';
    dom.clipboardStatus.textContent = 'Auto-capture paused';
  }
}
```

## Testing Guidelines

### Unit Testing
- **Test Core Logic**: Focus on business logic, not UI
- **Mock External Dependencies**: Mock Chrome APIs and network requests
- **Edge Cases**: Test error conditions and boundary values
- **Async Testing**: Properly test async functions with await

### Integration Testing
- **User Flows**: Test complete user journeys
- **Cross-Feature**: Test how features interact
- **Performance**: Test with large datasets
- **Browser Compatibility**: Test in different Chrome versions

### Manual Testing Checklist
- [ ] Extension loads without errors
- [ ] Clipboard monitoring works
- [ ] History saves and loads correctly
- [ ] Search and filtering work
- [ ] AI generation works (with token)
- [ ] Settings persist correctly
- [ ] Keyboard navigation works
- [ ] Dark/light themes work
- [ ] Error states display properly
- [ ] Performance is acceptable

## Security Guidelines

### Token Handling
- **Never Log Tokens**: Tokens should never appear in console logs
- **Encrypt Storage**: Use Web Crypto API for token encryption
- **Validate Tokens**: Always validate tokens before use
- **Clear on Demand**: Provide easy way for users to clear tokens

### Input Validation
- **Sanitize Inputs**: Clean all user inputs before processing
- **Length Limits**: Enforce reasonable text length limits
- **Type Checking**: Validate data types before processing
- **XSS Prevention**: Escape HTML content properly

### API Security
- **HTTPS Only**: All API calls must use HTTPS
- **Rate Limiting**: Respect API rate limits
- **Error Handling**: Don't expose sensitive error details
- **Timeout Handling**: Set reasonable timeouts for API calls

## Performance Guidelines

### Memory Management
- **Limit History Size**: Cap clipboard history at 50 items
- **Clean Up Listeners**: Remove event listeners when not needed
- **Avoid Memory Leaks**: Clear intervals and timeouts
- **Efficient Storage**: Use compressed JSON for large data

### UI Performance
- **Debounce Inputs**: Debounce search and filter inputs
- **Virtual Scrolling**: For large lists (future enhancement)
- **Lazy Loading**: Load content as needed
- **Minimize Reflows**: Batch DOM updates

### Network Performance
- **Request Batching**: Batch API requests when possible
- **Caching**: Cache API responses appropriately
- **Compression**: Use gzip for large requests
- **Timeout Handling**: Set appropriate timeouts

## Debugging Guidelines

### Console Logging
```javascript
// Good: Structured logging
logger.debug('clipboard:save', { 
  itemId: item.id, 
  type: item.type, 
  length: item.text.length 
});

// Bad: Unstructured logging
console.log('saving clipboard item', item);
```

### Error Reporting
- **Structured Errors**: Use consistent error format
- **Context Information**: Include relevant context in errors
- **User-Friendly Messages**: Show helpful messages to users
- **Debug Information**: Log technical details for debugging

### Development Tools
- **Chrome DevTools**: Use for debugging and performance analysis
- **Extension DevTools**: Monitor extension-specific metrics
- **Network Tab**: Monitor API requests and responses
- **Performance Tab**: Check for memory leaks and performance issues

## Release Guidelines

### Version Management
- **Semantic Versioning**: MAJOR.MINOR.PATCH
- **Breaking Changes**: Increment major version
- **New Features**: Increment minor version
- **Bug Fixes**: Increment patch version

### Release Process
1. **Code Review**: All changes reviewed and approved
2. **Testing**: Full test suite passes
3. **Version Bump**: Update manifest.json version
4. **Release Notes**: Document changes for users
5. **Package**: Create extension package
6. **Deploy**: Submit to Chrome Web Store
7. **Monitor**: Watch for issues and user feedback

### Rollback Plan
- **Previous Version**: Keep previous version package ready
- **Quick Rollback**: Ability to quickly revert to previous version
- **User Communication**: Notify users of any issues and fixes
- **Post-Mortem**: Document what went wrong and how to prevent it