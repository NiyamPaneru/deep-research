# Smart Clipboard - Technical Architecture

## System Overview
Smart Clipboard is a Chrome extension built with vanilla JavaScript, focusing on local-first architecture with optional cloud enhancements.

## Core Architecture Principles

### 1. Local-First Design
- **Primary Storage**: Chrome extension local storage
- **No Required Backend**: Core features work completely offline
- **Optional Cloud Sync**: Future premium feature for cross-device sync
- **Privacy by Design**: User data stays on device unless explicitly synced

### 2. Progressive Enhancement
- **Layer 1**: Basic clipboard history (works without internet)
- **Layer 2**: Type detection and smart organization
- **Layer 3**: AI enhancement (requires API keys)
- **Layer 4**: Cloud sync and premium features (future)

### 3. Modular Components
- **clipboardManager.js**: Core clipboard functionality
- **popup.js**: Main UI controller
- **background.js**: Service worker for persistence
- **quotaHelper.js**: Usage tracking and limits
- **hfClient.js**: Hugging Face API integration

## File Structure

```
├── manifest.json              # Extension configuration
├── popup.html                 # Main UI
├── popup.js                   # UI controller
├── styles.css                 # All styling
├── background.js              # Service worker
├── clipboardManager.js        # Core clipboard logic
├── quotaHelper.js            # Usage tracking
├── services/
│   ├── hfClient.js           # Hugging Face API
│   ├── tokenStore.js         # Secure token storage
│   ├── logger.js             # Logging utilities
│   └── telemetry.js          # Usage analytics
├── src/
│   ├── ui/
│   │   └── generateFlow.js   # AI generation UI
│   └── services/
│       ├── hfClient.js       # Duplicate for compatibility
│       └── tokenStorage.js   # Token management



## Data Flow

### Clipboard Capture Flow
1. User copies text → Browser clipboard API
2. clipboardManager detects change (if monitoring enabled)
3. Text processed through type detection
4. Item saved to local storage with metadata
5. UI updated to show new item

### AI Enhancement Flow
1. User enters prompt in compose tab
2. System checks for valid token or uses quota
3. Request sent to Hugging Face API
4. Response processed and formatted
5. Result displayed with copy/save options

### Storage Architecture
```javascript
// Clipboard History Structure
{
  "clipboardHistory_v2": [
    {
      "id": 1703123456789,
      "text": "clipboard content",
      "type": "url|email|code|text|phone|number|document",
      "timestamp": "2023-12-20T10:30:00.000Z",
      "source": "clipboard|manual|ai"
    }
  ]
}

// User Preferences
{
  "popupPreferences_v1": {
    "theme": "system|light|dark",
    "clipboardMonitoring": true,
    "activeTab": "compose|history|settings",
    "welcomeDismissed": false,
    "lastPrompt": "user's last AI prompt"
  }
}

// Quota Tracking
{
  "quota_free_[deviceId]": {
    "used": 2,
    "resetAt": 1703209856789,
    "remaining": 1
  }
}
```

## Security Model

### Token Storage
- **Token Persistence**: Hugging Face tokens saved to Chrome local storage without encryption; users are warned in UI
- **Local Only**: Tokens never transmitted to our servers
- **User Control**: Users can clear tokens anytime
- **Validation**: Tokens validated against Hugging Face API

### Data Privacy
- **No Tracking**: No user identification or behavior tracking
- **Local Storage**: All clipboard data stays on device
- **Optional Telemetry**: Anonymous usage statistics (can be disabled)
- **No Account Required**: Core features work without any signup

## API Integration

### Hugging Face Integration
```javascript
// Supported Models
const MODELS = {
  'gpt2': 'Basic text generation',
  'tiiuae/falcon-7b-instruct': 'Instruction following',
  'meta-llama/Llama-2-7b-chat-hf': 'Conversational AI'
};

// Request Format
{
  "inputs": "user prompt with clipboard content",
  "parameters": {
    "max_new_tokens": 160,
    "temperature": 0.7,
    "return_full_text": false,
    "top_p": 0.92
  }
}
```

### Error Handling
- **Network Failures**: Graceful degradation to demo mode
- **API Limits**: Clear user messaging with upgrade paths
- **Invalid Tokens**: Helpful error messages with fix instructions
- **Quota Exceeded**: Transparent limits with reset timers

## Performance Considerations

### Memory Management
- **History Limits**: Maximum 50 clipboard items
- **Text Limits**: 3-10,000 characters per item
- **Cleanup**: Automatic removal of oldest items
- **Efficient Storage**: Compressed JSON storage

### UI Responsiveness
- **Async Operations**: All API calls non-blocking
- **Loading States**: Clear feedback for all operations
- **Debounced Search**: Efficient history filtering
- **Virtual Scrolling**: For large history lists (future)

## Extension Permissions

### Required Permissions
- `storage`: Local data persistence
- `clipboardRead`: Reading clipboard content
- `clipboardWrite`: Writing to clipboard
- `activeTab`: Context menu integration

### Host Permissions
- `https://api-inference.huggingface.co/*`: AI API access
- `https://*.supabase.co/*`: Future cloud sync (unused currently)

## Development Workflow

### Local Development
1. Load unpacked extension in Chrome
2. Use `chrome://extensions/` developer mode
3. Test with `extension-tester.html` for isolated testing
4. Monitor console for errors and performance

### Testing Strategy
- **Unit Tests**: Jest for core functions
- **E2E Tests**: Playwright for user flows
- **Manual Testing**: Real-world usage scenarios
- **Performance Testing**: Memory and CPU usage monitoring

## Deployment Process

### Version Management
- **Semantic Versioning**: Major.Minor.Patch
- **Manifest Version**: Updated with each release
- **Migration Scripts**: Handle storage format changes
- **Rollback Plan**: Previous version backup

### Release Checklist
1. Update version in manifest.json
2. Test all core features
3. Verify AI integration
4. Check permissions and security
5. Package extension
6. Submit to Chrome Web Store
7. Monitor for issues

## Future Architecture Plans

### Scalability Improvements
- **Web Workers**: Move heavy processing off main thread
- **IndexedDB**: Better storage for large datasets
- **Service Worker**: Enhanced background processing
- **Streaming**: Real-time AI generation

### Feature Additions
- **Cloud Sync**: Cross-device clipboard history
- **Team Features**: Shared clipboard spaces
- **Plugin System**: Custom AI providers
- **Mobile App**: Companion mobile application

## Troubleshooting Guide

### Common Issues
1. **Clipboard not working**: Check permissions
2. **AI not generating**: Verify token and quota
3. **History not saving**: Check storage permissions
4. **UI not loading**: Clear extension data and reload

### Debug Tools
- **Console Logging**: Detailed operation logs
- **Storage Inspector**: View stored data
- **Network Tab**: Monitor API requests
- **Performance Tab**: Check memory usage