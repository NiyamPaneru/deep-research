# Smart Clipboard AI - Project Structure

## Directory Organization

### Root Level Files
- **manifest.json**: Chrome extension configuration and permissions
- **package.json**: Node.js dependencies and build scripts
- **README.md**: Comprehensive setup and deployment documentation
- **popup.html/popup.js**: Main extension popup interface and logic
- **background.js**: Service worker for background processing
- **styles.css**: UI styling and responsive design

### Core Directories

#### `/src/` - Source Code
- **background.js**: Background service worker implementation
- **popup.html/popup.js**: Extension popup UI and interaction logic
- **quotaHelper.js**: Usage quota management utilities
- **settings.html/settings.js**: Configuration interface for API keys

#### `/services/` - External Integrations
- **auth.js**: Authentication service with OAuth and subscription management

#### `/supabase/` - Backend Infrastructure
- **functions/generate/**: Edge function for AI content generation
  - **index.ts**: TypeScript implementation with Hugging Face integration
  - **index.js**: JavaScript fallback version
- **config.toml**: Supabase project configuration
- **.temp/**: CLI temporary files and project metadata

#### `/icons/` - Visual Assets
- **icon16.png, icon32.png, icon48.png, icon128.png**: Extension icons
- **ICON_INSTRUCTIONS.md**: Icon design specifications

#### `/.github/` - Development Tools
- **copilot-instructions.md**: AI assistant development guidelines

#### `/.amazonq/rules/memory-bank/` - Documentation
- **product.md, structure.md, tech.md, guidelines.md**: Project memory bank

### Configuration Files
- **config.js/config.example.js**: API configuration templates
- **setup-api-keys.js**: Development key management utility
- **package-extension.js**: Extension packaging script

### Development & Testing
- **server.js**: Local development server
- **test-harness.html**: Standalone testing interface
- **extension-tester.html**: Extension functionality testing
- **debug.js**: Development debugging utilities
- **error-handler.js**: Error handling and logging

### Authentication & Payments
- **auth-callback.html**: OAuth callback handler
- **stripe-callback.html**: Payment processing callback
- **setup-hf.html**: Hugging Face API key setup interface

### Documentation
- **AUTH_SETUP.md**: Authentication configuration guide
- **SETUP_GUIDE.md**: Complete setup instructions
- **QUOTA_IMPLEMENTATION.md**: Usage quota system documentation
- **SECURITY_FIXES.md**: Security implementation details
- **TEST_CHECKLIST.md**: Quality assurance procedures
- **stripe-integration.md**: Payment system integration guide

## Core Components & Relationships

### Extension Architecture
```
Chrome Extension (Manifest V3)
├── Service Worker (background.js)
│   ├── Message Handling
│   ├── API Integration (Hugging Face)
│   ├── Quota Management
│   └── Authentication State
├── Popup Interface (popup.html/js)
│   ├── Content Generation UI
│   ├── History Management
│   ├── Search & Filter
│   └── Settings Access
└── Context Menu Integration
    └── Text Selection Capture
```

### Data Flow
1. **User Input**: Text selection → Context menu → Clipboard storage
2. **Generation**: Popup input → Background processing → AI API → Results
3. **Storage**: Local storage (free) → Cloud sync (premium)
4. **Authentication**: OAuth flow → Subscription management → Feature unlocking

### Service Integration
- **Hugging Face API**: Primary AI content generation
- **Supabase**: Backend services and edge functions
- **Chrome Storage**: Local data persistence
- **Stripe**: Payment processing and subscription management

## Architectural Patterns

### Modular Design
- **Separation of Concerns**: UI, business logic, and data layers clearly separated
- **Service Layer**: External integrations abstracted through service modules
- **Configuration Management**: Environment-specific settings externalized

### Event-Driven Architecture
- **Message Passing**: Chrome extension messaging for component communication
- **Async Processing**: Background service worker handles long-running operations
- **Callback Patterns**: OAuth and payment flows use callback mechanisms

### Progressive Enhancement
- **Offline Capability**: Fallback content generation when AI services unavailable
- **Graceful Degradation**: Core functionality works without premium features
- **Feature Detection**: Conditional feature availability based on user tier

### Security Architecture
- **Content Sanitization**: All user and AI-generated content sanitized
- **Secure Storage**: API keys stored in Chrome's secure storage
- **Permission Model**: Minimal required permissions for extension functionality