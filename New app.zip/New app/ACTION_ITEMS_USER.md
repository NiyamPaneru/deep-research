# Smart Clipboard AI - Action Items for You

## 🚨 Critical Security Fixes (Do These First!)

### 1. Fix .gitignore Security Issue
**Priority: HIGH**
```bash
# Add this line to .gitignore
echo "config.js" >> .gitignore
```
**Why:** Prevents accidentally committing API keys and secrets to version control.

### 2. Add Rate Limiting to Edge Function
**Priority: HIGH**
**File:** `supabase/functions/generate/index.ts`

Add this at the top of your Edge Function:
```typescript
// Rate limiting (5 requests per minute per IP)
const rateLimitMap = new Map();
const RATE_LIMIT = 5;
const WINDOW_MS = 60000; // 1 minute

function checkRateLimit(ip: string): boolean {
  const now = Date.now();
  const userRequests = rateLimitMap.get(ip) || [];
  
  // Remove old requests outside the window
  const validRequests = userRequests.filter((time: number) => now - time < WINDOW_MS);
  
  if (validRequests.length >= RATE_LIMIT) {
    return false; // Rate limit exceeded
  }
  
  validRequests.push(now);
  rateLimitMap.set(ip, validRequests);
  return true;
}

// Add this check in your serve function:
const clientIP = req.headers.get('x-forwarded-for') || 'unknown';
if (!checkRateLimit(clientIP)) {
  return new Response(
    JSON.stringify({ error: 'Rate limit exceeded. Try again in a minute.' }),
    { status: 429, headers: corsHeaders }
  );
}
```

## 📋 Supabase Backend Setup (Required for LTD/Pro)

### 1. Create Supabase Project
1. Go to [supabase.com](https://supabase.com)
2. Create new project
3. Note your project URL and anon key

### 2. Create Database Tables
Run this SQL in your Supabase SQL editor:

```sql
-- Licenses table for LTD users
CREATE TABLE licenses (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  license_key TEXT UNIQUE NOT NULL,
  email TEXT NOT NULL,
  status TEXT DEFAULT 'active',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  activated_at TIMESTAMP WITH TIME ZONE,
  user_id UUID REFERENCES auth.users(id)
);

-- Subscriptions table for Pro users  
CREATE TABLE subscriptions (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users(id),
  gumroad_license_key TEXT UNIQUE,
  status TEXT DEFAULT 'active',
  next_billing_date TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable RLS
ALTER TABLE licenses ENABLE ROW LEVEL SECURITY;
ALTER TABLE subscriptions ENABLE ROW LEVEL SECURITY;

-- RLS Policies
CREATE POLICY "Users can view own licenses" ON licenses
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can view own subscriptions" ON subscriptions  
  FOR SELECT USING (auth.uid() = user_id);
```

### 3. Deploy Edge Functions
```bash
# Install Supabase CLI
npm install -g supabase

# Login to Supabase
supabase login

# Link your project
supabase link --project-ref YOUR_PROJECT_REF

# Deploy functions
supabase functions deploy verify_ltd
supabase functions deploy generate
```

### 4. Set Environment Variables
In your Supabase dashboard, go to Settings > Edge Functions and add:
```
HUGGING_FACE_API_KEY=your_hf_token_here
ROCKETHUB_CSV_URL=your_rockethub_csv_endpoint
```

### 5. Test Edge Function
```bash
curl -X POST 'https://YOUR_PROJECT.supabase.co/functions/v1/verify_ltd' \
  -H 'Content-Type: application/json' \
  -d '{"licenseKey": "test-key", "email": "test@example.com"}'
```

## 🔧 Enable LTD/Pro Flows

### 1. Update config.js
```javascript
const CONFIG = {
  DEBUG_MODE: false, // Set to false for production
  SUPABASE_URL: 'https://YOUR_PROJECT.supabase.co',
  SUPABASE_FUNCTIONS_URL: 'https://YOUR_PROJECT.supabase.co/functions/v1',
  ROCKETHUB_PROMO_END: '2024-12-15T00:00:00Z', // Set your promo end date
  // ... other config
};
```

### 2. Uncomment License Activation Code
**File:** `settings.js`

Find these commented lines and uncomment them:
```javascript
// LTD Activation - TEMPORARILY DISABLED until Supabase backend is ready
document.getElementById('activate-ltd-btn')?.addEventListener('click', async () => {
  await activateLTDLicense();
});

// Pro Activation - TEMPORARILY DISABLED until Supabase backend is ready  
document.getElementById('activate-pro-btn')?.addEventListener('click', async () => {
  await activateProLicense();
});
```

## 🚀 Deployment Steps

### 1. Build Extension
```bash
npm run build
npm run package
```

### 2. Test in Chrome
1. Open `chrome://extensions`
2. Enable "Developer mode"
3. Click "Load unpacked"
4. Select the `dist` folder

### 3. Test All Flows
- [ ] Free user: Try 3 AI generations
- [ ] LTD user: Test license activation
- [ ] Pro user: Test subscription activation
- [ ] Humor: Toggle on/off, check rotation
- [ ] History: Save items, view history page
- [ ] Settings: Change preferences

## 📦 Chrome Web Store Submission

### 1. Prepare Assets
- [ ] Create store screenshots (1280x800)
- [ ] Write store description
- [ ] Create promotional tile (440x280)

### 2. Upload to Chrome Web Store
1. Go to [Chrome Web Store Developer Dashboard](https://chrome.google.com/webstore/devconsole)
2. Upload your `dist` folder as ZIP
3. Fill in store listing details
4. Submit for review

## 🔍 Testing Checklist

Before going live, test:
- [ ] Free tier quota (3 generations per 36h)
- [ ] LTD license activation with real key
- [ ] Pro subscription with real Gumroad key
- [ ] Rate limiting (try >5 requests per minute)
- [ ] All pages work in light/dark theme
- [ ] Humor rotates every 90 seconds
- [ ] History saves and displays correctly
- [ ] Settings persist across browser restarts

## 📞 Support Setup

Consider setting up:
- [ ] Support email address
- [ ] FAQ page
- [ ] User documentation
- [ ] Error reporting system

## 🎯 Marketing Preparation

For RocketHub launch:
- [ ] Set promo end date in config
- [ ] Prepare demo video
- [ ] Write marketing copy
- [ ] Create landing page
- [ ] Set up analytics tracking

## ⚠️ Important Notes

1. **Never commit real API keys** - Always use placeholders in version control
2. **Test rate limiting** - Make sure it actually blocks excessive requests  
3. **Backup your database** - Before making schema changes
4. **Monitor usage** - Watch Supabase quotas and costs
5. **Have rollback plan** - Keep previous version ready if issues arise

## 🆘 If You Get Stuck

Common issues and solutions:

**"Edge Function not found"**
- Make sure you deployed functions: `supabase functions deploy`

**"Rate limit not working"**  
- Check if you added the rate limiting code to the Edge Function

**"License activation fails"**
- Verify your database tables exist and RLS policies are set

**"Extension won't load"**
- Check for JavaScript errors in Chrome DevTools
- Make sure all files are in the `dist` folder

**"Humor not rotating"**
- Check if `humorEnabled` is true in settings
- Verify the rotation interval is set correctly