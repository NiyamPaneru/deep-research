// Quick Supabase Setup Checker
import { CONFIG } from './config.js';

console.log('🔍 Checking Supabase Setup...\n');

const checks = [
  {
    name: 'Supabase URL',
    value: CONFIG.SUPABASE_URL,
    valid: CONFIG.SUPABASE_URL && CONFIG.SUPABASE_URL !== 'https://your-project-ref.supabase.co'
  },
  {
    name: 'Functions URL', 
    value: CONFIG.SUPABASE_FUNCTIONS_URL,
    valid: CONFIG.SUPABASE_FUNCTIONS_URL && CONFIG.SUPABASE_FUNCTIONS_URL !== 'https://your-project-ref.supabase.co/functions/v1'
  }
];

let allValid = true;

checks.forEach(check => {
  const status = check.valid ? '✅' : '❌';
  console.log(`${status} ${check.name}: ${check.value || 'NOT SET'}`);
  if (!check.valid) allValid = false;
});

console.log('\n' + (allValid ? '🎉 Setup Complete!' : '⚠️  Please update config.js with your actual Supabase credentials'));

if (!allValid) {
  console.log('\n📋 Next Steps:');
  console.log('1. Go to https://supabase.com');
  console.log('2. Create/select your project');
  console.log('3. Go to Settings → API');
  console.log('4. Copy Project URL and update CONFIG.SUPABASE_URL');
  console.log('5. Update CONFIG.SUPABASE_FUNCTIONS_URL');
}