// Edge Function: verify_pro
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  const supabase = createClient(
    Deno.env.get("PROJECT_URL") ?? "",
    Deno.env.get("SERVICE_ROLE_KEY") ?? ""
  );

  try {
    const { gumroadKey, email } = await req.json();
    if (!gumroadKey || !email) {
      return new Response(JSON.stringify({ valid: false, error: "Missing gumroadKey or email" }), { status: 400, headers: corsHeaders });
    }

    // Look up subscription by gumroad license key or by email
    const { data: sub, error } = await supabase
      .from("subscriptions")
      .select("*")
      .or(`gumroad_license_key.eq.${gumroadKey},email.eq.${email.toLowerCase()}`)
      .maybeSingle();

    if (error) {
      return new Response(JSON.stringify({ valid: false, error: "DB error" }), { status: 500, headers: corsHeaders });
    }

    if (!sub) {
      return new Response(JSON.stringify({ valid: false, error: "No active subscription found" }), { status: 200, headers: corsHeaders });
    }

    if (sub.status !== "active") {
      return new Response(JSON.stringify({ valid: false, error: "Subscription not active" }), { status: 200, headers: corsHeaders });
    }

    // Optionally update last verified
    await supabase.from("subscriptions").update({ updated_at: new Date().toISOString() }).eq("id", sub.id);

    // Log verification
    await supabase.from("logs").insert([{ type: "verify_pro", payload: { gumroadKey, email, time: new Date().toISOString() } }]);

    return new Response(JSON.stringify({ valid: true, plan: "PRO", email: sub.email }), { status: 200, headers: corsHeaders });
  } catch (e) {
    return new Response(JSON.stringify({ valid: false, error: e.message }), { status: 500, headers: corsHeaders });
  }
});
