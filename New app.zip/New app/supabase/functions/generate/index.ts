// @ts-ignore - Deno std import resolved at runtime
import { serve } from "https://deno.land/std@0.168.0/http/server.ts"

// Security: Input sanitization function
function sanitizeForLog(input: any): string {
  if (typeof input !== 'string') {
    input = String(input);
  }
  return input.replace(/[\r\n\t]/g, ' ').substring(0, 100);
}

function sanitizeText(text: string): string {
  return text.replace(/[<>&"']/g, function(match) {
    const escapeMap: Record<string, string> = {
      '<': '&lt;',
      '>': '&gt;',
      '&': '&amp;',
      '"': '&quot;',
      "'": '&#x27;'
    };
    return escapeMap[match];
  });
}

// Minimal shim for Deno env so TypeScript tooling works
declare const Deno: {
  env: { get(name: string): string | undefined }
}

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS'
}

serve(async (req: Request) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    // Parse request body with error handling
    let requestBody: any
    try {
      requestBody = await req.json()
    } catch (e) {
      return new Response(
        JSON.stringify({ error: 'Invalid JSON in request body' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    const { prompt, useCase } = requestBody
    
    if (!prompt || typeof prompt !== 'string') {
      return new Response(
        JSON.stringify({ error: 'Invalid prompt parameter' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    // Get API key from environment or request body (user's own token)
    let apiKey = requestBody.userToken || Deno.env.get('HUGGING_FACE_API_KEY')
    if (!apiKey) {
      return new Response(
        JSON.stringify({ error: 'API key not configured' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    // Build model prompt based on use case
    const buildPrompt = (prompt: string, useCase: string): string => {
      const templates: Record<string, string> = {
        headline: `Write 3 compelling headlines for: ${prompt}\n1.`,
        cta: `Create 3 call-to-action phrases for: ${prompt}\n1.`,
        product_description: `Write a product description for: ${prompt}\nDescription:`,
        email_subject: `Create 3 email subjects for: ${prompt}\n1.`,
        social_media: `Write 3 social media posts about: ${prompt}\n1.`,
        blog_intro: `Write an engaging blog introduction about: ${prompt}\nIntroduction:`,
        summary: `Summarize this text: ${prompt}\nSummary:`
      }
      return templates[useCase] || `Generate content about: ${prompt}\nContent:`
    }

    const modelPrompt = buildPrompt(prompt, useCase || 'headline')

    // Use more reliable models with better availability
    const models = [
      'microsoft/DialoGPT-medium',
      'gpt2',
      'distilgpt2',
      'facebook/blenderbot-400M-distill',
      'microsoft/DialoGPT-small'
    ]
    let response: Response | null = null
    let lastError: string = ''

    for (const model of models) {
      try {
        console.log(`Trying model: ${sanitizeForLog(model)}`)
        
        response = await fetch(`https://api-inference.huggingface.co/models/${model}`, {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${apiKey}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            inputs: modelPrompt,
            parameters: {
              max_length: 40,
              num_return_sequences: 2,
              temperature: 0.6
            },
            options: {
              wait_for_model: true,
              use_cache: true
            }
          })
        })

        if (response.ok) {
          console.log(`Success with model: ${sanitizeForLog(model)}`)
          break
        } else {
          const errorText = await response.text()
          lastError = `${sanitizeForLog(model)}: HTTP ${response.status} - ${sanitizeForLog(errorText)}`
          console.error(lastError)
          response = null
        }
      } catch (error) {
        lastError = `${sanitizeForLog(model)}: ${sanitizeForLog((error as Error).message)}`
        console.error(`Failed to call ${sanitizeForLog(model)}:`, sanitizeForLog(String(error)))
        response = null
      }
    }

    if (!response || !response.ok) {
      console.error('All Hugging Face API calls failed. Last error:', sanitizeForLog(lastError))
      
      // Return fallback generated content
      const fallbackOutputs = generateFallbackContent(prompt, useCase)
      return new Response(
        JSON.stringify({ outputs: fallbackOutputs, fallback: true }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    // Parse response with better error handling
    let result
    try {
      result = await response.json()
    } catch (e) {
      throw new Error('Failed to parse API response as JSON')
    }

    console.log('API Response received (sanitized for security)')

    let outputs: string[] = []

    // Handle different response formats
    if (Array.isArray(result)) {
      // Handle array of generations
      outputs = result
        .map(item => {
          if (typeof item === 'string') return item
          if (item.generated_text) return item.generated_text
          if (item.text) return item.text
          return null
        })
        .filter(text => text && text.trim())
        .slice(0, 3)
    } else if (result.generated_text) {
      // Single generation
      outputs = [result.generated_text]
    } else if (typeof result === 'string') {
      outputs = [result]
    }

    // Clean and process outputs
    outputs = outputs
      .map(text => text.trim().replace(modelPrompt, '').trim())
      .filter(text => text.length > 0 && text.length < 200)
      .slice(0, 3)

    // Ensure we have exactly 2 outputs
    if (outputs.length > 2) {
      outputs = outputs.slice(0, 2)
    } else if (outputs.length === 1) {
      const base = outputs[0].trim()
      const variation = createLocalVariation(base, useCase)
      outputs = [base, variation]
    }

    // Fallback if no valid outputs
    if (outputs.length === 0) {
      outputs = generateFallbackContent(prompt, useCase)
    }

    return new Response(
      JSON.stringify({ outputs }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )

  } catch (error) {
    console.error('Edge function error:', sanitizeForLog(String(error)))
    
    // Return fallback content even on error
    const fallbackOutputs = ['Generated content', 'Alternative option', 'Third variation']
    
    return new Response(
      JSON.stringify({ 
        outputs: fallbackOutputs, 
        error: 'Fallback mode activated',
        debug: sanitizeForLog((error as Error).message) 
      }),
      { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )
  }
})

// Generate fallback content when API fails
function generateFallbackContent(prompt: string, useCase: string): string[] {
  const safePrompt = sanitizeText(prompt);
  const words = safePrompt.split(' ').filter(w => w.length > 2);
  const key = words.slice(0, 3).join(' ');
  
  const templates: Record<string, string[]> = {
    headline: [
      `${key}: The Ultimate Guide`,
      `Discover Amazing ${key} Solutions`,
      `Transform Your ${key} Experience Today`
    ],
    cta: [
      `Get Started with ${key}`,
      `Try ${key} Risk-Free`,
      `Unlock ${key} Benefits Now`
    ],
    product_description: [
      `Our ${key} solution combines innovation with reliability to deliver outstanding results.`,
      `Experience premium ${key} features designed for modern users who demand excellence.`,
      `${key} technology that adapts to your needs and exceeds expectations.`
    ],
    email_subject: [
      `Your ${key} Update is Ready`,
      `Exclusive ${key} Offer Inside`,
      `Important ${key} Information`
    ],
    social_media: [
      `Just discovered amazing ${key} tips! 🚀 #productivity`,
      `${key} game-changer alert! Who else is excited? 💡`,
      `Quick ${key} hack that actually works ✨ Try it!`
    ],
    blog_intro: [
      `In today's fast-paced world, ${key} has become more important than ever.`,
      `Have you ever wondered about the impact of ${key} on your daily life?`,
      `Let's explore the fascinating world of ${key} and its possibilities.`
    ],
    summary: [
      `Key points about ${key}: Essential information summarized.`,
      `${key} overview: Main concepts and important details.`,
      `Quick ${key} summary: What you need to know.`
    ]
  }

  return templates[useCase] || [
    `Explore ${key} possibilities`,
    `Discover ${key} benefits`, 
    `Learn about ${key} solutions`
  ]
}

// Create single local variation to save API quota
function createLocalVariation(baseText: string, useCase: string): string {
  switch(useCase) {
    case 'headline':
      return baseText.replace(/\b(amazing|great|good)\b/gi, 'incredible')
    case 'cta':
      return baseText.replace(/now/gi, 'today') + ' - Act Fast!'
    case 'social_media':
      return baseText + ' 🚀 #trending'
    default:
      return baseText.replace(/\b(the|a)\b/gi, match => match === 'the' ? 'your' : 'the')
  }
}

