import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "https://kmyewkhcpvqkfyhlodeg.supabase.co",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

class OpenAI {
  constructor({ baseURL, apiKey }) {
    this.baseURL = baseURL;
    this.apiKey = apiKey;
  }

  get chat() {
    return {
      completions: {
        create: async (params) => {
          const res = await fetch(`${this.baseURL}/chat/completions`, {
            method: "POST",
            headers: {
              "Authorization": `Bearer ${this.apiKey}`,
              "Content-Type": "application/json",
            },
            body: JSON.stringify(params),
          });
          if (!res.ok) {
            throw new Error(`HTTP ${res.status}: ${await res.text()}`);
          }
          return await res.json();
        },
      },
    };
  }
}

function buildPrompt(prompt, useCase) {
  const templates = {
    headline: `Create 3 short compelling landing page headlines for: ${prompt}`,
    cta: `Write 3 short clear calls-to-action for: ${prompt}`,
    product_description: `Write 3 short product descriptions for: ${prompt}`,
    email_subject: `Write 3 short email subject lines for: ${prompt}`,
    general: `Generate helpful and relevant content based on this context: ${prompt}. Please provide a comprehensive response.`,
  };
  return templates[useCase] ?? templates.general;
}

function generateFallbackContent(prompt, useCase) {
  const baseWords = (prompt ?? "").split(/\s+/).filter(Boolean).slice(0, 6);
  const base = baseWords.length ? baseWords.join(" ") : "Your project";
  const templates = {
    headline: [
      `${base} — A smarter way`,
      `Try ${base} today`,
      `Build faster with ${base}`,
    ],
    cta: [
      `Try ${base} now`,
      "Get started",
      "Start free trial",
    ],
    product_description: [
      `${base} is a lightweight tool that helps you get results faster.`,
      `A simple solution for ${base} — designed for creators.`,
      `Save time and ship better with ${base}.`,
    ],
    email_subject: [
      `${base} — quick update`,
      `Improve your ${base} today`,
      `${base}: Invitation`,
    ],
  };
  return templates[useCase] ?? templates.headline;
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    let requestBody;
    try {
      requestBody = await req.json();
    } catch {
      return new Response(JSON.stringify({ error: "Invalid JSON" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const prompt = requestBody?.prompt;
    const useCase = requestBody?.useCase ?? "general";

    if (!prompt || typeof prompt !== "string") {
      return new Response(JSON.stringify({ error: "Invalid prompt" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const words = prompt.trim().split(/\s+/).filter((word) => word.length > 0);
    if (words.length < 3) {
      return new Response(JSON.stringify({ error: "Please provide at least 3 words for better generation" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const apiKey = Deno.env.get("HF_TOKEN");
    if (!apiKey) {
      return new Response(JSON.stringify({ error: "API key not configured" }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const client = new OpenAI({
      baseURL: "https://router.huggingface.co/v1",
      apiKey,
    });

    const modelPrompt = buildPrompt(prompt, useCase);

    try {
      const chatCompletion = await client.chat.completions.create({
        model: "mistralai/Mistral-7B-Instruct-v0.2:featherless-ai",
        messages: [
          {
            role: "user",
            content: modelPrompt,
          },
        ],
        max_tokens: 500,
        temperature: 0.7,
      });

      const content = chatCompletion?.choices?.[0]?.message?.content ?? "";
      let outputs = [];

      if (useCase === "general") {
        outputs = [content.trim()];
      } else {
        const lines = content
          .split(/\n+/)
          .map((line) => line.replace(/^\d+[\).\s-]*/, "").trim())
          .filter((line) => line.length > 0);
        outputs = (lines.length ? lines : [content]).slice(0, 3);
      }

      if (!outputs.length || outputs.every((text) => !text)) {
        outputs = generateFallbackContent(prompt, useCase);
      }

      return new Response(JSON.stringify({ outputs }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    } catch (aiError) {
      console.error("AI generation error:", String(aiError.message).substring(0, 100));
      const fallback = generateFallbackContent(prompt, useCase);
      return new Response(JSON.stringify({ outputs: fallback, fallback: true, error: "Generation failed. Please try again." }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
  } catch (error) {
    console.error("Server error:", String(error).substring(0, 100));
    const fallback = generateFallbackContent("fallback", "headline");
    return new Response(JSON.stringify({ outputs: fallback, error: "Server error occurred" }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
