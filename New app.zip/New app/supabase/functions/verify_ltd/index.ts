import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  const supabase = createClient(
    Deno.env.get("PROJECT_URL") ?? "",
    Deno.env.get("SERVICE_ROLE_KEY") ?? ""
  );

  try {
    const { licenseKey, email, deviceId } = await req.json();

    if (!licenseKey || !email || !deviceId)
      return new Response(JSON.stringify({ valid: false, error: "Missing fields" }), {
        status: 400,
        headers: corsHeaders,
      });

    const { data: license, error } = await supabase
      .from("licenses")
      .select("*")
      .eq("license_key", licenseKey)
      .eq("email", email.toLowerCase())
      .eq("status", "active")
      .single();

    if (error || !license)
      return new Response(JSON.stringify({ valid: false, error: "Invalid license" }), {
        status: 401,
        headers: corsHeaders,
      });

    // if already bound to another device
    if (license.device_id && license.device_id !== deviceId)
      return new Response(JSON.stringify({ valid: false, error: "License used on another device" }), {
        status: 403,
        headers: corsHeaders,
      });

    // simple usage counter
    const newCount = (license.usage_count ?? 0) + 1;
    await supabase
      .from("licenses")
      .update({ device_id: deviceId, usage_count: newCount, activated_at: new Date().toISOString() })
      .eq("license_key", licenseKey);

    // log event
    await supabase.from("logs").insert({
      type: "verify_ltd",
      payload: { email, licenseKey, deviceId, time: new Date().toISOString() },
    });

    return new Response(
      JSON.stringify({
        valid: true,
        plan: license.plan_type,
        usage_count: newCount,
        email: license.email,
      }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (e) {
    return new Response(JSON.stringify({ valid: false, error: e.message }), {
      status: 500,
      headers: corsHeaders,
    });
  }
});
