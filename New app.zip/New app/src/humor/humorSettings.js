// Humor Settings Component
class HumorSettings {
  constructor(container) {
    this.container = container;
    this.humorManager = null;
  }

  async init(humorManager) {
    this.humorManager = humorManager;
    this.render();
    this.attachEventListeners();
  }

  render() {
    this.container.innerHTML = `
      <div class="humor-controls-card">
        <h3>😄 Humor Controls</h3>
        <div class="humor-setting">
          <label class="humor-toggle">
            <input type="checkbox" id="humorEnabled" ${this.humorManager.settings.humorEnabled ? 'checked' : ''}>
            <span class="toggle-slider"></span>
            Enable Humor
          </label>
        </div>
        
        <div class="humor-setting">
          <label for="humorTone">Tone:</label>
          <select id="humorTone" ${!this.humorManager.settings.humorEnabled ? 'disabled' : ''}>
            <option value="playful" ${this.humorManager.settings.humorTone === 'playful' ? 'selected' : ''}>Playful</option>
            <option value="neutral" ${this.humorManager.settings.humorTone === 'neutral' ? 'selected' : ''}>Neutral</option>
            <option value="off" ${this.humorManager.settings.humorTone === 'off' ? 'selected' : ''}>Off</option>
          </select>
        </div>

        <div class="humor-setting">
          <label for="humorFrequency">Frequency:</label>
          <select id="humorFrequency" ${!this.humorManager.settings.humorEnabled ? 'disabled' : ''}>
            <option value="random" ${this.humorManager.settings.humorFrequency === 'random' ? 'selected' : ''}>Random</option>
            <option value="daily" ${this.humorManager.settings.humorFrequency === 'daily' ? 'selected' : ''}>Daily</option>
            <option value="perItem" ${this.humorManager.settings.humorFrequency === 'perItem' ? 'selected' : ''}>Per Item</option>
          </select>
        </div>

        <p class="humor-note">We keep jokes optional. Disable anytime.</p>
      </div>
    `;
  }

  attachEventListeners() {
    const humorEnabled = this.container.querySelector('#humorEnabled');
    const humorTone = this.container.querySelector('#humorTone');
    const humorFrequency = this.container.querySelector('#humorFrequency');

    humorEnabled.addEventListener('change', async (e) => {
      const enabled = e.target.checked;
      await this.humorManager.saveSettings({ humorEnabled: enabled });
      
      humorTone.disabled = !enabled;
      humorFrequency.disabled = !enabled;
      
      if (enabled) {
        this.humorManager.startRotation();
      } else {
        this.humorManager.stopRotation();
      }
    });

    humorTone.addEventListener('change', async (e) => {
      await this.humorManager.saveSettings({ humorTone: e.target.value });
    });

    humorFrequency.addEventListener('change', async (e) => {
      await this.humorManager.saveSettings({ humorFrequency: e.target.value });
      this.humorManager.startRotation(); // Restart with new frequency
    });
  }
}

window.HumorSettings = HumorSettings;