const JOKE_LIBRARY = [
  {
    id: 'history-1',
    tone: 'Playful',
    category: 'history',
    text: 'Clipboard refreshed. Consider us your idea vault on standby.'
  },
  {
    id: 'history-2',
    tone: 'Playful',
    category: 'history',
    text: 'Saved! Your latest copy has a VIP seat in history.'
  },
  {
    id: 'history-3',
    tone: 'Neutral',
    category: 'history',
    text: 'Clipboard item stored successfully and ready when you are.'
  },
  {
    id: 'history-4',
    tone: 'Playful',
    category: 'history',
    text: 'You copy, we organize. Teamwork in real time.'
  },
  {
    id: 'history-5',
    tone: 'Neutral',
    category: 'history',
    text: 'History updated to keep your workflow uninterrupted.'
  },
  {
    id: 'empty-1',
    tone: 'Playful',
    category: 'emptyState',
    text: "No clips yet. Maybe your memory's taking a coffee break ☕."
  },
  {
    id: 'empty-2',
    tone: 'Neutral',
    category: 'emptyState',
    text: 'Nothing saved yet. Copy something and it will appear here instantly.'
  },
  {
    id: 'empty-3',
    tone: 'Playful',
    category: 'emptyState',
    text: 'Clipboard is clear. Ready whenever inspiration strikes.'
  },
  {
    id: 'settings-1',
    tone: 'Playful',
    category: 'settings',
    text: 'Dial in your preferences. We will keep the jokes respectful of your vibe.'
  },
  {
    id: 'settings-2',
    tone: 'Neutral',
    category: 'settings',
    text: 'Adjust humor and productivity settings in one spot.'
  },
  {
    id: 'settings-3',
    tone: 'Playful',
    category: 'settings',
    text: 'Prefer focus or fun? Set the tone and we will match it.'
  },
  {
    id: 'daily-1',
    tone: 'Playful',
    category: 'daily',
  text: "Clipboard systems checked. Let's capture something great today."
  },
  {
    id: 'daily-2',
    tone: 'Neutral',
    category: 'daily',
    text: 'Smart Clipboard is ready whenever you need it.'
  },
  {
    id: 'daily-3',
    tone: 'Playful',
    category: 'daily',
    text: 'Fresh day, fresh clipboard. Time to make it count.'
  },
  {
    id: 'tips-1',
    tone: 'Playful',
    category: 'tip',
    text: 'Pro tip: Pin important clips so they never wander off.'
  },
  {
    id: 'tips-2',
    tone: 'Neutral',
    category: 'tip',
    text: 'Need structure? Tag clips with quick labels to stay organized.'
  },
  {
    id: 'tips-3',
    tone: 'Playful',
    category: 'tip',
    text: 'Shortcuts matter: try copying twice quickly to highlight favorites.'
  },
  {
    id: 'history-6',
    tone: 'Playful',
    category: 'history',
    text: 'Nice save. Your ideas now have a reliable getaway car.'
  },
  {
    id: 'history-7',
    tone: 'Neutral',
    category: 'history',
    text: 'Clipboard item captured and filed for easy recall.'
  },
  {
    id: 'history-8',
    tone: 'Playful',
    category: 'history',
    text: 'Another copy secured. Momentum officially on your side.'
  }
];

const FALLBACK_JOKE = {
  id: 'fallback',
  tone: 'Neutral',
  category: 'tip',
  text: 'Clipboard steady and standing by.'
};

export { JOKE_LIBRARY, FALLBACK_JOKE };
export default JOKE_LIBRARY;
