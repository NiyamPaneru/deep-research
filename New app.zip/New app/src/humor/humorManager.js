// UI-facing Humor Manager helper that coordinates with the shared humor service
(function defineHumorManager(globalScope) {
  const DEFAULT_INTERVAL_MS = 90_000;

  class HumorManager {
    constructor(options = {}) {
      this.channel = typeof options.channel === 'string' && options.channel.trim() ? options.channel.trim() : 'general';
      this.listeners = new Set();
      this.intervalId = null;
      this.settings = null;
      this.unsubscribeSettings = null;
      this.isInitialized = false;
      this.lastDispatch = null;
    }

    get api() {
      return globalScope?.humorManager || null;
    }

    get intervalMs() {
      if (!this.settings) {
        return DEFAULT_INTERVAL_MS;
      }
      const candidate = Number.parseInt(this.settings.rotationInterval, 10);
      if (!Number.isFinite(candidate) || candidate <= 0) {
        return DEFAULT_INTERVAL_MS;
      }
      return Math.max(10_000, candidate * 1000);
    }

    async init() {
      if (!this.api) {
        return this;
      }

      this.settings = await this.api.loadSettings();
      this.unsubscribeSettings = this.api.subscribe((next) => {
        this.settings = next;
        this.restartTimer();
        this.dispatch(null, { kind: 'settings', settings: next });
      });

      this.isInitialized = true;
      this.restartTimer(true);
      return this;
    }

    async fetchJoke(options = {}) {
      if (!this.api) {
        return null;
      }

      const joke = await this.api.getJoke(this.channel, options);
      if (joke && typeof joke.text === 'string') {
        this.lastDispatch = { joke, settings: this.settings };
      }
      return joke;
    }

    restartTimer(triggerImmediate = false) {
      this.stopTimer();

      if (!this.settings?.humorEnabled) {
        this.dispatch(null, { kind: 'disabled', settings: this.settings });
        return;
      }

      if (triggerImmediate) {
        void this.emitNext({ force: true });
      }

      this.intervalId = globalScope.setInterval(() => {
        void this.emitNext({ force: false });
      }, this.intervalMs);
    }

    stopTimer() {
      if (this.intervalId) {
        globalScope.clearInterval(this.intervalId);
        this.intervalId = null;
      }
    }

    async emitNext({ force }) {
      if (!this.settings?.humorEnabled && !force) {
        this.dispatch(null, { kind: 'disabled', settings: this.settings });
        return;
      }

      const joke = await this.fetchJoke({ force });
      if (joke) {
        this.dispatch(joke, { kind: 'joke', settings: this.settings });
      }
    }

    dispatch(joke, context = {}) {
      if (!this.listeners.size) {
        return;
      }
      const payload = {
        joke,
        settings: this.settings,
        kind: context.kind || (joke ? 'joke' : 'state'),
        timestamp: Date.now()
      };
      this.listeners.forEach((listener) => {
        try {
          listener(payload);
        } catch (_error) {
          // ignore listener failures
        }
      });
    }

    watch(listener, options = {}) {
      if (typeof listener !== 'function') {
        return () => {};
      }

      this.listeners.add(listener);

      if (this.lastDispatch && options.replay !== false) {
        listener({ ...this.lastDispatch, kind: 'joke', timestamp: Date.now() });
      } else if (this.settings?.humorEnabled) {
        void this.emitNext({ force: true });
      } else {
        listener({ joke: null, settings: this.settings, kind: 'disabled', timestamp: Date.now() });
      }

      if (!this.intervalId && this.settings?.humorEnabled) {
        this.restartTimer();
      }

      return () => {
        this.listeners.delete(listener);
        if (!this.listeners.size) {
          this.stopTimer();
        }
      };
    }

    updateSettings(partial) {
      if (!this.api) {
        return Promise.resolve(false);
      }
      return this.api.updateSettings({ ...this.settings, ...partial });
    }

    destroy() {
      this.stopTimer();
      if (typeof this.unsubscribeSettings === 'function') {
        this.unsubscribeSettings();
      }
      this.listeners.clear();
    }
  }

  globalScope.HumorManager = HumorManager;
})(typeof window !== 'undefined' ? window : globalThis);