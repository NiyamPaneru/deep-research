// Humor Panel Component for History Page
class HumorPanel {
  constructor(container) {
    this.container = container;
    this.humorManager = null;
    this.currentJoke = null;
    this.rotationInterval = null;
  }

  async init(humorManager) {
    this.humorManager = humorManager;
    this.render();
    this.startRotation();
    
    // Listen for rotation messages
    chrome.runtime.onMessage.addListener((message) => {
      if (message.type === 'ROTATE_JOKE') {
        this.updateJoke();
      }
    });
  }

  render() {
    if (!this.humorManager.settings.humorEnabled) {
      this.container.style.display = 'none';
      return;
    }

    this.container.style.display = 'block';
    this.container.innerHTML = `
      <div class="humor-panel">
        <div class="humor-content">
          <div id="jokeText" class="joke-text">Loading humor...</div>
        </div>
        <div class="humor-footer">
          <button id="disableHumor" class="disable-humor-btn">
            Don't like jokes? Turn Humor Off
          </button>
        </div>
      </div>
    `;

    this.attachEventListeners();
    this.updateJoke();
  }

  attachEventListeners() {
    const disableBtn = this.container.querySelector('#disableHumor');
    if (disableBtn) {
      disableBtn.addEventListener('click', async () => {
        await this.humorManager.saveSettings({ humorEnabled: false });
        this.container.style.display = 'none';
        this.stopRotation();
      });
    }
  }

  updateJoke(category = null) {
    if (!this.humorManager.settings.humorEnabled) return;

    const joke = this.humorManager.getJoke(category);
    if (joke) {
      this.currentJoke = joke;
      const jokeElement = this.container.querySelector('#jokeText');
      if (jokeElement) {
        jokeElement.textContent = joke.text;
        jokeElement.className = `joke-text ${joke.tone} ${joke.length}`;
      }
    }
  }

  startRotation() {
    if (this.rotationInterval) {
      clearInterval(this.rotationInterval);
    }

    if (this.humorManager.settings.humorFrequency === 'random') {
      // Rotate every 1-2 minutes
      const interval = (60 + Math.random() * 60) * 1000;
      this.rotationInterval = setInterval(() => {
        this.updateJoke();
      }, interval);
    }
  }

  stopRotation() {
    if (this.rotationInterval) {
      clearInterval(this.rotationInterval);
      this.rotationInterval = null;
    }
  }

  showCategoryJoke(category) {
    this.updateJoke(category);
  }

  destroy() {
    this.stopRotation();
    if (this.container) {
      this.container.innerHTML = '';
    }
  }
}

window.HumorPanel = HumorPanel;