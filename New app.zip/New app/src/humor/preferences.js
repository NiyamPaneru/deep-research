import { storageGet, storageSet, storageRemove } from '../../storageHelper.js';

const HUMOR_SETTINGS_KEY = 'humorSettingsV2';
const LEGACY_SETTINGS_KEYS = ['humorSettings', 'humorSettingsV1'];
const HUMOR_RUNTIME_KEY = 'humorRuntimeStateV2';
const LEGACY_RUNTIME_KEYS = ['humorRuntimeStateV1'];

const DEFAULT_HUMOR_SETTINGS = {
  humorEnabled: true,
  rotationInterval: 90,
  tone: 'default'
};

const MIN_INTERVAL_SECONDS = 30;
const MAX_INTERVAL_SECONDS = 600;

function clampInterval(value) {
  const numeric = Number.parseInt(value, 10);
  if (!Number.isFinite(numeric)) {
    return DEFAULT_HUMOR_SETTINGS.rotationInterval;
  }
  return Math.min(Math.max(numeric, MIN_INTERVAL_SECONDS), MAX_INTERVAL_SECONDS);
}

function normalizeTone(tone) {
  const normalized = String(tone || '').toLowerCase();
  if (['default', 'neutral', 'spicy'].includes(normalized)) {
    return normalized;
  }
  return DEFAULT_HUMOR_SETTINGS.tone;
}

function normalizeSettings(raw) {
  if (!raw || typeof raw !== 'object') {
    return { ...DEFAULT_HUMOR_SETTINGS };
  }

  // Support legacy shape
  if (Object.prototype.hasOwnProperty.call(raw, 'enabled')) {
    return {
      humorEnabled: Boolean(raw.enabled),
      rotationInterval: clampInterval(raw.interval ?? raw.rotationInterval ?? 90),
      tone: normalizeTone(raw.tone === 'Playful' ? 'default' : raw.tone === 'Neutral' ? 'neutral' : raw.tone === 'Off' ? 'neutral' : raw.tone)
    };
  }

  return {
    humorEnabled: raw.humorEnabled !== false,
    rotationInterval: clampInterval(raw.rotationInterval),
    tone: normalizeTone(raw.tone)
  };
}

async function migrateLegacySettings() {
  for (const key of LEGACY_SETTINGS_KEYS) {
    const legacy = await storageGet([key]);
    const candidate = legacy?.[key];
    if (candidate) {
      const normalized = normalizeSettings(candidate);
      await storageSet({ [HUMOR_SETTINGS_KEY]: normalized });
      await storageRemove(key);
      return normalized;
    }
  }
  return { ...DEFAULT_HUMOR_SETTINGS };
}

async function loadHumorSettings() {
  try {
    const result = await storageGet([HUMOR_SETTINGS_KEY]);
    const stored = result?.[HUMOR_SETTINGS_KEY];
    if (stored) {
      return normalizeSettings(stored);
    }
    return migrateLegacySettings();
  } catch (_error) {
    return { ...DEFAULT_HUMOR_SETTINGS };
  }
}

async function saveHumorSettings(settings) {
  const normalized = normalizeSettings(settings);
  await storageSet({ [HUMOR_SETTINGS_KEY]: normalized });
  // Clean up legacy keys to avoid stale state
  await Promise.all(LEGACY_SETTINGS_KEYS.map((key) => storageRemove(key)));
  return normalized;
}

function observeHumorSettings(callback) {
  if (typeof chrome === 'undefined' || !chrome.storage?.onChanged?.addListener) {
    return () => {};
  }

  const handler = (changes, areaName) => {
    if (areaName !== 'local') {
      return;
    }

    if (Object.prototype.hasOwnProperty.call(changes, HUMOR_SETTINGS_KEY)) {
      const next = changes[HUMOR_SETTINGS_KEY]?.newValue;
      callback?.(normalizeSettings(next));
      return;
    }

    const legacyKey = LEGACY_SETTINGS_KEYS.find((key) => Object.prototype.hasOwnProperty.call(changes, key));
    if (legacyKey) {
      const next = changes[legacyKey]?.newValue;
      callback?.(normalizeSettings(next));
    }
  };

  chrome.storage.onChanged.addListener(handler);
  return () => chrome.storage.onChanged.removeListener(handler);
}

async function loadRuntimeState() {
  try {
    const result = await storageGet([HUMOR_RUNTIME_KEY]);
    const state = result?.[HUMOR_RUNTIME_KEY];
    if (state && typeof state === 'object') {
      const lastServed = state.lastServed && typeof state.lastServed === 'object' ? state.lastServed : {};
      return { lastServed };
    }

    for (const key of LEGACY_RUNTIME_KEYS) {
      const legacy = await storageGet([key]);
      const legacyState = legacy?.[key];
      if (legacyState && typeof legacyState === 'object') {
        const payload = {
          lastServed: legacyState.lastServed && typeof legacyState.lastServed === 'object' ? legacyState.lastServed : {}
        };
        await storageSet({ [HUMOR_RUNTIME_KEY]: payload });
        await storageRemove(key);
        return payload;
      }
    }
  } catch (_error) {
    // ignore and fall through to defaults
  }

  return { lastServed: {} };
}

async function persistRuntimeState(state) {
  const payload = {
    lastServed: state?.lastServed && typeof state.lastServed === 'object' ? state.lastServed : {}
  };
  await storageSet({ [HUMOR_RUNTIME_KEY]: payload });
  await Promise.all(LEGACY_RUNTIME_KEYS.map((key) => storageRemove(key)));
  return payload;
}

export {
  HUMOR_SETTINGS_KEY,
  HUMOR_RUNTIME_KEY,
  DEFAULT_HUMOR_SETTINGS,
  loadHumorSettings,
  saveHumorSettings,
  observeHumorSettings,
  loadRuntimeState,
  persistRuntimeState
};

export default {
  HUMOR_SETTINGS_KEY,
  HUMOR_RUNTIME_KEY,
  DEFAULT_HUMOR_SETTINGS,
  loadHumorSettings,
  saveHumorSettings,
  observeHumorSettings,
  loadRuntimeState,
  persistRuntimeState
};
