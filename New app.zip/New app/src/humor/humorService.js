import JOKE_LIBRARY, { FALLBACK_JOKE } from './jokeLibrary.js';
import {
  DEFAULT_HUMOR_SETTINGS,
  loadHumorSettings,
  saveHumorSettings,
  observeHumorSettings,
  loadRuntimeState,
  persistRuntimeState
} from './preferences.js';

let runtimeState = null;
let runtimeLoaded = false;

function getNow() {
  return Date.now();
}

async function ensureRuntimeState() {
  if (!runtimeLoaded) {
    runtimeState = await loadRuntimeState();
    runtimeLoaded = true;
  }

  if (!runtimeState || typeof runtimeState !== 'object') {
    runtimeState = { lastServed: {} };
  }

  if (!runtimeState.lastServed || typeof runtimeState.lastServed !== 'object') {
    runtimeState.lastServed = {};
  }

  return runtimeState;
}

function getToneValue(value) {
  return String(value || '').toLowerCase();
}

function filterJokesByTone(list, tone) {
  if (!Array.isArray(list) || !list.length) {
    return [];
  }

  if (tone === 'neutral') {
    return list.filter((item) => getToneValue(item.tone) === 'neutral');
  }

  if (tone === 'spicy') {
    return list.filter((item) => {
      const value = getToneValue(item.tone);
      return value === 'spicy' || value === 'playful';
    });
  }

  // default tone returns playful first, then everything else
  const playful = list.filter((item) => getToneValue(item.tone) === 'playful');
  return playful.length ? playful : list.slice();
}

function pickRandom(list, excludeId) {
  if (!Array.isArray(list) || !list.length) {
    return null;
  }
  const candidates = excludeId ? list.filter((item) => item.id !== excludeId) : list;
  if (!candidates.length) {
    return list[0];
  }
  const index = Math.floor(Math.random() * candidates.length);
  return candidates[index];
}

function findJokesForCategory(category) {
  return JOKE_LIBRARY.filter((item) => item.category === category);
}

function resolveCategory(category) {
  return typeof category === 'string' && category.trim() ? category.trim() : 'general';
}

function shouldReuseLastJoke(settings, last, now) {
  if (!settings.humorEnabled) {
    return true;
  }

  if (!last) {
    return false;
  }

  const intervalMs = Math.max(10_000, settings.rotationInterval * 1000);
  return now - last.timestamp < intervalMs;
}

async function pickJoke(category, settings) {
  const state = await ensureRuntimeState();
  const pool = findJokesForCategory(category);
  const filtered = filterJokesByTone(pool, settings.tone);
  const fallbackPool = filtered.length ? filtered : pool;
  const lastId = state.lastServed?.[category]?.id;
  return pickRandom(fallbackPool.length ? fallbackPool : [FALLBACK_JOKE], lastId) || FALLBACK_JOKE;
}

async function recordDisplay(category, joke) {
  const state = await ensureRuntimeState();
  state.lastServed[category] = {
    id: joke.id,
    text: joke.text,
    timestamp: getNow()
  };
  await persistRuntimeState(state);
}

async function getHumorPayload({ category, force = false } = {}) {
  const settings = await loadHumorSettings();

  if (!settings.humorEnabled && !force) {
    return { show: false, settings };
  }

  const activeCategory = resolveCategory(category);
  const state = await ensureRuntimeState();
  const now = getNow();
  const last = state.lastServed?.[activeCategory];

  if (!force && shouldReuseLastJoke(settings, last, now)) {
    if (last?.text) {
      return { show: true, joke: { id: last.id, text: last.text }, settings, fresh: false };
    }
  }

  const joke = await pickJoke(activeCategory, settings);
  await recordDisplay(activeCategory, joke);
  return { show: true, joke, settings, fresh: true };
}

async function updateHumorSettings(next) {
  return saveHumorSettings(next);
}

function subscribeToHumorSettings(callback) {
  return observeHumorSettings((value) => {
    if (!value || typeof value !== 'object') {
      callback?.({ ...DEFAULT_HUMOR_SETTINGS });
      return;
    }
    callback?.(value);
  });
}

async function resetHumorRuntime() {
  runtimeState = { lastServed: {} };
  runtimeLoaded = true;
  await persistRuntimeState(runtimeState);
}

export {
  DEFAULT_HUMOR_SETTINGS,
  getHumorPayload,
  loadHumorSettings,
  updateHumorSettings,
  subscribeToHumorSettings,
  resetHumorRuntime
};

export default {
  DEFAULT_HUMOR_SETTINGS,
  getHumorPayload,
  loadHumorSettings,
  updateHumorSettings,
  subscribeToHumorSettings,
  resetHumorRuntime
};
