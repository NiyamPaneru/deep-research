(function initTokenStorage(globalScope) {
  'use strict';

  const STORE_KEY = 'hf_token_encrypted_v1';
  const SECRET_KEY = 'hf_token_secret_v1';

  const logger = globalScope.logger || { debug: function noop() {} };
  const telemetry = globalScope.telemetry || { send: function noop() {} };

  const storageArea = resolveStorageArea();
  const memoryStore = new Map();

  function resolveStorageArea() {
    if (typeof chrome !== 'undefined' && chrome.storage?.local) {
      return chrome.storage.local;
    }
    if (typeof browser !== 'undefined' && browser.storage?.local) {
      return browser.storage.local;
    }
    return null;
  }

  function storageGet(keys) {
    if (!storageArea) {
      if (Array.isArray(keys)) {
        return Promise.resolve(keys.reduce((acc, key) => {
          acc[key] = memoryStore.get(key) ?? undefined;
          return acc;
        }, {}));
      }
      if (typeof keys === 'string') {
        return Promise.resolve({ [keys]: memoryStore.get(keys) ?? undefined });
      }
      if (keys && typeof keys === 'object') {
        return Promise.resolve(Object.keys(keys).reduce((acc, key) => {
          acc[key] = memoryStore.get(key) ?? keys[key];
          return acc;
        }, {}));
      }
      return Promise.resolve({});
    }

    const result = storageArea.get(keys);
    if (result && typeof result.then === 'function') {
      return result;
    }

    return new Promise((resolve, reject) => {
      storageArea.get(keys, (items) => {
        if (chrome?.runtime?.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
          return;
        }
        resolve(items || {});
      });
    });
  }

  function storageSet(items) {
    if (!items || typeof items !== 'object') {
      return Promise.resolve();
    }

    if (!storageArea) {
      Object.entries(items).forEach(([key, value]) => {
        memoryStore.set(key, value);
      });
      return Promise.resolve();
    }

    const result = storageArea.set(items);
    if (result && typeof result.then === 'function') {
      return result;
    }

    return new Promise((resolve, reject) => {
      storageArea.set(items, () => {
        if (chrome?.runtime?.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
          return;
        }
        resolve();
      });
    });
  }

  function storageRemove(keys) {
    if (!storageArea) {
      if (Array.isArray(keys)) {
        keys.forEach((key) => memoryStore.delete(key));
      } else {
        memoryStore.delete(keys);
      }
      return Promise.resolve();
    }

    const result = storageArea.remove(keys);
    if (result && typeof result.then === 'function') {
      return result;
    }

    return new Promise((resolve, reject) => {
      storageArea.remove(keys, () => {
        if (chrome?.runtime?.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
          return;
        }
        resolve();
      });
    });
  }

  function getNodeCrypto() {
    if (typeof require === 'function') {
      try {
        return require('crypto');
      } catch (_error) {
        return null;
      }
    }
    return null;
  }

  function getCrypto() {
    if (globalScope.crypto?.subtle) {
      return globalScope.crypto;
    }
    const nodeCrypto = getNodeCrypto();
    if (nodeCrypto?.webcrypto?.subtle) {
      return nodeCrypto.webcrypto;
    }
    throw new Error('CRYPTO_UNAVAILABLE');
  }

  function getNodeUtil() {
    if (typeof require === 'function') {
      try {
        return require('util');
      } catch (_error) {
        return null;
      }
    }
    return null;
  }

  function createTextEncoder() {
    if (typeof TextEncoder !== 'undefined') {
      return new TextEncoder();
    }
    const util = getNodeUtil();
    if (util?.TextEncoder) {
      return new util.TextEncoder();
    }
    throw new Error('TEXT_ENCODER_UNAVAILABLE');
  }

  function createTextDecoder() {
    if (typeof TextDecoder !== 'undefined') {
      return new TextDecoder();
    }
    const util = getNodeUtil();
    if (util?.TextDecoder) {
      return new util.TextDecoder();
    }
    throw new Error('TEXT_DECODER_UNAVAILABLE');
  }

  function toUint8Array(buffer) {
    if (buffer instanceof Uint8Array) {
      return buffer;
    }
    return new Uint8Array(buffer);
  }

  function toBase64(bytes) {
    if (typeof btoa === 'function') {
      let binary = '';
      const arr = toUint8Array(bytes);
      for (let i = 0; i < arr.length; i += 1) {
        binary += String.fromCharCode(arr[i]);
      }
      return btoa(binary);
    }
    return Buffer.from(bytes).toString('base64');
  }

  function fromBase64(value) {
    if (!value) return new Uint8Array();
    if (typeof atob === 'function') {
      const binary = atob(value);
      const bytes = new Uint8Array(binary.length);
      for (let i = 0; i < binary.length; i += 1) {
        bytes[i] = binary.charCodeAt(i);
      }
      return bytes;
    }
    return new Uint8Array(Buffer.from(value, 'base64'));
  }

  async function getSecretMaterial() {
    const cache = await storageGet([SECRET_KEY]);
    const stored = cache?.[SECRET_KEY];
    if (stored && typeof stored === 'string') {
      return fromBase64(stored);
    }

    const cryptoApi = getCrypto();
    const secret = new Uint8Array(32);
    cryptoApi.getRandomValues(secret);
    await storageSet({ [SECRET_KEY]: toBase64(secret) });
    return secret;
  }

  async function getCryptoKey() {
    const cryptoApi = getCrypto();
    const secretBytes = await getSecretMaterial();
    return cryptoApi.subtle.importKey(
      'raw',
      secretBytes,
      { name: 'AES-GCM' },
      false,
      ['encrypt', 'decrypt']
    );
  }

  async function encryptToken(token) {
    const cryptoApi = getCrypto();
    const key = await getCryptoKey();
    const iv = new Uint8Array(12);
    cryptoApi.getRandomValues(iv);
    const encoder = createTextEncoder();
    const cipherBuffer = await cryptoApi.subtle.encrypt(
      { name: 'AES-GCM', iv },
      key,
      encoder.encode(token)
    );

    return {
      iv: toBase64(iv),
      data: toBase64(toUint8Array(cipherBuffer))
    };
  }

  async function decryptToken(payload) {
    if (!payload || typeof payload !== 'object') {
      return null;
    }

    const { iv, data } = payload;
    if (!iv || !data) {
      return null;
    }

    const cryptoApi = getCrypto();
    const key = await getCryptoKey();
    const decoder = createTextDecoder();

    try {
      const decrypted = await cryptoApi.subtle.decrypt(
        { name: 'AES-GCM', iv: fromBase64(iv) },
        key,
        fromBase64(data)
      );
      return decoder.decode(decrypted);
    } catch (error) {
      logger.debug('tokenStorage decrypt failed', error?.message || error);
      return null;
    }
  }

  function mapError(code) {
    switch (code) {
      case 'HF_INVALID_TOKEN':
        return { code, message: 'Invalid Hugging Face token — re-enter or grab a new one at Hugging Face.' };
      case 'HF_MODEL_NOT_FOUND':
        return { code, message: "Model not found — try 'gpt2' or check spelling." };
      case 'HF_EMPTY_RESPONSE':
        return { code, message: 'Model returned no output — try again or switch models.' };
      case 'HF_SERVER_ERROR':
        return { code, message: 'Server error — try again shortly.' };
      case 'HF_NETWORK_ERROR':
      default:
        return { code: code || 'HF_NETWORK_ERROR', message: 'Network error — try again shortly.' };
    }
  }

  function emitTelemetry(event, payload) {
    try {
      telemetry.send(event, payload);
    } catch (_error) {
      // ignore telemetry failures
    }
  }

  async function setToken(token) {
    if (!token) {
      await clearToken();
      emitTelemetry('token_test_cleared', {});
      return { ok: true, message: 'Token cleared.' };
    }

    if (!globalScope.hfClient?.generate) {
      throw new Error('HF_CLIENT_UNAVAILABLE');
    }

    try {
      const validation = await globalScope.hfClient.generate('gpt2', token, 'Hello');
      logger.debug('tokenStorage validation status', validation.status);
      emitTelemetry('token_test_success', { status: validation.status });
    } catch (error) {
      const mapped = mapError(error?.code || error?.message || 'HF_NETWORK_ERROR');
      logger.debug('tokenStorage validation failed', mapped.code);
      emitTelemetry('token_test_fail', { code: mapped.code });
      return { ok: false, code: mapped.code, message: mapped.message };
    }

    try {
      const encrypted = await encryptToken(token);
      await storageSet({ [STORE_KEY]: encrypted });
      return { ok: true, message: 'Token saved securely.' };
    } catch (error) {
      logger.debug('tokenStorage store failed', error?.message || error);
      return { ok: false, code: 'TOKEN_STORE_FAILED', message: 'Unable to store token on this device.' };
    }
  }

  async function getToken() {
    try {
      const stored = await storageGet([STORE_KEY]);
      const payload = stored?.[STORE_KEY];
      if (!payload) {
        return null;
      }
      return await decryptToken(payload);
    } catch (error) {
      logger.debug('tokenStorage read failed', error?.message || error);
      return null;
    }
  }

  async function clearToken() {
    await storageRemove([STORE_KEY]);
  }

  const api = {
    setToken,
    getToken,
    clearToken
  };

  globalScope.tokenStorage = api;
  globalScope.tokenStore = globalScope.tokenStore || api;

  if (typeof module !== 'undefined' && module.exports) {
    module.exports = api;
  }
})(typeof self !== 'undefined' ? self : typeof globalThis !== 'undefined' ? globalThis : this);
