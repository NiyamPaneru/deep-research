'use strict';

(function defineHistoryHumorManager(globalScope) {
  class HistoryHumorManager {
    constructor() {
      this.manager = null;
      this.unsubscribe = null;
      this.isHumorEnabled = true;
    }

    async init() {
      if (!globalScope.HumorManager || !globalScope.humorManager) {
        return;
      }

      this.manager = new globalScope.HumorManager({ channel: 'history-roast' });
      await this.manager.init();

      this.isHumorEnabled = Boolean(this.manager.settings?.humorEnabled);

      this.unsubscribe = this.manager.watch(({ joke, settings }) => {
        this.isHumorEnabled = Boolean(settings?.humorEnabled);
        if (joke) {
          this.renderJoke(joke.text);
        } else {
          this.renderJoke('Humor disabled. You can re-enable it from Settings.');
        }
        this.updatePanelVisibility(settings?.humorEnabled);
      }, { replay: true });
    }

    updatePanelVisibility(enabled) {
      const humorPanel = document.getElementById('humor-panel');
      const footer = document.querySelector('.humor-footer');

      const shouldShow = Boolean(enabled);
      if (humorPanel) {
        humorPanel.style.display = shouldShow ? 'flex' : 'none';
      }
      if (footer) {
        footer.style.display = shouldShow ? 'block' : 'none';
      }
    }

    renderJoke(text) {
      const target = document.getElementById('humor-text');
      if (!target) {
        return;
      }

      target.classList.add('fade-out');
      target.classList.remove('fade-in');

      setTimeout(() => {
        target.textContent = text || '';
        target.classList.remove('fade-out');
        target.classList.add('fade-in');
      }, 180);
    }

    async updateHumorDisplay(category = 'history-roast') {
      if (!globalScope.humorManager) {
        return;
      }
      const joke = await globalScope.humorManager.getJoke(category, { force: true });
      if (joke && joke.text) {
        this.renderJoke(joke.text);
      }
    }

    async toggleHumor() {
      if (!globalScope.humorManager) {
        return false;
      }

      const next = !this.isHumorEnabled;
      await globalScope.humorManager.updateSettings({ humorEnabled: next });
      this.isHumorEnabled = next;
      this.updatePanelVisibility(next);
      if (next) {
        await this.updateHumorDisplay('history-roast');
      }
      return next;
    }

    destroy() {
      if (typeof this.unsubscribe === 'function') {
        this.unsubscribe();
      }
      if (this.manager) {
        this.manager.destroy?.();
      }
    }
  }

  globalScope.HistoryHumorManager = HistoryHumorManager;
})(typeof window !== 'undefined' ? window : globalThis);
