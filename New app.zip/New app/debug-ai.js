// Debug script to test AI generation
console.log('🔍 Debugging AI Generation...');

// Test 1: Check if token is available
async function testToken() {
  try {
    const response = await chrome.runtime.sendMessage({ action: 'getToken' });
    console.log('Token status:', response);
    return response;
  } catch (error) {
    console.error('Token check failed:', error);
    return null;
  }
}

// Test 2: Test direct generation
async function testGeneration() {
  try {
    console.log('Testing AI generation...');
    const response = await chrome.runtime.sendMessage({ 
      action: 'generate', 
      input: 'Hello world', 
      responses: 1 
    });
    console.log('Generation result:', response);
    return response;
  } catch (error) {
    console.error('Generation failed:', error);
    return null;
  }
}

// Test 3: Check background script status
async function testBackground() {
  try {
    const response = await chrome.runtime.sendMessage({ action: 'ping' });
    console.log('Background status:', response);
    return response;
  } catch (error) {
    console.error('Background ping failed:', error);
    return null;
  }
}

// Run all tests
async function runTests() {
  console.log('=== AI Debug Tests ===');
  
  const bgStatus = await testBackground();
  if (!bgStatus?.ok) {
    console.error('❌ Background script not ready');
    return;
  }
  
  const tokenStatus = await testToken();
  if (!tokenStatus?.hasToken) {
    console.error('❌ No token available');
    return;
  }
  
  const genResult = await testGeneration();
  if (genResult?.outputs?.length) {
    console.log('✅ AI generation working!');
  } else {
    console.error('❌ AI generation failed:', genResult);
  }
}

// Auto-run when script loads
if (typeof chrome !== 'undefined') {
  runTests();
} else {
  console.log('Run this in the extension popup console');
}