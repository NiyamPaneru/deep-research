const path = require('path');
const { test, expect } = require('@playwright/test');

const extensionPath = path.resolve(__dirname, '..');
const popupFile = path.join(extensionPath, 'popup-new.html');
const popupUrl = `file://${popupFile.replace(/\\/g, '/')}`;

test.describe('Smart Clipboard AI popup', () => {
  test('renders generate button and history panel can open', async ({ page }) => {
    await page.goto(popupUrl);

    await expect(page.getByRole('button', { name: /Generate with AI/i })).toBeVisible();
    await page.getByRole('button', { name: /Open history/i }).click();
    await expect(page.getByRole('dialog', { name: /Clipboard history/i })).toBeVisible();
  });
});
