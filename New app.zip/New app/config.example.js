// Configuration template - DO NOT commit real values
// Copy this to config.js and fill in your actual values

const CONFIG = {
  SUPABASE_URL: 'https://your-project.supabase.co',
  SUPABASE_FUNCTIONS_URL: 'https://your-project.supabase.co/functions/v1',
  HF_SHARED_TOKEN: '', // Optional: Shared Hugging Face token for demo mode
  AUTH_REDIRECT_URL: 'https://your-extension-id.chromiumapp.org/auth-callback.html',
  ALLOWED_ORIGINS: ['http://localhost:54321'],
  ROCKETHUB_PROMO_END: '', // ISO date string, e.g., '2024-02-15T00:00:00Z'
  ROCKETHUB_PROMO_DEFAULT_DAYS: 14,
  TIER_POLICIES: {
    free: {
      type: 'free',
      quota: { windowMs: 36 * 60 * 60 * 1000, max: 3 },
      defaultModel: 'gpt2'
    },
    ltd: {
      type: 'license',
      quota: null,
      defaultModel: 'tiiuae/falcon-7b-instruct'
    },
    pro: {
      type: 'subscription',
      quota: null,
      defaultModel: 'tiiuae/falcon-7b-instruct'
    }
  }
};

export default CONFIG;
export { CONFIG };
