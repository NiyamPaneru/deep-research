// GPT-5 Refactor: Centralized debug logging guard.
const DEBUG_FLAG_KEY = 'debug_logging_enabled';

let debugEnabled = null;

async function loadDebugFlag() {
  if (debugEnabled !== null) {
    return debugEnabled;
  }

  try {
    if (typeof chrome !== 'undefined' && chrome.storage?.local) {
      const result = await chrome.storage.local.get([DEBUG_FLAG_KEY]);
      debugEnabled = Boolean(result[DEBUG_FLAG_KEY]);
      return debugEnabled;
    }
  } catch (_error) {
    // ignore storage failures
  }

  debugEnabled = false;
  return debugEnabled;
}

function debugLog(message, payload) {
  if (debugEnabled === null) {
    void loadDebugFlag().then(() => {
      if (debugEnabled) {
        console.debug('[SmartClipboard]', message, payload ?? null);
      }
    });
    return;
  }

  if (debugEnabled) {
    console.debug('[SmartClipboard]', message, payload ?? null);
  }
}

export { loadDebugFlag, debugLog };
