'use strict';

(function initSettingsPage(globalScope) {
  const THEME_KEY = 'smart_clipboard_theme';
  const DEVICE_KEY = 'smartClipboard_deviceId_v1';

  document.addEventListener('DOMContentLoaded', () => {
    const navButtons = Array.from(document.querySelectorAll('[data-section]'));
    const panels = Array.from(document.querySelectorAll('.settings-panel'));
    const themeToggleButton = document.getElementById('theme-toggle');

    const hf = {
      input: document.getElementById('hf-token'),
      button: document.getElementById('hf-connect'),
      status: document.getElementById('hf-status'),
      message: document.getElementById('hf-message'),
      helpToggle: document.getElementById('hf-help-toggle'),
      helpPanel: document.getElementById('hf-help')
    };



    const toggles = {
      humor: { el: document.getElementById('humor-toggle'), key: 'humorEnabled', default: true },
      autosave: { el: document.getElementById('autosave-toggle'), key: 'autosaveEnabled', default: false },
      alerts: { el: document.getElementById('alerts-toggle'), key: 'alertsEnabled', default: true }
    };

    const humorInterval = document.getElementById('humor-interval');
    const rocketHubSection = document.getElementById('rockethub-section');
    const proSection = document.getElementById('pro-section');
    const deviceIdLabel = document.getElementById('device-id');
    const clearDataButton = document.getElementById('clear-data');
    const openButtons = Array.from(document.querySelectorAll('[data-open]'));
    const planButtons = Array.from(document.querySelectorAll('[data-upgrade-plan]'));

    navButtons.forEach((button) => {
      button.addEventListener('click', () => activatePanel(button.dataset.section, navButtons, panels));
    });

    themeToggleButton?.addEventListener('click', () => {
      const current = document.documentElement.getAttribute('data-theme') || 'light';
      const next = current === 'dark' ? 'light' : 'dark';
      applyTheme(next, themeToggleButton);
      void persistTheme(next);
    });

    attachHelpToggle(hf.helpToggle, hf.helpPanel);

    hf.button?.addEventListener('click', async () => {
      const token = (hf.input?.value || '').trim();
      if (!token) {
        showStatus(hf.message, 'Enter a Hugging Face token first.', 'error');
        updateStatusPill(hf.status, false);
        return;
      }

  setButtonBusy(hf.button, true, 'Connecting...');
  showStatus(hf.message, 'Verifying token...', 'info');

      const valid = await testHuggingFaceToken(token);
      if (valid) {
        await storageSet({ hfToken: token });
        updateStatusPill(hf.status, true);
        showStatus(hf.message, 'Connected to Hugging Face ✓', 'success');
      } else {
        updateStatusPill(hf.status, false);
        showStatus(hf.message, 'Token failed validation. Double-check permissions.', 'error');
      }

  setButtonBusy(hf.button, false, 'Connect');
    });



    Object.values(toggles).forEach(({ el, key }) => {
      el?.addEventListener('click', async () => {
        const next = !el.classList.contains('active');
        el.classList.toggle('active', next);
        await storageSet({ [key]: next });
        
        if (key === 'humorEnabled' && globalScope.humorManager) {
          if (next) {
            await globalScope.humorManager.enable();
          } else {
            await globalScope.humorManager.disable();
          }
        }
      });
    });

    humorInterval?.addEventListener('change', async () => {
      const seconds = parseInt(humorInterval.value) || 90;
      await storageSet({ humorRotationInterval: seconds });
      if (globalScope.humorManager?.setRotationInterval) {
        await globalScope.humorManager.setRotationInterval(seconds);
      }
    });

    openButtons.forEach((button) => {
      button.addEventListener('click', () => openLink(button.dataset.open));
    });

    planButtons.forEach((button) => {
      button.addEventListener('click', () => openUpgradeFlow(button.dataset.upgradePlan));
    });

    // LTD Activation - TEMPORARILY DISABLED until Supabase backend is ready
    // document.getElementById('activate-ltd-btn')?.addEventListener('click', async () => {
    //   await activateLTDLicense();
    // });

    // Pro Activation - TEMPORARILY DISABLED until Supabase backend is ready
    // document.getElementById('activate-pro-btn')?.addEventListener('click', async () => {
    //   await activateProLicense();
    // });

    // Pro Management - TEMPORARILY DISABLED until Supabase backend is ready
    // document.getElementById('manage-subscription-btn')?.addEventListener('click', () => {
    //   chrome.tabs.create({
    //     url: 'https://app.gumroad.com/library'
    //   });
    // });

    // document.getElementById('refresh-status-btn')?.addEventListener('click', async () => {
    //   setButtonBusy(document.getElementById('refresh-status-btn'), true, 'Checking...');
    //   
    //   const result = await chrome.runtime.sendMessage({
    //     action: 'checkProStatus'
    //   });
    //   
    //   setButtonBusy(document.getElementById('refresh-status-btn'), false, '🔄 Refresh Status');
    //   
    //   if (result.active) {
    //     showStatus(document.getElementById('pro-message'), '✅ Subscription is active', 'success');
    //     updateSubscriptionUI(result);
    //   } else {
    //     showStatus(document.getElementById('pro-message'), '⚠️ Subscription has ended. Renew to continue Pro access.', 'error');
    //     document.getElementById('pro-management-card').style.display = 'none';
    //     document.getElementById('pro-activation-card').style.display = 'block';
    //   }
    // });

    clearDataButton?.addEventListener('click', async () => {
      const confirmClear = globalScope.confirm?.('Clear all extension data? This action cannot be undone.');
      if (!confirmClear) {
        return;
      }

      await storageClear();
      hf.input && (hf.input.value = '');
      updateStatusPill(hf.status, false);
      showStatus(hf.message, 'Data cleared. Reconnect to continue.', 'info');

      Object.values(toggles).forEach(({ el, default: defaultValue }) => {
        if (el) {
          el.classList.toggle('active', Boolean(defaultValue));
        }
      });

        await storageSet({
          hfToken: '',
          humorEnabled: toggles.humor.default,
          autosaveEnabled: toggles.autosave.default,
          alertsEnabled: toggles.alerts.default
        });
    });

    void loadTheme(themeToggleButton);
    void loadSettings({ hf, toggles, deviceIdLabel });
    void loadUserStatus();
    void checkRocketHubPromo();
  });

  function activatePanel(sectionKey, navButtons, panels) {
    navButtons.forEach((button) => {
      button.classList.toggle('active', button.dataset.section === sectionKey);
    });
    panels.forEach((panel) => {
      panel.classList.toggle('active', panel.dataset.panel === sectionKey);
    });
  }

  function attachHelpToggle(toggleButton, panel) {
    toggleButton?.addEventListener('click', () => {
      const isShown = panel?.classList.contains('show');
      panel?.classList.toggle('show', !isShown);
    });
  }

  async function loadSettings({ hf, toggles, deviceIdLabel }) {
    const defaults = {
      hfToken: '',
      humorEnabled: true,
      autosaveEnabled: false,
      alertsEnabled: true,
      humorRotationInterval: 90
    };

    const stored = await storageGet(defaults);

    if (hf.input) {
      hf.input.value = stored.hfToken;
      updateStatusPill(hf.status, Boolean(stored.hfToken));
    }

    Object.values(toggles).forEach(({ el, key, default: fallback }) => {
      if (el) {
        el.classList.toggle('active', stored[key] ?? fallback);
      }
    });

    if (deviceIdLabel) {
      const device = await storageGet({ [DEVICE_KEY]: '—' });
      deviceIdLabel.textContent = device[DEVICE_KEY] || 'Not assigned yet';
    }

    if (humorInterval) {
      humorInterval.value = stored.humorRotationInterval || 90;
    }
  }

  async function checkRocketHubPromo() {
    const promoStart = new Date('2024-12-01').getTime();
    const promoEnd = promoStart + (14 * 24 * 60 * 60 * 1000);
    const now = Date.now();
    
    const showRocketHub = now >= promoStart && now <= promoEnd;
    
    if (rocketHubSection) {
      rocketHubSection.style.display = showRocketHub ? 'block' : 'none';
    }
    if (proSection) {
      proSection.style.display = showRocketHub ? 'none' : 'block';
    }
  }

  async function loadTheme(themeToggleButton) {
    const stored = await readStoredTheme();
    const theme = stored || detectPreferredTheme();
    applyTheme(theme, themeToggleButton);
  }

  function applyTheme(theme, toggleButton) {
    document.documentElement.setAttribute('data-theme', theme);
    document.body?.setAttribute('data-theme', theme);
    if (toggleButton) {
      toggleButton.textContent = theme === 'dark' ? 'Use Light Theme' : 'Use Dark Theme';
    }
  }

  async function readStoredTheme() {
    if (typeof chrome === 'undefined' || !chrome.storage?.local) {
      try {
        return globalScope.localStorage?.getItem(THEME_KEY) || null;
      } catch (_error) {
        return null;
      }
    }

    return new Promise((resolve) => {
      try {
        chrome.storage.local.get({ [THEME_KEY]: null }, (items) => {
          if (chrome.runtime?.lastError) {
            resolve(null);
            return;
          }
          resolve(items?.[THEME_KEY] || null);
        });
      } catch (_error) {
        resolve(null);
      }
    });
  }

  function detectPreferredTheme() {
    try {
      return globalScope.matchMedia && globalScope.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
    } catch (_error) {
      return 'light';
    }
  }

  async function persistTheme(theme) {
    if (typeof chrome === 'undefined' || !chrome.storage?.local) {
      try {
        globalScope.localStorage?.setItem(THEME_KEY, theme);
      } catch (_error) {
        // ignore
      }
      return;
    }

    await new Promise((resolve) => {
      try {
        chrome.storage.local.set({ [THEME_KEY]: theme }, () => resolve());
      } catch (_error) {
        resolve();
      }
    });
  }

  function showStatus(banner, message, variant) {
    if (!banner) {
      return;
    }
    banner.innerHTML = message.replace(/\n/g, '<br>');
    banner.className = 'status-banner show';
    if (variant) {
      banner.classList.add(variant);
    }
    if (banner._hideTimer) {
      clearTimeout(banner._hideTimer);
    }
    banner._hideTimer = setTimeout(() => {
      banner.classList.remove('show', 'success', 'error', 'info');
      banner._hideTimer = null;
    }, 8000);
  }

  function setButtonBusy(button, isBusy, busyLabel) {
    if (!button) {
      return;
    }
    if (!button.dataset.idleLabel) {
      button.dataset.idleLabel = button.textContent || '';
    }
    button.disabled = isBusy;
    button.textContent = isBusy ? busyLabel : button.dataset.idleLabel;
  }

  function updateStatusPill(pill, isConnected) {
    if (!pill) {
      return;
    }
    pill.classList.toggle('is-connected', Boolean(isConnected));
    pill.textContent = isConnected ? 'Connected' : 'Disconnected';
    const dot = document.createElement('span');
    dot.className = 'status-dot';
    pill.prepend(dot);
  }

  async function testHuggingFaceToken(token) {
    try {
      const response = await fetch('https://api-inference.huggingface.co/models/gpt2', {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ inputs: 'Smart Clipboard test ping', parameters: { max_new_tokens: 1 } })
      });
      return response.ok;
    } catch (_error) {
      return false;
    }
  }



  function openLink(path) {
    if (!path) {
      return;
    }

    if (path.startsWith('http')) {
      globalScope.open(path, '_blank', 'noopener');
      return;
    }

    if (typeof chrome !== 'undefined' && chrome.runtime?.getURL) {
      const url = chrome.runtime.getURL(path);
      if (chrome.tabs?.create) {
        chrome.tabs.create({ url });
        return;
      }
      globalScope.open(url, '_blank');
      return;
    }

    globalScope.open(path, '_blank');
  }

  function openUpgradeFlow(plan) {
    const url = plan ? `upgrade.html?plan=${encodeURIComponent(plan)}` : 'upgrade.html';
    openLink(url);
  }

  function storageGet(defaults) {
    if (typeof chrome === 'undefined' || !chrome.storage?.local) {
      return Promise.resolve({ ...defaults });
    }

    return new Promise((resolve) => {
      try {
        chrome.storage.local.get(defaults, (items) => {
          if (chrome.runtime?.lastError) {
            resolve({ ...defaults });
            return;
          }
          resolve(items);
        });
      } catch (_error) {
        resolve({ ...defaults });
      }
    });
  }

  function storageSet(values) {
    if (typeof chrome === 'undefined' || !chrome.storage?.local) {
      return Promise.resolve(false);
    }

    return new Promise((resolve) => {
      try {
        chrome.storage.local.set(values, () => {
          resolve(!chrome.runtime?.lastError);
        });
      } catch (_error) {
        resolve(false);
      }
    });
  }

  function storageClear() {
    if (typeof chrome === 'undefined' || !chrome.storage?.local) {
      return Promise.resolve(false);
    }

    return new Promise((resolve) => {
      try {
        chrome.storage.local.clear(() => {
          resolve(!chrome.runtime?.lastError);
        });
      } catch (_error) {
        resolve(false);
      }
    });
  }

  // LTD activation with mandatory sign-in
  async function activateLTDLicense() {
    const licenseKey = document.getElementById('ltd-license-key').value.trim();
    const email = document.getElementById('ltd-email').value.trim();
    
    if (!licenseKey || !email) {
      showStatus(document.getElementById('ltd-message'), 'Please enter both license key and email', 'error');
      return;
    }
    
    setButtonBusy(document.getElementById('activate-ltd-btn'), true, 'Verifying...');
    
    // Step 1: Verify license with Supabase
    const verifyResult = await chrome.runtime.sendMessage({
      action: 'verifyLTDLicense',
      licenseKey,
      email
    });
    
    if (!verifyResult.success) {
      setButtonBusy(document.getElementById('activate-ltd-btn'), false, 'Activate License');
      showStatus(document.getElementById('ltd-message'), verifyResult.error, 'error');
      return;
    }
    
    // Step 2: MANDATORY Google Sign-In
    showStatus(document.getElementById('ltd-message'), 'License verified! Now sign in with Google to activate...', 'info');
    
    const signInResult = await chrome.runtime.sendMessage({
      action: 'signInWithGoogle'
    });
    
    if (!signInResult.success) {
      setButtonBusy(document.getElementById('activate-ltd-btn'), false, 'Activate License');
      showStatus(document.getElementById('ltd-message'), 'Sign-in required to activate Lifetime access', 'error');
      return;
    }
    
    // Step 3: Save to Supabase (cloud backup)
    const saveResult = await chrome.runtime.sendMessage({
      action: 'saveLTDToCloud',
      userId: signInResult.userId,
      email: signInResult.email,
      licenseKey: licenseKey,
      licenseEmail: email
    });
    
    if (!saveResult.success) {
      setButtonBusy(document.getElementById('activate-ltd-btn'), false, 'Activate License');
      showStatus(document.getElementById('ltd-message'), 'Failed to save license. Please try again.', 'error');
      return;
    }
    
    // Step 4: Store locally for offline access
    await storageSet({
      userTier: 'ltd',
      userId: signInResult.userId,
      email: signInResult.email,
      licenseKey: licenseKey,
      activatedAt: Date.now()
    });
    
    setButtonBusy(document.getElementById('activate-ltd-btn'), false, 'Activate License');
    
    showStatus(document.getElementById('ltd-message'), `
✅ Lifetime Deal Activated!

Your benefits:
• 50 AI generations per day
• Falcon-7B model (better quality)
• Lifetime access
• Works on all your devices

Your license is safely backed up to the cloud.
    `, 'success');
    
    // Refresh UI to show activated status
    loadUserStatus();
  }

  // Pro activation with mandatory sign-in
  async function activateProLicense() {
    const licenseKey = document.getElementById('pro-license-key').value.trim();
    
    if (!licenseKey) {
      showStatus(document.getElementById('pro-message'), 'Please enter your Gumroad license key', 'error');
      return;
    }
    
    setButtonBusy(document.getElementById('activate-pro-btn'), true, 'Verifying...');
    
    // Step 1: Verify license with Gumroad API
    const verifyResult = await chrome.runtime.sendMessage({
      action: 'verifyGumroadLicense',
      licenseKey
    });
    
    if (!verifyResult.success) {
      setButtonBusy(document.getElementById('activate-pro-btn'), false, 'Activate License');
      showStatus(document.getElementById('pro-message'), verifyResult.error, 'error');
      return;
    }
    
    // Step 2: MANDATORY Google Sign-In
    showStatus(document.getElementById('pro-message'), 'License verified! Now sign in with Google to activate...', 'info');
    
    const signInResult = await chrome.runtime.sendMessage({
      action: 'signInWithGoogle'
    });
    
    if (!signInResult.success) {
      setButtonBusy(document.getElementById('activate-pro-btn'), false, 'Activate License');
      showStatus(document.getElementById('pro-message'), 'Sign-in required to activate Pro', 'error');
      return;
    }
    
    // Step 3: Save to Supabase
    const saveResult = await chrome.runtime.sendMessage({
      action: 'saveProToCloud',
      userId: signInResult.userId,
      email: signInResult.email,
      licenseKey: licenseKey,
      gumroadEmail: verifyResult.email
    });
    
    if (!saveResult.success) {
      setButtonBusy(document.getElementById('activate-pro-btn'), false, 'Activate License');
      showStatus(document.getElementById('pro-message'), 'Failed to save subscription. Please try again.', 'error');
      return;
    }
    
    // Step 4: Store locally
    await storageSet({
      userTier: 'pro',
      userId: signInResult.userId,
      email: signInResult.email,
      gumroadLicenseKey: licenseKey,
      activatedAt: Date.now()
    });
    
    setButtonBusy(document.getElementById('activate-pro-btn'), false, 'Activate License');
    
    showStatus(document.getElementById('pro-message'), `
✅ Pro Activated!

Your benefits:
• Unlimited AI generations
• Falcon-7B model (best quality)
• Priority support
• Works on all your devices

Your subscription is safely backed up to the cloud.
    `, 'success');
    
    // Refresh UI
    loadUserStatus();
  }

  // Load user status and show appropriate cards
  async function loadUserStatus() {
    const data = await storageGet(['userTier', 'email', 'gumroadLicenseKey']);
    
    if (data.userTier === 'pro' && data.gumroadLicenseKey) {
      // Show Pro management card
      document.getElementById('pro-activation-card').style.display = 'none';
      document.getElementById('pro-management-card').style.display = 'block';
      document.getElementById('pro-email').textContent = data.email || 'user@gmail.com';
      
      // Check subscription status
      const statusResult = await chrome.runtime.sendMessage({
        action: 'checkProStatus'
      });
      
      if (statusResult && statusResult.active) {
        updateSubscriptionUI(statusResult);
      }
    } else if (data.userTier === 'ltd') {
      // Hide LTD activation card and show LTD status card
      document.getElementById('ltd-activation-card').style.display = 'none';
      document.getElementById('ltd-status-card').style.display = 'block';
      document.getElementById('ltd-email').textContent = data.email || 'user@gmail.com';
    }
  }

  // Update subscription UI with current status
  function updateSubscriptionUI(statusData) {
    if (statusData.nextBilling) {
      document.getElementById('next-billing').textContent = new Date(statusData.nextBilling).toLocaleDateString();
    }
    if (statusData.status) {
      document.getElementById('sub-status').textContent = statusData.status;
    }
  }
})(typeof window !== 'undefined' ? window : global);
