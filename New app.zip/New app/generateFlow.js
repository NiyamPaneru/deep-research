(function initGenerateFlow(globalScope) {
  'use strict';

  const inflightMap = new WeakMap();

  function resolveButton(buttonElem) {
    if (buttonElem) return buttonElem;
    if (typeof document === 'undefined') return null;
    return document.querySelector('[data-primary="generate"]');
  }

  function getSpinner(button) {
    if (!button) return null;
    return button.querySelector('[data-spinner="generate"]') || button.querySelector('[data-spinner]');
  }

  function toggleState(button, loading) {
    if (!button) return;
    button.disabled = loading;
    button.classList.toggle('is-loading', loading);
    button.setAttribute('aria-busy', loading ? 'true' : 'false');
    const spinner = getSpinner(button);
    if (spinner) {
      spinner.hidden = !loading;
      spinner.setAttribute('aria-hidden', loading ? 'false' : 'true');
    }
  }

  function startCall(buttonElem) {
    const button = resolveButton(buttonElem);
    if (!button) return;
    const count = inflightMap.get(button) || 0;
    inflightMap.set(button, count + 1);
    if (count === 0) {
      toggleState(button, true);
    }
  }

  function endCall(buttonElem, success) {
    const button = resolveButton(buttonElem);
    if (!button) return Boolean(success);
    const previous = inflightMap.get(button) || 0;
    const next = Math.max(0, previous - 1);
    inflightMap.set(button, next);
    if (next === 0) {
      toggleState(button, false);
    }
    return Boolean(success);
  }

  const api = {
    startCall,
    endCall
  };

  globalScope.generateFlow = api;

  if (typeof module !== 'undefined' && module.exports) {
    module.exports = api;
  }
})(typeof self !== 'undefined' ? self : typeof globalThis !== 'undefined' ? globalThis : this);