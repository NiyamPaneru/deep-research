// Quick Supabase connectivity test
// Run with: node test-supabase.js

const CONFIG = {
  SUPABASE_URL: '', // ← Add your Supabase URL here
  SUPABASE_ANON_KEY: '', // ← Add your anon key here
};

async function testSupabase() {
  console.log('🔍 Testing Supabase Connection...\n');

  // Check if config is set
  if (!CONFIG.SUPABASE_URL || CONFIG.SUPABASE_URL === '') {
    console.log('❌ SUPABASE_URL not configured');
    console.log('   → Update CONFIG.SUPABASE_URL in this file\n');
    return false;
  }

  if (!CONFIG.SUPABASE_ANON_KEY || CONFIG.SUPABASE_ANON_KEY === '') {
    console.log('⚠️  SUPABASE_ANON_KEY not configured (optional for some tests)');
    console.log('   → Update CONFIG.SUPABASE_ANON_KEY in this file\n');
  }

  console.log(`📡 Testing: ${CONFIG.SUPABASE_URL}\n`);

  // Test 1: Check if Supabase is reachable
  try {
    console.log('Test 1: Checking Supabase health...');
    const healthResponse = await fetch(`${CONFIG.SUPABASE_URL}/rest/v1/`, {
      method: 'HEAD',
      headers: {
        'apikey': CONFIG.SUPABASE_ANON_KEY || 'test'
      }
    });
    
    if (healthResponse.ok || healthResponse.status === 401) {
      console.log('✅ Supabase is reachable\n');
    } else {
      console.log(`⚠️  Unexpected status: ${healthResponse.status}\n`);
    }
  } catch (error) {
    console.log('❌ Cannot reach Supabase');
    console.log(`   Error: ${error.message}\n`);
    return false;
  }

  // Test 2: Check verify_ltd function
  try {
    console.log('Test 2: Testing verify_ltd Edge Function...');
    const verifyResponse = await fetch(`${CONFIG.SUPABASE_URL}/functions/v1/verify_ltd`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        licenseKey: 'TEST-LTD-12345',
        email: 'test@example.com'
      })
    });

    const verifyData = await verifyResponse.json();
    
    if (verifyResponse.ok && verifyData.valid) {
      console.log('✅ verify_ltd function is working');
      console.log(`   Response: ${JSON.stringify(verifyData)}\n`);
    } else if (verifyResponse.status === 404) {
      console.log('❌ verify_ltd function not found (not deployed)');
      console.log('   → Run: supabase functions deploy verify_ltd\n');
    } else {
      console.log(`⚠️  verify_ltd returned: ${JSON.stringify(verifyData)}`);
      console.log('   This might be expected if test license doesn\'t exist\n');
    }
  } catch (error) {
    console.log('❌ verify_ltd function test failed');
    console.log(`   Error: ${error.message}\n`);
  }

  // Test 3: Check generate function
  try {
    console.log('Test 3: Testing generate Edge Function...');
    const generateResponse = await fetch(`${CONFIG.SUPABASE_URL}/functions/v1/generate`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        prompt: 'Test prompt',
        useCase: 'headline'
      })
    });

    if (generateResponse.ok) {
      const generateData = await generateResponse.json();
      console.log('✅ generate function is working');
      console.log(`   Outputs: ${generateData.outputs?.length || 0} items\n`);
    } else if (generateResponse.status === 404) {
      console.log('❌ generate function not found (not deployed)');
      console.log('   → Run: supabase functions deploy generate\n');
    } else {
      console.log(`⚠️  generate returned status: ${generateResponse.status}\n`);
    }
  } catch (error) {
    console.log('❌ generate function test failed');
    console.log(`   Error: ${error.message}\n`);
  }

  // Summary
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
  console.log('📋 Summary:');
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n');
  
  if (!CONFIG.SUPABASE_URL || CONFIG.SUPABASE_URL === '') {
    console.log('❌ Supabase NOT configured');
    console.log('\n📖 Next steps:');
    console.log('1. Create Supabase project at https://supabase.com');
    console.log('2. Update CONFIG in this file with your project URL');
    console.log('3. Run this test again\n');
    console.log('📄 See SUPABASE_STATUS_CHECK.md for detailed setup guide\n');
  } else {
    console.log('✅ Supabase URL is configured');
    console.log('\n📖 Next steps:');
    console.log('1. Deploy Edge Functions if not already done');
    console.log('2. Create database tables (see SUPABASE_STATUS_CHECK.md)');
    console.log('3. Update config.js with your Supabase URL');
    console.log('4. Test in Chrome extension\n');
  }

  return true;
}

// Run the test
testSupabase().catch(error => {
  console.error('Test failed:', error);
  process.exit(1);
});
