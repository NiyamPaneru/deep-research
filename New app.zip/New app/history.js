'use strict';

(function initHistoryPage(globalScope) {
  if (typeof document === 'undefined') {
    return;
  }

  const THEME_KEY = 'smart_clipboard_theme';

  const state = {
    history: [],
    filtered: [],
    filter: 'all',
    query: ''
  };

  const dom = {};
  let humorManager = null;

  document.addEventListener('DOMContentLoaded', () => {
    cacheDom();
    bindEvents();
    void applySavedTheme();
    void loadHistory();
    void initHumor();
  });

  function cacheDom() {
    dom.list = document.getElementById('history-list');
    dom.emptyState = document.getElementById('empty-state');
    dom.search = document.getElementById('search-input');
    dom.clearAll = document.getElementById('clear-all-btn');
    dom.themeToggle = document.getElementById('theme-btn');
    dom.filterChips = Array.from(document.querySelectorAll('.filter-chip'));
    dom.confirmModal = document.getElementById('confirm-modal');
    dom.confirmBtn = document.getElementById('confirm-btn');
    dom.cancelBtn = document.getElementById('cancel-btn');
    dom.humorPanel = document.getElementById('humor-panel');
    dom.toggleHumor = document.getElementById('humor-toggle-btn');
    dom.saveCurrentButtons = Array.from(document.querySelectorAll('[data-save-current="true"]'));
    dom.statTotal = document.getElementById('stat-total-count');
    dom.statWeek = document.getElementById('stat-week-count');
    dom.statToday = document.getElementById('stat-today-count');
    dom.statFilter = document.getElementById('stat-filter-count');
  dom.statLastActivity = document.getElementById('stat-last-activity');
  dom.statAi = document.getElementById('stat-ai-count');
    dom.emptyTitle = dom.emptyState?.querySelector('.empty-title') || null;
    dom.emptyCopy = dom.emptyState?.querySelector('.empty-copy') || null;
    dom.emptyAction = dom.emptyState?.querySelector('[data-save-current="true"]') || null;
  }

  function bindEvents() {
    dom.search?.addEventListener('input', handleSearch);
    dom.clearAll?.addEventListener('click', handleClearAll);
    dom.themeToggle?.addEventListener('click', toggleTheme);
    dom.list?.addEventListener('click', handleHistoryAction);
    dom.toggleHumor?.addEventListener('click', handleHumorToggle);
    dom.saveCurrentButtons.forEach((button) => {
      button.addEventListener('click', handleSaveCurrent);
    });

    dom.filterChips.forEach((chip) => {
      chip.addEventListener('click', () => {
        const nextFilter = chip.dataset.filter || 'all';
        if (state.filter === nextFilter) {
          return;
        }
        setFilter(nextFilter);
      });
    });
  }

  async function loadHistory() {
    const response = await sendMessage('getClipboardHistory');
    const rawHistory = Array.isArray(response?.history) ? response.history : [];
    state.history = normalizeHistory(rawHistory);
    applyFilters();
  }

  function handleSearch(event) {
    state.query = (event.target?.value || '').trim().toLowerCase();
    applyFilters();
  }

  function setFilter(filterKey) {
    state.filter = filterKey;
    dom.filterChips.forEach((chip) => {
      const isActive = (chip.dataset.filter || 'all') === filterKey;
      chip.classList.toggle('active', isActive);
      chip.setAttribute('aria-pressed', String(isActive));
    });
    applyFilters();
  }

  function applyFilters() {
    const query = state.query;
    const filterKey = state.filter;

    const filtered = state.history.filter((item) => {
      const text = (item?.text || '').toLowerCase();
      if (query && !text.includes(query)) {
        return false;
      }

      if (filterKey === 'today') {
        return isWithinDays(item?.timestamp, 0);
      }

      if (filterKey === 'week') {
        return isWithinDays(item?.timestamp, 6);
      }

      return true;
    });

    state.filtered = normalizeHistory(filtered, { skipSort: true });
    updateStats();
    renderHistory();
  }

  function isWithinDays(timestamp, daysBack) {
    if (!timestamp) {
      return false;
    }

    try {
      const itemDate = new Date(timestamp);
      if (Number.isNaN(itemDate.getTime())) {
        return false;
      }

      const start = new Date();
      start.setHours(0, 0, 0, 0);
      start.setDate(start.getDate() - daysBack);

      const end = new Date();
      end.setHours(23, 59, 59, 999);

      return itemDate >= start && itemDate <= end;
    } catch (_error) {
      return false;
    }
  }

  function renderHistory() {
    if (!dom.list || !dom.emptyState) {
      return;
    }

    dom.list.innerHTML = '';

    if (!state.filtered.length) {
      dom.emptyState.classList.remove('hidden');
      if (state.query) {
        if (dom.emptyTitle) {
          dom.emptyTitle.textContent = 'No matches found';
        }
        if (dom.emptyCopy) {
          dom.emptyCopy.textContent = 'Try adjusting your search or reset the filters to see everything.';
        }
        dom.emptyAction?.classList.add('hidden');
        if (humorManager) {
          humorManager.updateHumorDisplay('search-no-results');
        }
      } else {
        if (dom.emptyTitle) {
          dom.emptyTitle.textContent = 'Clipboard is quiet';
        }
        if (dom.emptyCopy) {
          dom.emptyCopy.textContent = 'Copy text anywhere to see it appear here instantly.';
        }
        dom.emptyAction?.classList.remove('hidden');
        if (humorManager) {
          humorManager.updateHumorDisplay('empty-state');
        }
      }
      return;
    }

    dom.emptyState.classList.add('hidden');
    dom.emptyAction?.classList.remove('hidden');

    const fragment = document.createDocumentFragment();
    state.filtered.forEach((item) => {
      const card = buildHistoryCard(item);
      fragment.appendChild(card);
    });

    dom.list.appendChild(fragment);
    if (humorManager) {
      humorManager.updateHumorDisplay('history-roast');
    }
  }

  function buildHistoryCard(item) {
    const card = document.createElement('article');
    card.className = 'history-item';
    card.dataset.id = String(item?.id ?? '');

    const text = document.createElement('p');
    text.className = 'history-text';
    text.textContent = item?.text || '';
    card.appendChild(text);

    const meta = document.createElement('div');
    meta.className = 'history-meta';

    const time = document.createElement('span');
    time.className = 'history-time';
    time.textContent = formatTimestamp(item?.timestamp);
    meta.appendChild(time);

    const actions = document.createElement('div');
    actions.className = 'history-actions';

    const copyBtn = document.createElement('button');
    copyBtn.type = 'button';
    copyBtn.className = 'history-btn';
    copyBtn.dataset.action = 'copy';
    copyBtn.textContent = 'Copy';
    actions.appendChild(copyBtn);

    const deleteBtn = document.createElement('button');
    deleteBtn.type = 'button';
    deleteBtn.className = 'history-btn danger';
    deleteBtn.dataset.action = 'delete';
    deleteBtn.textContent = 'Delete';
    actions.appendChild(deleteBtn);

    meta.appendChild(actions);
    card.appendChild(meta);

    return card;
  }

  function updateStats() {
    const totalCount = state.history.length;
    const weekCount = state.history.filter((entry) => isWithinDays(entry?.timestamp, 6)).length;
    const todayCount = state.history.filter((entry) => isWithinDays(entry?.timestamp, 0)).length;
    const visibleCount = state.filtered.length;
    const lastActivity = computeLastActivity(state.history);
    const aiCount = state.history.filter((entry) => isAiEntry(entry)).length;

    setStat(dom.statTotal, totalCount);
    setStat(dom.statWeek, weekCount);
    setStat(dom.statToday, todayCount);
    setStat(dom.statFilter, visibleCount);
    if (dom.statLastActivity) {
      dom.statLastActivity.textContent = lastActivity;
    }
    setStat(dom.statAi, aiCount);
  }

  function setStat(target, value) {
    if (!target) {
      return;
    }
    try {
      target.textContent = new Intl.NumberFormat('en-US').format(value);
    } catch (_error) {
      target.textContent = String(value ?? 0);
    }
  }

  function formatTimestamp(timestamp) {
    if (!timestamp) {
      return 'Saved just now';
    }

    try {
      const date = new Date(timestamp);
      if (Number.isNaN(date.getTime())) {
        return 'Saved just now';
      }

      const diff = Date.now() - date.getTime();
      if (diff < 45 * 1000) {
        return 'Saved just now';
      }
      if (diff < 60 * 60 * 1000) {
        const minutes = Math.round(diff / (60 * 1000));
        return minutes === 1 ? 'Saved 1 minute ago' : `Saved ${minutes} minutes ago`;
      }
      if (diff < 24 * 60 * 60 * 1000) {
        const hours = Math.round(diff / (60 * 60 * 1000));
        return hours === 1 ? 'Saved 1 hour ago' : `Saved ${hours} hours ago`;
      }
      return `Saved ${date.toLocaleString()}`;
    } catch (_error) {
      return 'Saved just now';
    }
  }

  async function handleHistoryAction(event) {
    const trigger = event.target?.closest('button[data-action]');
    if (!trigger) {
      return;
    }

    const card = trigger.closest('.history-item');
    if (!card) {
      return;
    }

    const id = card.dataset.id;
    const item = state.history.find((entry) => String(entry?.id) === String(id));
    if (!item) {
      return;
    }

    if (trigger.dataset.action === 'copy') {
      await copyText(item.text || '');
      showToast('Copied to clipboard');
      return;
    }

    if (trigger.dataset.action === 'delete') {
      await deleteItem(id);
    }
  }

  async function copyText(text) {
    if (!text) {
      return;
    }

    try {
      if (navigator.clipboard?.writeText) {
        await navigator.clipboard.writeText(text);
        return;
      }
    } catch (_error) {
      // fall through
    }

    try {
      const textArea = document.createElement('textarea');
      textArea.value = text;
      textArea.style.position = 'fixed';
      textArea.style.opacity = '0';
      document.body.appendChild(textArea);
      textArea.focus();
      textArea.select();
      document.execCommand('copy');
      textArea.remove();
    } catch (_error) {
      // ignore
    }
  }

  async function deleteItem(id) {
    await sendMessage('deleteHistoryItem', { id });
    state.history = state.history.filter((entry) => String(entry?.id) !== String(id));
    applyFilters();
    showToast('Item deleted');
  }

  async function handleClearAll() {
    const confirmed = await showConfirmModal();
    if (!confirmed) {
      return;
    }

    await sendMessage('clearHistory');
    state.history = [];
    applyFilters();
    showToast('History cleared');
  }

  function showConfirmModal() {
    const modal = dom.confirmModal;
    if (!modal) {
      return Promise.resolve(globalScope.confirm?.('Clear all history?'));
    }

    return new Promise((resolve) => {
      const close = (result) => {
        modal.classList.add('hidden');
        dom.confirmBtn?.removeEventListener('click', onConfirm);
        dom.cancelBtn?.removeEventListener('click', onCancel);
        modal.removeEventListener('click', onBackdrop);
        resolve(result);
      };

      const onConfirm = () => close(true);
      const onCancel = () => close(false);
      const onBackdrop = (event) => {
        if (event.target === modal) {
          close(false);
        }
      };

      dom.confirmBtn?.addEventListener('click', onConfirm);
      dom.cancelBtn?.addEventListener('click', onCancel);
      modal.addEventListener('click', onBackdrop);

      modal.classList.remove('hidden');
    });
  }

  async function applySavedTheme() {
    const stored = await readStoredTheme();
    const theme = stored || detectPreferredTheme();
    setTheme(theme);
  }

  function detectPreferredTheme() {
    try {
      return globalScope.matchMedia && globalScope.matchMedia('(prefers-color-scheme: dark)').matches
        ? 'dark'
        : 'light';
    } catch (_error) {
      return 'light';
    }
  }

  function setTheme(theme) {
    document.documentElement.setAttribute('data-theme', theme);
    document.body.setAttribute('data-theme', theme);
    updateThemeToggle(theme);
    void persistTheme(theme);
  }

  function updateThemeToggle(theme) {
    if (!dom.themeToggle) {
      return;
    }
    const isDark = theme === 'dark';
    dom.themeToggle.textContent = isDark ? '🌞' : '🌙';
    dom.themeToggle.setAttribute('aria-label', isDark ? 'Switch to light theme' : 'Switch to dark theme');
  }

  function toggleTheme() {
    const current = document.documentElement.getAttribute('data-theme') || 'light';
    setTheme(current === 'dark' ? 'light' : 'dark');
  }

  async function readStoredTheme() {
    if (typeof chrome === 'undefined' || !chrome.storage?.local) {
      try {
        return globalScope.localStorage?.getItem(THEME_KEY) || null;
      } catch (_error) {
        return null;
      }
    }

    return new Promise((resolve) => {
      try {
        chrome.storage.local.get({ [THEME_KEY]: null }, (result) => {
          if (chrome.runtime?.lastError) {
            resolve(null);
            return;
          }
          resolve(result?.[THEME_KEY] || null);
        });
      } catch (_error) {
        resolve(null);
      }
    });
  }

  async function persistTheme(theme) {
    if (typeof chrome === 'undefined' || !chrome.storage?.local) {
      try {
        globalScope.localStorage?.setItem(THEME_KEY, theme);
      } catch (_error) {
        // ignore
      }
      return;
    }

    try {
      await new Promise((resolve) => {
        chrome.storage.local.set({ [THEME_KEY]: theme }, () => resolve());
      });
    } catch (_error) {
      // ignore
    }
  }

  function sendMessage(action, payload = {}) {
    if (typeof chrome === 'undefined' || !chrome.runtime?.sendMessage) {
      return Promise.resolve(null);
    }

    return new Promise((resolve) => {
      try {
        chrome.runtime.sendMessage({ action, ...payload }, (response) => {
          if (chrome.runtime?.lastError) {
            resolve(null);
            return;
          }
          resolve(response);
        });
      } catch (_error) {
        resolve(null);
      }
    });
  }

  async function initHumor() {
    if (typeof globalScope.HistoryHumorManager === 'undefined') {
      return;
    }

    humorManager = new globalScope.HistoryHumorManager();
    await humorManager.init();
    updateHumorToggle();
  }

  async function handleSaveCurrent() {
    try {
      const text = await navigator.clipboard.readText();
      if (!text || !text.trim()) {
        showToast('Nothing in clipboard to save');
        return;
      }

      const response = await sendMessage('save_clipboard', { text: text.trim(), source: 'manual' });
      if (response?.status === 'saved' && response.item) {
        state.history = insertOrUpdateHistory(state.history, response.item);
        applyFilters();
        showToast('Saved to history');
      } else {
        showToast('Could not save clipboard');
      }
    } catch (error) {
      showToast('Cannot access clipboard - grant permission first');
    }
  }

  function insertOrUpdateHistory(list, entry) {
    const normalizedEntry = normalizeHistoryEntry(entry);
    if (!normalizedEntry) {
      return Array.isArray(list) ? list.slice(0) : [];
    }

    const next = Array.isArray(list) ? list.slice(0) : [];
    const existingIndex = next.findIndex((item) => item.id === normalizedEntry.id);
    if (existingIndex !== -1) {
      next.splice(existingIndex, 1);
    }
    next.unshift(normalizedEntry);
    return normalizeHistory(next);
  }

  async function handleHumorToggle(event) {
    event?.preventDefault();
    if (!humorManager) return;

    await humorManager.toggleHumor();
    updateHumorToggle();
  }

  function updateHumorToggle() {
    if (!dom.toggleHumor || !humorManager) {
      return;
    }
    const enabled = humorManager.isHumorEnabled;
    dom.toggleHumor.textContent = enabled ? 'Pause humor' : 'Resume humor';
    dom.toggleHumor.setAttribute('aria-pressed', String(enabled));
    dom.toggleHumor.dataset.state = enabled ? 'playing' : 'paused';
  }

  function normalizeHistory(items, options = {}) {
    const { skipSort = false } = options;
    const list = Array.isArray(items) ? items : [];
    const mapped = list
      .map((entry) => normalizeHistoryEntry(entry))
      .filter(Boolean);

    if (skipSort) {
      return mapped;
    }

    return mapped
      .sort((a, b) => safeTimestamp(b.timestamp) - safeTimestamp(a.timestamp))
      .slice(0, 50);
  }

  function normalizeHistoryEntry(entry) {
    if (!entry || typeof entry !== 'object') {
      return null;
    }

    const text = typeof entry.text === 'string' ? entry.text : '';
    if (!text.trim()) {
      return null;
    }

    const id = typeof entry.id === 'string' || typeof entry.id === 'number'
      ? entry.id
      : Date.now();

    const timestamp = entry.timestamp instanceof Date
      ? entry.timestamp.toISOString()
      : (entry.timestamp || new Date().toISOString());
    const source = String(entry.source || entry.origin || '').trim() || 'unknown';

    return {
      id,
      text,
      timestamp,
      source
    };
  }

  function safeTimestamp(value) {
    if (!value) {
      return 0;
    }
    try {
      const time = new Date(value).getTime();
      return Number.isFinite(time) ? time : 0;
    } catch (_error) {
      return 0;
    }
  }

  function computeLastActivity(list) {
    if (!Array.isArray(list) || !list.length) {
      return 'No activity yet';
    }

    const latest = list[0];
    const formatted = formatTimestamp(latest?.timestamp);
    return formatted.replace(/^Saved\s*/i, '') || 'Just now';
  }

  function isAiEntry(item) {
    const source = String(item?.source || item?.origin || '').toLowerCase();
    return source === 'popup-ai' || source === 'ai' || source === 'edge-function';
  }

  function showToast(message) {
    if (typeof globalScope.toast?.show === 'function') {
      globalScope.toast.show(message);
    }
  }
})(typeof window !== 'undefined' ? window : global);
