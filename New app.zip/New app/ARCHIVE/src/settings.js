// Legacy stub to keep the old src/settings.js entry point working.
// Loads the shared settings implementation from ../settings.js.

(function loadSharedSettings() {
  if (typeof document === 'undefined') return;

  if (document.querySelector('script[data-shared-settings="true"]')) {
    return;
  }

  const script = document.createElement('script');
  script.src = '../settings.js';
  script.type = 'text/javascript';
  script.defer = true;
  script.dataset.sharedSettings = 'true';
  script.onerror = (event) => {
    console.error('Failed to load shared settings script from ../settings.js', event);
  };
  document.head.appendChild(script);
})();