// Legacy stub for development builds.
// The production popup logic now lives in ../popup.js and is loaded dynamically below.

(function loadSharedPopup() {
  if (typeof document === 'undefined') return;

  // Avoid injecting the shared script multiple times.
  if (document.querySelector('script[data-shared-popup="true"]')) return;

  const script = document.createElement('script');
  script.src = '../popup.js';
  script.type = 'text/javascript';
  script.defer = true;
  script.dataset.sharedPopup = 'true';
  script.onerror = (event) => {
    if (window.logger?.debug) {
      window.logger.debug('Failed to load shared popup script from ../popup.js', event?.message || event);
    }
  };
  document.head.appendChild(script);
})();