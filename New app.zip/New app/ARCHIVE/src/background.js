// Delegate to the shared background script so dev builds stay in sync.
(function () {
  try {
    if (typeof importScripts === 'function') {
      importScripts('../background.js');
      return;
    }
  } catch (error) {
    if (typeof self !== 'undefined' && self.logger?.debug) {
      self.logger.debug('Failed to import shared background script via importScripts:', error?.message || error);
    }
  }

  // Fallback for environments without importScripts (e.g., test harness mocks)
  if (typeof document !== 'undefined') {
    const script = document.createElement('script');
    script.src = '../background.js';
    script.onerror = (event) => {
      if (typeof self !== 'undefined' && self.logger?.debug) {
        self.logger.debug('Failed to load shared background script fallback:', event?.message || event);
      }
    };
    document.head.appendChild(script);
  }
})();