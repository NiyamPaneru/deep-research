// Legacy stub for development builds.
// Loads the shared quota helper from the project root when referenced via src/quotaHelper.js.

(function loadSharedQuotaHelper() {
  if (typeof document === 'undefined') {
    try {
      if (typeof importScripts === 'function') {
        importScripts('../quotaHelper.js');
      }
    } catch (error) {
      console.error('Failed to import shared quota helper from ../quotaHelper.js', error);
    }
    return;
  }

  if (window.quotaHelper || document.querySelector('script[data-shared-quota="true"]')) {
    return;
  }

  const script = document.createElement('script');
  script.src = '../quotaHelper.js';
  script.type = 'text/javascript';
  script.defer = true;
  script.dataset.sharedQuota = 'true';
  script.onerror = (event) => {
    console.error('Failed to load shared quota helper from ../quotaHelper.js', event);
  };
  document.head.appendChild(script);
})();