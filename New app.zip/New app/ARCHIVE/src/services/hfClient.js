(function initHfClient(globalScope) {
  'use strict';

  const logger = globalScope.logger || { debug: function noop() {} };
  const telemetry = globalScope.telemetry || { send: function noop() {} };
  const MAX_RETRIES = 2;
  const RETRY_BASE_MS = 350;

  function createError(code, status) {
    const error = new Error(code);
    error.code = code;
    error.status = typeof status === 'number' ? status : null;
    return error;
  }

  function wait(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  function buildBody(input, opts) {
    const payload = {
      inputs: input,
      options: Object.assign({ wait_for_model: true }, opts?.options || {})
    };
    if (opts?.parameters) {
      payload.parameters = opts.parameters;
    }
    if (opts?.body && typeof opts.body === 'object') {
      Object.assign(payload, opts.body);
    }
    return JSON.stringify(payload);
  }

  function logAttempt(endpoint, status) {
    try {
      logger.debug('hfClient.generate', endpoint, status);
    } catch (_error) {
      // debug logging should never break execution
    }
  }

  async function generate(modelName, token, input, opts = {}) {
    if (!modelName || typeof modelName !== 'string') {
      throw createError('HF_MODEL_REQUIRED');
    }
    if (!token || typeof token !== 'string') {
      throw createError('HF_TOKEN_REQUIRED');
    }

    const endpoint = `https://api-inference.huggingface.co/models/${encodeURIComponent(modelName)}`;
    const headers = {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json'
    };
    const body = buildBody(input, opts);

    let lastError = null;

    for (let attempt = 0; attempt <= MAX_RETRIES; attempt += 1) {
      try {
        const response = await fetch(endpoint, {
          method: 'POST',
          headers,
          body
        });

        const { status } = response;
        logAttempt(endpoint, status);

        if (status === 401) throw createError('HF_INVALID_TOKEN', status);
        if (status === 404) throw createError('HF_MODEL_NOT_FOUND', status);
        if (status === 204) throw createError('HF_EMPTY_RESPONSE', status);
        if (status >= 500) throw createError('HF_SERVER_ERROR', status);

        const text = await response.text();
        if (!text) {
          throw createError('HF_EMPTY_RESPONSE', status);
        }

        let data;
        try {
          data = JSON.parse(text);
        } catch (_parseError) {
          throw createError('HF_EMPTY_RESPONSE', status);
        }

        if (data == null || (Array.isArray(data) && data.length === 0)) {
          throw createError('HF_EMPTY_RESPONSE', status);
        }

        const payload = {
          ok: true,
          status,
          data
        };
        try {
          telemetry.send('model_call_status', { ok: true, status });
        } catch (_telemetryError) {
          // ignore telemetry failures
        }
        return payload;
      } catch (error) {
        const normalized = normalizeError(error);
        lastError = normalized;
        const shouldRetry = (normalized.code === 'HF_SERVER_ERROR' || normalized.code === 'HF_NETWORK_ERROR') && attempt < MAX_RETRIES;

        if (shouldRetry) {
          await wait(RETRY_BASE_MS * Math.pow(2, attempt));
          continue;
        }

        try {
          telemetry.send('model_call_status', { ok: false, status: normalized.status ?? null, code: normalized.code });
        } catch (_telemetryError) {
          // ignore telemetry failures
        }
        throw normalized;
      }
    }

    if (lastError) {
      try {
        telemetry.send('model_call_status', { ok: false, status: lastError.status ?? null, code: lastError.code });
      } catch (_telemetryError) {
        // ignore telemetry failures
      }
      throw lastError;
    }

    const fallbackError = createError('HF_SERVER_ERROR');
    try {
      telemetry.send('model_call_status', { ok: false, status: fallbackError.status ?? null, code: fallbackError.code });
    } catch (_telemetryError) {
      // ignore telemetry failures
    }
    throw fallbackError;
  }

  function normalizeError(error) {
    if (!error) {
      return createError('HF_UNKNOWN_ERROR');
    }

    if (error.code && error.message === error.code) {
      return error;
    }

    if (error.name === 'TypeError' || error.message === 'Failed to fetch') {
      return createError('HF_NETWORK_ERROR', error.status);
    }

    if (error.message && /^HF_/.test(error.message)) {
      return createError(error.message, error.status);
    }

    if (error.status >= 500) {
      return createError('HF_SERVER_ERROR', error.status);
    }

    return createError('HF_UNKNOWN_ERROR', error.status);
  }

  const api = {
    generate
  };

  globalScope.hfClient = api;

  if (typeof module !== 'undefined' && module.exports) {
    module.exports = api;
  }
})(typeof self !== 'undefined' ? self : typeof globalThis !== 'undefined' ? globalThis : this);
