# 📚 Smart Clipboard AI - Complete Documentation

## 🏗️ Architecture Overview

### Core Components

**Extension Structure**
```
├── Background Service (background-sw.js)
│   ├── License validation
│   ├── Authentication handling
│   └── Storage management
├── Popup Interface (popup.html/js)
│   ├── Clipboard display
│   ├── AI generation
│   └── Quick actions
├── History Page (history.html/js)
│   ├── Full clipboard history
│   ├── Search functionality
│   └── Humor panel (optional)
└── Settings Page (settings.html/js)
    ├── Upgrade plans
    ├── Personalization
    └── AI provider config
```

### Data Flow

1. **User copies text** → Content script detects
2. **Auto-save enabled?** → Store in chrome.storage.local
3. **User opens popup** → Display recent items
4. **User clicks AI enhance** → Call HuggingFace API
5. **Result returned** → Display with humor (if enabled)

### Storage Schema

```javascript
// chrome.storage.local
{
  clipboardHistory: [
    { id, text, timestamp, source }
  ],
  userTier: 'free' | 'pro' | 'lifetime',
  licenseKey: 'ltd_xxx' | 'pro_xxx',
  hfToken: 'hf_xxx',
  humorEnabled: true,
  humorTone: 'playful' | 'neutral' | 'off'
}

// Supabase tables
user_access: { email, tier, activated_at }
license_mappings: { license_key, email, tier, activated_at }
```

## 🔐 License System Implementation

### License Key Format
- **LTD**: `ltd_[random_string]`
- **Pro**: `pro_[random_string]`

### Validation Flow

```javascript
// 1. User enters license key
async function activateLicense(key, email) {
  // Check if key exists in Supabase
  const mapping = await checkLicenseMapping(key);
  
  if (mapping && mapping.email !== email) {
    throw new Error('License already activated with different email');
  }
  
  // Check if user already has access
  const access = await checkUserAccess(email);
  
  if (access && access.tier === 'lifetime') {
    throw new Error('Account already has Lifetime access');
  }
  
  if (access && access.tier === 'pro') {
    throw new Error('Account already has Pro subscription');
  }
  
  // Activate license
  await createLicenseMapping(key, email, tier);
  await createUserAccess(email, tier);
  
  return { success: true, tier };
}
```

### Multi-Device Access

```javascript
// When user signs in on new device
async function restoreAccess(email) {
  const access = await getUserAccess(email);
  
  if (access) {
    // Store locally
    await chrome.storage.local.set({
      userTier: access.tier,
      userEmail: email
    });
    
    return access.tier;
  }
  
  return 'free';
}
```

## 🎨 Humor System

### Joke Categories

1. **history-roast**: Shown in clipboard history
2. **empty-state**: When history is empty
3. **search-no-results**: When search finds nothing
4. **upgrade-rockethub**: RocketHub launch special (2 weeks)
5. **upgrade-monthly**: Monthly plans (after launch)
6. **token-setup**: Token configuration page
7. **settings-general**: Settings page
8. **daily-motivational**: Random daily messages
9. **ai-success**: After successful AI generation
10. **ai-limit**: When AI quota reached

### Joke Selection Logic

```javascript
function getJoke(category, tone = 'playful') {
  // Filter by category and tone
  const filtered = jokes.filter(j => 
    j.category === category && 
    j.tone === tone
  );
  
  // Avoid repeating last joke
  const available = filtered.filter(j => 
    j.id !== lastJokeId
  );
  
  // Random selection
  const joke = available[Math.floor(Math.random() * available.length)];
  lastJokeId = joke.id;
  
  return joke.text;
}
```

### User Controls

- **Settings → Personalization → Humor**: ON/OFF toggle
- **Tone Selection**: Playful | Neutral | Off
- **Footer Link**: "Don't like jokes? Turn Humor Off"

## 🚀 Setup & Deployment

### Development Setup

```bash
# Install dependencies
npm install

# Create environment file
cp .env.example .env

# Add credentials
SUPABASE_URL=https://your-project.supabase.co
SUPABASE_ANON_KEY=your_anon_key
GUMROAD_PRODUCT_ID=your_product_id

# Load in Chrome
# chrome://extensions/ → Developer mode → Load unpacked
```

### Supabase Setup

```sql
-- User access tracking
CREATE TABLE user_access (
  email TEXT PRIMARY KEY,
  tier TEXT NOT NULL CHECK (tier IN ('free', 'pro', 'lifetime')),
  activated_at TIMESTAMP DEFAULT NOW()
);

-- License key mapping
CREATE TABLE license_mappings (
  license_key TEXT PRIMARY KEY,
  email TEXT NOT NULL,
  tier TEXT NOT NULL CHECK (tier IN ('pro', 'lifetime')),
  activated_at TIMESTAMP DEFAULT NOW(),
  UNIQUE(license_key)
);

-- Indexes for performance
CREATE INDEX idx_user_email ON user_access(email);
CREATE INDEX idx_license_key ON license_mappings(license_key);
```

### Chrome Web Store Submission

**Pre-Submission Checklist**
- [ ] Remove all console.log statements
- [ ] Test license validation (all scenarios)
- [ ] Verify humor toggle works
- [ ] Test multi-device access
- [ ] Check dark/light themes
- [ ] Validate all permissions needed
- [ ] Test Google OAuth flow
- [ ] Verify Supabase integration
- [ ] Test auto-save clipboard
- [ ] Check AI generation limits

**Store Listing**
- **Title**: Smart Clipboard AI
- **Category**: Productivity
- **Price**: Free (with in-app purchases)
- **Screenshots**: 5 images (1280x800)
- **Privacy Policy**: Required for OAuth

### Build & Package

```bash
# Production build
npm run build

# Package for store
npm run package
# Output: smart-clipboard-ai.zip
```

## 🔧 API Integration

### HuggingFace API

```javascript
async function generateAI(prompt, token) {
  const response = await fetch(
    'https://api-inference.huggingface.co/models/mistralai/Mistral-7B-Instruct-v0.2',
    {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        inputs: prompt,
        parameters: {
          max_new_tokens: 250,
          temperature: 0.7
        }
      })
    }
  );
  
  return await response.json();
}
```

### Quota Management

```javascript
// Free tier: 3 generations per day
async function checkQuota(email, tier) {
  if (tier === 'pro' || tier === 'lifetime') {
    return { allowed: true, remaining: Infinity };
  }
  
  const today = new Date().toDateString();
  const usage = await getUsageToday(email, today);
  
  return {
    allowed: usage < 3,
    remaining: 3 - usage,
    resetAt: getTomorrowMidnight()
  };
}
```

## 🎯 Feature Implementation

### Auto-Save Clipboard

```javascript
// content-scripts/clipboard-listener.js
document.addEventListener('copy', async (e) => {
  const settings = await chrome.storage.local.get('autoSaveEnabled');
  
  if (!settings.autoSaveEnabled) return;
  
  const text = window.getSelection().toString();
  
  if (text) {
    await chrome.runtime.sendMessage({
      type: 'SAVE_CLIPBOARD',
      text,
      source: window.location.hostname
    });
  }
});
```

### Smart Search

```javascript
function searchHistory(query) {
  const history = await getClipboardHistory();
  
  return history.filter(item => 
    item.text.toLowerCase().includes(query.toLowerCase())
  ).sort((a, b) => b.timestamp - a.timestamp);
}
```

### Theme Support

```css
/* Automatic theme detection */
@media (prefers-color-scheme: dark) {
  :root {
    --bg-primary: #1a1a1a;
    --text-primary: #ffffff;
    --accent: #3b82f6;
  }
}

@media (prefers-color-scheme: light) {
  :root {
    --bg-primary: #ffffff;
    --text-primary: #000000;
    --accent: #2563eb;
  }
}
```

## 📊 Monitoring & Analytics

### Key Metrics

**User Engagement**
- Daily active users
- Clipboard items saved per user
- AI generations per user
- Humor toggle usage (target: 70%+ ON)

**Conversion**
- Free → Pro conversion rate
- LTD sales during launch
- BYOK adoption rate
- Churn rate for Pro

**Technical**
- Extension load time
- API response time
- Error rates
- Storage usage per user

### Error Handling

```javascript
try {
  await generateAI(prompt, token);
} catch (error) {
  if (error.status === 429) {
    showError('Rate limit reached. Try again in a minute.');
  } else if (error.status === 401) {
    showError('Invalid token. Check your HuggingFace token.');
  } else {
    showError('AI generation failed. Please try again.');
  }
  
  // Log for monitoring
  logError('AI_GENERATION_FAILED', error);
}
```

## 🔄 Maintenance

### Weekly Tasks
- Monitor error logs
- Check user feedback
- Review conversion metrics
- Update joke pool (5-10 new jokes)

### Monthly Tasks
- Update dependencies
- Security audit
- Performance optimization
- Add features based on feedback
- Refresh humor content (20-30 new jokes)

### Quarterly Tasks
- Major feature releases
- UI/UX improvements
- Pricing strategy review
- Marketing campaigns

## 🆘 Troubleshooting

### Common Issues

**License key not working**
- Verify key format (ltd_xxx or pro_xxx)
- Check Supabase connection
- Ensure user is signed in with Google
- Check if key already used

**AI not generating**
- Check quota (free = 3/day)
- Verify HuggingFace token valid
- Check API rate limits
- Ensure internet connection

**Auto-save not working**
- Verify enabled in settings
- Check content script loaded
- Reload extension
- Check browser permissions

**Humor not showing**
- Check humor toggle in settings
- Verify jokes.json loaded
- Check tone setting
- Reload extension

## 📄 License & Credits

**License**: MIT License

**Built with**:
- Chrome Extension APIs
- HuggingFace Inference API
- Supabase (Auth & Database)
- Gumroad (Payments)

---

**Last Updated**: 2025
**Version**: 1.0.0
**Status**: Production Ready 🚀
