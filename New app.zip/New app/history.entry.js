import './storageHelper.js';
import './services/humorManager.js';
import './src/humor/humorManager.js';
import './src/humor/humorPanel.js';
import './history.js';
