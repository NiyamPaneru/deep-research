const { beforeEach, describe, expect, test } = require('@jest/globals');
const path = require('path');

const mockStore = {};
const localStore = {};

global.window = {};

global.localStorage = {
  getItem: (key) => (Object.prototype.hasOwnProperty.call(localStore, key) ? localStore[key] : null),
  setItem: (key, value) => {
    localStore[key] = value;
  },
  removeItem: (key) => {
    delete localStore[key];
  },
  clear: () => {
    Object.keys(localStore).forEach((storageKey) => delete localStore[storageKey]);
  }
};

global.chrome = {
  storage: {
    local: {
      get: (keys, cb) => {
        const compute = () => {
          if (Array.isArray(keys) || typeof keys === 'object') {
            const result = {};
            const entries = Array.isArray(keys) ? keys : Object.keys(keys);
            entries.forEach((key) => { result[key] = mockStore[key]; });
            return result;
          }
          return { [keys]: mockStore[keys] };
        };

        const result = compute();
        if (typeof cb === 'function') {
          cb(result);
          return undefined;
        }
        return Promise.resolve(result);
      },
      set: (items, cb) => {
        Object.assign(mockStore, items);
        if (typeof cb === 'function') {
          cb();
          return undefined;
        }
        return Promise.resolve();
      }
    }
  },
  runtime: { lastError: null }
};

global.window.localStorage = global.localStorage;
global.window.chrome = global.chrome;

beforeEach(() => {
  Object.keys(mockStore).forEach((key) => delete mockStore[key]);
  Object.keys(localStore).forEach((key) => delete localStore[key]);
  global.localStorage.clear();
  jest.resetModules();

  const storageHelperPath = path.join(__dirname, '..', 'storageHelper.cjs');
  const quotaHelperPath = path.join(__dirname, '..', 'quotaHelper.cjs');

  delete require.cache[storageHelperPath];
  delete require.cache[quotaHelperPath];

  const storageHelper = require(storageHelperPath);
  const quotaHelper = require(quotaHelperPath);

  global.storageHelper = storageHelper;
  global.quotaHelper = quotaHelper;
});

describe('quotaHelper.checkAndIncrementQuota', () => {
  test('increments usage when within limit', async () => {
    const helper = global.quotaHelper;
    const deviceId = await global.storageHelper.getOrCreateDeviceId();
    const result = await helper.checkAndIncrementQuota('free', deviceId, 1);
    expect(result.ok).toBe(true);
    expect(result.remaining).toBe(2);
  });

  test('blocks when quota exceeded', async () => {
    const helper = global.quotaHelper;
    const deviceId = await global.storageHelper.getOrCreateDeviceId();
    await helper.checkAndIncrementQuota('free', deviceId, 3);
    const result = await helper.checkAndIncrementQuota('free', deviceId, 1);
    expect(result.ok).toBe(false);
    expect(result.remaining).toBe(0);
  });

  test('decrementQuota rolls usage back', async () => {
    const helper = global.quotaHelper;
    const deviceId = await global.storageHelper.getOrCreateDeviceId();
    await helper.checkAndIncrementQuota('free', deviceId, 2);
    const rollback = await helper.decrementQuota('free', deviceId, 1);
    expect(rollback.remaining).toBe(2);
  });
});
