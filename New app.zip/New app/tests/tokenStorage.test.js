const path = require('path');
const { webcrypto } = require('crypto');

describe('tokenStorage', () => {
  const tokenStoragePath = path.join(__dirname, '..', 'src', 'services', 'tokenStorage.js');
  let hfClientMock;
  let tokenStorage;
  let storedPayload;
  const originalChrome = global.chrome;
  const originalCrypto = global.crypto;
  const originalAtob = global.atob;
  const originalBtoa = global.btoa;

  beforeEach(() => {
    jest.resetModules();
    storedPayload = {};

    global.crypto = webcrypto;
    global.atob = (value) => Buffer.from(value, 'base64').toString('binary');
    global.btoa = (value) => Buffer.from(value, 'binary').toString('base64');

    hfClientMock = {
      generate: jest.fn().mockResolvedValue({ ok: true, status: 200, data: ['ok'] })
    };
    global.hfClient = hfClientMock;
    global.logger = { debug: jest.fn() };
    global.telemetry = { send: jest.fn() };
    global.storageHelper = undefined;

    global.chrome = {
      storage: {
        local: {
          get: (keys, callback) => {
            const keyArray = Array.isArray(keys) ? keys : [keys];
            const result = keyArray.reduce((acc, key) => {
              acc[key] = storedPayload[key];
              return acc;
            }, {});
            if (typeof callback === 'function') {
              callback(result);
            }
            return undefined;
          },
          set: (items, callback) => {
            storedPayload = { ...storedPayload, ...items };
            if (typeof callback === 'function') {
              callback();
            }
            return undefined;
          },
          remove: (keys, callback) => {
            const keyArray = Array.isArray(keys) ? keys : [keys];
            keyArray.forEach((key) => delete storedPayload[key]);
            if (typeof callback === 'function') {
              callback();
            }
            return undefined;
          }
        }
      },
      runtime: {}
    };

    tokenStorage = require(tokenStoragePath);
  });

  afterEach(() => {
    delete global.hfClient;
    delete global.logger;
    delete global.telemetry;
    delete global.storageHelper;
    if (originalChrome) {
      global.chrome = originalChrome;
    } else {
      delete global.chrome;
    }
    if (originalCrypto) {
      global.crypto = originalCrypto;
    } else {
      delete global.crypto;
    }
    if (typeof originalAtob === 'function') {
      global.atob = originalAtob;
    } else {
      delete global.atob;
    }
    if (typeof originalBtoa === 'function') {
      global.btoa = originalBtoa;
    } else {
      delete global.btoa;
    }
    jest.clearAllMocks();
  });

  it('validates and stores tokens securely', async () => {
    const result = await tokenStorage.setToken('hf_test_token');
    expect(result).toMatchObject({ ok: true });
    expect(hfClientMock.generate).toHaveBeenCalledWith('gpt2', 'hf_test_token', 'Hello');

    const stored = storedPayload.hf_token_encrypted_v1;
    expect(stored).toBeDefined();
    expect(stored).toHaveProperty('data');
    expect(stored).toHaveProperty('iv');
    expect(typeof storedPayload.hf_token_secret_v1).toBe('string');

    const recovered = await tokenStorage.getToken();
    expect(recovered).toBe('hf_test_token');
  });

  it('returns validation failure codes from Hugging Face errors', async () => {
    const error = new Error('HF_INVALID_TOKEN');
    error.code = 'HF_INVALID_TOKEN';
    hfClientMock.generate.mockRejectedValue(error);

    const result = await tokenStorage.setToken('hf_bad_token');
    expect(result).toMatchObject({ ok: false, code: 'HF_INVALID_TOKEN' });
    expect(storedPayload.hf_token_encrypted_v1).toBeUndefined();
  });

  it('clears stored token when provided with empty input', async () => {
    await tokenStorage.setToken('hf_test_token');
    expect(storedPayload.hf_token_encrypted_v1).toBeDefined();

    await tokenStorage.setToken('');
    expect(storedPayload.hf_token_encrypted_v1).toBeUndefined();
    const token = await tokenStorage.getToken();
    expect(token).toBeNull();
  });

  it('removes stored value on clearToken', async () => {
    await tokenStorage.setToken('hf_test_token');
    expect(storedPayload.hf_token_encrypted_v1).toBeDefined();

    await tokenStorage.clearToken();
    expect(storedPayload.hf_token_encrypted_v1).toBeUndefined();
  });
});
