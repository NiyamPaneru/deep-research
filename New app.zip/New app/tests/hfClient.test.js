const path = require('path');

describe('hfClient.generate', () => {
  const originalFetch = global.fetch;
  const hfClientPath = path.join(__dirname, '..', 'src', 'services', 'hfClient.js');
  let hfClient;

  beforeEach(() => {
    global.fetch = jest.fn();
    global.logger = { debug: jest.fn() };
    global.telemetry = { send: jest.fn() };
    jest.resetModules();
    hfClient = require(hfClientPath);
  });

  afterEach(() => {
    if (originalFetch) {
      global.fetch = originalFetch;
    } else {
      delete global.fetch;
    }
    delete global.logger;
    delete global.telemetry;
    jest.clearAllMocks();
  });

  it('returns ok result when Hugging Face responds with data', async () => {
    global.fetch.mockResolvedValue({
      status: 200,
      text: async () => JSON.stringify([{ generated_text: 'Hello world' }])
    });

    const result = await hfClient.generate('gpt2', 'token', 'Hello');

    expect(result.ok).toBe(true);
    expect(result.status).toBe(200);
    expect(result.data[0].generated_text).toBe('Hello world');
    expect(global.telemetry.send).toHaveBeenCalledWith('model_call_status', { ok: true, status: 200 });
  });

  it('throws HF_INVALID_TOKEN on 401', async () => {
    global.fetch.mockResolvedValue({ status: 401, text: async () => '' });

    await expect(hfClient.generate('gpt2', 'token', 'Hello')).rejects.toMatchObject({ code: 'HF_INVALID_TOKEN' });
    expect(global.telemetry.send).toHaveBeenCalledWith('model_call_status', { ok: false, status: 401, code: 'HF_INVALID_TOKEN' });
  });

  it('throws HF_MODEL_NOT_FOUND on 404', async () => {
    global.fetch.mockResolvedValue({ status: 404, text: async () => '' });

    await expect(hfClient.generate('missing-model', 'token', 'Hello')).rejects.toMatchObject({ code: 'HF_MODEL_NOT_FOUND' });
    expect(global.telemetry.send).toHaveBeenCalledWith('model_call_status', { ok: false, status: 404, code: 'HF_MODEL_NOT_FOUND' });
  });

  it('throws HF_EMPTY_RESPONSE when body is empty', async () => {
    global.fetch.mockResolvedValue({ status: 200, text: async () => '' });

    await expect(hfClient.generate('gpt2', 'token', 'Hello')).rejects.toMatchObject({ code: 'HF_EMPTY_RESPONSE' });
  });

  it('retries on 5xx and surfaces HF_SERVER_ERROR after retries', async () => {
    global.fetch
      .mockResolvedValueOnce({ status: 503, text: async () => '' })
      .mockResolvedValueOnce({ status: 502, text: async () => '' })
      .mockResolvedValueOnce({ status: 500, text: async () => '' });

    await expect(hfClient.generate('gpt2', 'token', 'Hello')).rejects.toMatchObject({ code: 'HF_SERVER_ERROR' });
    expect(global.fetch).toHaveBeenCalledTimes(3);
  expect(global.telemetry.send).toHaveBeenLastCalledWith('model_call_status', { ok: false, status: 500, code: 'HF_SERVER_ERROR' });
  });

  it('maps network failures to HF_NETWORK_ERROR', async () => {
    global.fetch.mockRejectedValue(new TypeError('Failed to fetch'));

    await expect(hfClient.generate('gpt2', 'token', 'Hello')).rejects.toMatchObject({ code: 'HF_NETWORK_ERROR' });
    expect(global.telemetry.send).toHaveBeenCalledWith('model_call_status', { ok: false, status: null, code: 'HF_NETWORK_ERROR' });
  });
});
