/**
 * Error handling utilities for Smart Clipboard AI
 */

// Global error handler for the extension
class ErrorHandler {
  constructor() {
    this.errors = [];
    this.maxErrors = 50;
    this.setupGlobalHandlers();
  }

  setupGlobalHandlers() {
    // Handle uncaught errors
    window.addEventListener('error', (event) => {
      this.logError({
        type: 'javascript_error',
        message: event.message,
        filename: event.filename,
        lineno: event.lineno,
        colno: event.colno,
        stack: event.error?.stack,
        timestamp: new Date().toISOString()
      });
    });

    // Handle unhandled promise rejections
    window.addEventListener('unhandledrejection', (event) => {
      this.logError({
        type: 'promise_rejection',
        message: event.reason?.message || String(event.reason),
        stack: event.reason?.stack,
        timestamp: new Date().toISOString()
      });
    });
  }

  logError(error) {
    console.error('Smart Clipboard Error:', error);
    
    // Store error for debugging
    this.errors.unshift(error);
    if (this.errors.length > this.maxErrors) {
      this.errors.pop();
    }

    // Try to save to storage for persistence
    try {
      if (typeof chrome !== 'undefined' && chrome.storage) {
        chrome.storage.local.set({
          'smartClipboard_errors': this.errors.slice(0, 10) // Keep only recent errors
        }).catch(() => {
          // Ignore storage errors
        });
      }
    } catch (e) {
      // Ignore storage errors
    }
  }

  getRecentErrors() {
    return this.errors.slice(0, 10);
  }

  clearErrors() {
    this.errors = [];
    try {
      if (typeof chrome !== 'undefined' && chrome.storage) {
        chrome.storage.local.remove('smartClipboard_errors');
      }
    } catch (e) {
      // Ignore storage errors
    }
  }

  // Helper to create user-friendly error messages
  static getUserFriendlyMessage(error) {
    if (!error) return 'An unknown error occurred';

    const message = error.message || String(error);

    // Auth-related errors
    if (message.includes('auth') || message.includes('login') || message.includes('sign')) {
      return 'Authentication failed. Please try signing in again.';
    }

    // Network errors
    if (message.includes('fetch') || message.includes('network') || message.includes('connection')) {
      return 'Network error. Please check your internet connection and try again.';
    }

    // API errors
    if (message.includes('API') || message.includes('401') || message.includes('403')) {
      return 'API error. Please check your configuration and try again.';
    }

    // Configuration errors
    if (message.includes('config') || message.includes('URL') || message.includes('key')) {
      return 'Configuration error. Please check your settings.';
    }

    // Storage errors
    if (message.includes('storage') || message.includes('quota')) {
      return 'Storage error. Please try clearing some data.';
    }

    // Generic fallback
    return 'Something went wrong. Please try again.';
  }
}

// Create global error handler instance
window.smartClipboardErrorHandler = new ErrorHandler();

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
  module.exports = ErrorHandler;
}