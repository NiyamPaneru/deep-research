// Entry point for HF setup
import './services/tokenStore.js';
import './services/hfClient.js';
import './setup-hf.js';
