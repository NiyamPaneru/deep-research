# Supabase Status Check & Setup Guide

## 🔍 Current Status: ⚠️ NOT CONFIGURED

### What I Found:

#### ✅ Good News:
1. **Local Supabase CLI is configured** - `config.toml` exists
2. **Edge Functions exist**:
   - `verify_ltd/index.ts` - License verification function
   - `generate/index.ts` - AI generation function
3. **Local development ready** - Port 54321 configured

#### ❌ Issues Found:

1. **No Supabase Project Connected**
   - `config.js` has empty `SUPABASE_URL: ''`
   - `config.js` has empty `SUPABASE_FUNCTIONS_URL: ''`
   - No project credentials configured

2. **No Database Tables**
   - `licenses` table doesn't exist yet
   - `subscriptions` table doesn't exist yet

3. **Edge Functions Not Deployed**
   - Functions exist locally but not deployed to cloud

4. **No Environment Variables Set**
   - Missing `SUPABASE_SERVICE_ROLE_KEY`
   - Missing `HUGGING_FACE_API_KEY`

## 🚀 Quick Setup Guide (15 minutes)

### Step 1: Create Supabase Project (3 min)

```bash
# Option A: Use Supabase Cloud (Recommended)
1. Go to https://supabase.com
2. Click "Start your project"
3. Create new organization (if needed)
4. Create new project:
   - Name: smart-clipboard-ai
   - Database Password: [generate strong password]
   - Region: [choose closest to your users]
5. Wait for project to be ready (~2 minutes)
```

### Step 2: Get Your Credentials (1 min)

In your Supabase dashboard:
1. Go to **Settings** → **API**
2. Copy these values:
   - **Project URL** (e.g., `https://abcdefgh.supabase.co`)
   - **anon/public key** (starts with `eyJ...`)
   - **service_role key** (starts with `eyJ...`) - Keep this SECRET!

### Step 3: Update config.js (2 min)

```javascript
const CONFIG = {
  DEBUG_MODE: false,
  SUPABASE_URL: 'https://YOUR_PROJECT.supabase.co', // ← Paste Project URL
  SUPABASE_FUNCTIONS_URL: 'https://YOUR_PROJECT.supabase.co/functions/v1', // ← Add /functions/v1
  HF_SHARED_TOKEN: '', // Optional: Add your Hugging Face token
  AUTH_REDIRECT_URL: 'https://YOUR_EXTENSION_ID.chromiumapp.org/auth-callback.html',
  ALLOWED_ORIGINS: ['http://localhost:54321'],
  ROCKETHUB_PROMO_END: '2024-12-31T23:59:59Z', // ← Set your promo end date
  // ... rest stays the same
};
```

### Step 4: Create Database Tables (3 min)

1. In Supabase dashboard, go to **SQL Editor**
2. Click **New query**
3. Paste this SQL:

```sql
-- Create licenses table for LTD users
CREATE TABLE IF NOT EXISTS licenses (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  license_key TEXT UNIQUE NOT NULL,
  email TEXT NOT NULL,
  status TEXT DEFAULT 'active' CHECK (status IN ('active', 'revoked', 'expired')),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  activated_at TIMESTAMP WITH TIME ZONE,
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE
);

-- Create subscriptions table for Pro users
CREATE TABLE IF NOT EXISTS subscriptions (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  gumroad_license_key TEXT UNIQUE,
  status TEXT DEFAULT 'active' CHECK (status IN ('active', 'cancelled', 'expired')),
  next_billing_date TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable Row Level Security
ALTER TABLE licenses ENABLE ROW LEVEL SECURITY;
ALTER TABLE subscriptions ENABLE ROW LEVEL SECURITY;

-- RLS Policies for licenses
CREATE POLICY "Users can view own licenses" ON licenses
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Service role can manage licenses" ON licenses
  FOR ALL USING (auth.jwt()->>'role' = 'service_role');

-- RLS Policies for subscriptions
CREATE POLICY "Users can view own subscriptions" ON subscriptions
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Service role can manage subscriptions" ON subscriptions
  FOR ALL USING (auth.jwt()->>'role' = 'service_role');

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_licenses_email ON licenses(email);
CREATE INDEX IF NOT EXISTS idx_licenses_key ON licenses(license_key);
CREATE INDEX IF NOT EXISTS idx_subscriptions_user ON subscriptions(user_id);

-- Insert test license for development
INSERT INTO licenses (license_key, email, status)
VALUES ('TEST-LTD-12345', 'test@example.com', 'active')
ON CONFLICT (license_key) DO NOTHING;
```

4. Click **Run** (or press Ctrl+Enter)
5. You should see "Success. No rows returned"

### Step 5: Deploy Edge Functions (4 min)

```bash
# Install Supabase CLI (if not installed)
npm install -g supabase

# Login to Supabase
supabase login

# Link your project (you'll need your project ref from dashboard)
supabase link --project-ref YOUR_PROJECT_REF

# Deploy verify_ltd function
supabase functions deploy verify_ltd

# Deploy generate function  
supabase functions deploy generate

# Set environment variables (secrets)
supabase secrets set SUPABASE_SERVICE_ROLE_KEY=your_service_role_key_here
supabase secrets set HUGGING_FACE_API_KEY=your_hf_token_here
```

### Step 6: Test Everything (2 min)

#### Test 1: Database Tables
```bash
# In Supabase SQL Editor, run:
SELECT * FROM licenses;
# Should show your test license
```

#### Test 2: verify_ltd Function
```bash
curl -X POST 'https://YOUR_PROJECT.supabase.co/functions/v1/verify_ltd' \
  -H 'Content-Type: application/json' \
  -d '{
    "licenseKey": "TEST-LTD-12345",
    "email": "test@example.com"
  }'

# Expected response:
# {"valid":true,"plan":"LTD","email":"test@example.com"}
```

#### Test 3: generate Function
```bash
curl -X POST 'https://YOUR_PROJECT.supabase.co/functions/v1/generate' \
  -H 'Content-Type: application/json' \
  -d '{
    "prompt": "Write a headline about AI",
    "useCase": "headline"
  }'

# Expected: JSON with "outputs" array
```

## 🔧 Troubleshooting

### "Project ref not found"
```bash
# Get your project ref from dashboard URL:
# https://supabase.com/dashboard/project/YOUR_PROJECT_REF
# Or from Settings → General → Reference ID
```

### "Function deployment failed"
```bash
# Make sure you're in the project root directory
cd "c:\Users\thely\Downloads\New app"

# Try deploying with verbose output
supabase functions deploy verify_ltd --debug
```

### "Database connection failed"
```bash
# Check if your project is paused (free tier auto-pauses after 7 days)
# Go to dashboard and click "Resume project"
```

### "Edge function returns 500 error"
```bash
# Check function logs in dashboard:
# Edge Functions → verify_ltd → Logs

# Common issues:
# - Missing environment variables
# - Wrong table names
# - RLS policies blocking access
```

## 📊 Verification Checklist

Run through this checklist to confirm everything works:

- [ ] Supabase project created and active
- [ ] `config.js` updated with project URL
- [ ] Database tables created (`licenses`, `subscriptions`)
- [ ] Test license inserted successfully
- [ ] Edge functions deployed (`verify_ltd`, `generate`)
- [ ] Environment variables set (service role key, HF token)
- [ ] Test curl request to `verify_ltd` returns success
- [ ] Test curl request to `generate` returns outputs
- [ ] Extension can connect to Supabase (test in Chrome)

## 🎯 Next Steps After Setup

1. **Update Extension Code**
   - Uncomment LTD/Pro activation code in `settings.js`
   - Test license activation in extension

2. **Add Real Licenses**
   ```sql
   -- Add your RocketHub licenses
   INSERT INTO licenses (license_key, email, status)
   VALUES ('RH-XXXXX-XXXXX', 'customer@email.com', 'active');
   ```

3. **Monitor Usage**
   - Check Edge Function logs regularly
   - Monitor database size (free tier: 500MB)
   - Watch for rate limit issues

4. **Security Hardening**
   - Add rate limiting to Edge Functions
   - Set up monitoring alerts
   - Review RLS policies

## 💡 Pro Tips

1. **Use Local Development First**
   ```bash
   # Start local Supabase
   supabase start
   
   # Your local URLs:
   # API: http://localhost:54321
   # Studio: http://localhost:54323
   ```

2. **Test with Local Functions**
   ```bash
   # Serve functions locally
   supabase functions serve
   
   # Test locally
   curl http://localhost:54321/functions/v1/verify_ltd \
     -H 'Content-Type: application/json' \
     -d '{"licenseKey":"TEST-LTD-12345","email":"test@example.com"}'
   ```

3. **Keep Secrets Safe**
   - Never commit service role key
   - Use environment variables
   - Rotate keys regularly

## 📞 Need Help?

If you get stuck:
1. Check Supabase docs: https://supabase.com/docs
2. Check function logs in dashboard
3. Test with curl first before testing in extension
4. Verify environment variables are set correctly

## 🎉 Success Indicators

You'll know everything is working when:
- ✅ Test license validates successfully
- ✅ Edge functions return 200 status
- ✅ Extension can activate LTD licenses
- ✅ No errors in Supabase logs
- ✅ Database queries execute without errors