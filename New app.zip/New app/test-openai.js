// Simple Hugging Face inference test (replaces undefined OpenAIClient)
async function testHF() {
  const token =
    (typeof chrome !== 'undefined' && chrome.storage?.sync
      ? (await chrome.storage.sync.get(['huggingFaceToken'])).huggingFaceToken
      : (typeof process !== 'undefined' && process.env.HF_TOKEN) || null);

  if (!token) {
    console.error('HF token missing (store in chrome.storage.sync as huggingFaceToken or set HF_TOKEN env).');
    return;
  }

  try {
    const resp = await fetch('https://api-inference.huggingface.co/models/gpt2', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ inputs: 'What is the capital of France?', parameters: { max_new_tokens: 15 } })
    });
    if (!resp.ok) throw new Error('HTTP ' + resp.status);
    const data = await resp.json();
    console.log('HF Test OK:', data);
  } catch (e) {
    console.error('HF test failed:', e.message);
  }
}

// Uncomment to run manually:
// testHF();