const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

// Configuration
const sourceDir = __dirname;
const outputDir = path.join(__dirname, 'dist');
const requiredFiles = [
  'manifest.json',
  'popup.html',
  'popup.js',
  'background-sw.js',
  'styles.css',
  'icons/icon16.png',
  'icons/icon48.png',
  'icons/icon128.png'
];

const extraRuntimeFiles = [
  'debug.js',
  'auth.js',
  'services/auth.js',
  'fakeGenerate.js',
  'auth-callback.html',
  'config.js',
  'setup-hf.html',
  'setup-hf.js'
];

const directoriesToCopy = [
  'src',
  'services'
];

function removeDesktopIni(dirPath) {
  if (!fs.existsSync(dirPath)) return;
  const entries = fs.readdirSync(dirPath, { withFileTypes: true });
  for (const entry of entries) {
    const fullPath = path.join(dirPath, entry.name);
    if (entry.isDirectory()) {
      removeDesktopIni(fullPath);
    } else if (entry.name.toLowerCase() === 'desktop.ini') {
      try {
        fs.unlinkSync(fullPath);
        console.log(`Removed desktop.ini at ${fullPath}`);
      } catch (error) {
        console.warn(`Unable to remove desktop.ini at ${fullPath}:`, error?.message || error);
      }
    }
  }
}

// Remove illegal desktop.ini files before packaging (Chrome extension requirement)
removeDesktopIni(__dirname);

// Create output directory
if (!fs.existsSync(outputDir)) {
  fs.mkdirSync(outputDir);
  console.log(`Created output directory: ${outputDir}`);
}

// Check for required files
const missingFiles = [];
for (const file of requiredFiles) {
  const filePath = path.join(sourceDir, file);
  if (!fs.existsSync(filePath)) {
    missingFiles.push(file);
  }
}

if (missingFiles.length > 0) {
  console.error('ERROR: The following required files are missing:');
  missingFiles.forEach(file => console.error(`- ${file}`));
  console.error('\nPlease create these files before packaging the extension.');
  process.exit(1);
}

// Copy all necessary files to dist
try {
  removeDesktopIni(sourceDir);

  // Copy main files
  const filesToCopy = [
    'manifest.json',
    'popup.html',
    'popup.js',
    'popup.entry.js',
    'background-sw.js',
    'styles.css',
    'storageHelper.js',
    'quotaHelper.js',
    'clipboardManager.js',
    'generateFlow.js',
    'settings.html',
    'settings.js',
    'settings.entry.js',
    'setup-hf.entry.js',
    'history.html',
    'history.js',
    'history.entry.js'
  ];
  
  for (const file of filesToCopy) {
    fs.copyFileSync(
      path.join(sourceDir, file), 
      path.join(outputDir, file)
    );
  }
  
  // Ensure icons directory exists
  const iconsDir = path.join(outputDir, 'icons');
  if (!fs.existsSync(iconsDir)) {
    fs.mkdirSync(iconsDir);
  }
  
  // Copy icons
  const iconsToCopy = ['icon16.png', 'icon48.png', 'icon128.png'];
  for (const icon of iconsToCopy) {
    fs.copyFileSync(
      path.join(sourceDir, 'icons', icon), 
      path.join(outputDir, 'icons', icon)
    );
  }
  
  // Copy extra runtime files
  for (const f of extraRuntimeFiles) {
    const p = path.join(sourceDir, f);
    if (fs.existsSync(p)) {
      const destDir = path.dirname(path.join(outputDir, f));
      if (!fs.existsSync(destDir)) fs.mkdirSync(destDir, { recursive: true });
      fs.copyFileSync(p, path.join(outputDir, f));
    }
  }

  // Copy supporting directories recursively
  for (const dir of directoriesToCopy) {
    const srcPath = path.join(sourceDir, dir);
    if (!fs.existsSync(srcPath)) continue;
    const destPath = path.join(outputDir, dir);
    fs.cpSync(srcPath, destPath, { recursive: true });
  }
  
  // Secret leakage warning
  try {
    const cfg = fs.readFileSync(path.join(sourceDir, 'config.js'), 'utf8');
    if (/hf_|sk_live|SUPABASE_ANON_KEY_PLACEHOLDER/.test(cfg) && !cfg.includes('PLACEHOLDER')) {
      console.warn('WARNING: Potential secret in config.js. Remove real keys before distribution.');
    }
  } catch {}
  
  removeDesktopIni(outputDir);

  console.log('All files copied successfully to dist folder.');
  console.log('Extension is ready to be loaded in Chrome!');
  console.log('\nTo load the extension:');
  console.log('1. Open Chrome and go to chrome://extensions');
  console.log('2. Enable "Developer mode"');
  console.log('3. Click "Load unpacked" and select the dist folder');
  
} catch (error) {
  console.error('Error during packaging:', error);
}
