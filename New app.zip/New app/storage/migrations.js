// GPT-5 Refactor: Handles legacy storage migrations to chrome.storage.local.
import storageHelper from '../storageHelper.js';
import { debugLog } from '../utils/debug.js';

const MIGRATION_FLAG = 'migration_v1_completed';

async function runMigrations() {
  try {
    const hasChrome = typeof chrome !== 'undefined';
    if (!hasChrome || !chrome.storage?.local) {
      return;
    }

    const result = await chrome.storage.local.get([MIGRATION_FLAG]);
    if (result[MIGRATION_FLAG]) {
      return;
    }

    await migrateLocalStorage();
    await chrome.storage.local.set({ [MIGRATION_FLAG]: true });
    debugLog('migrations.completed', true);
  } catch (error) {
    debugLog('migrations.failed', error?.message || error);
  }
}

async function migrateLocalStorage() {
  try {
    const legacyKeys = [
      'smartClipboard_user',
      'smartClipboard_users',
      'userTier',
      'smartClipboard_deviceId_v1',
      'huggingFaceToken'
    ];

    const migrated = {};
    legacyKeys.forEach((key) => {
      const value = localStorage.getItem(key);
      if (value !== null && value !== undefined) {
        migrated[key] = value;
        localStorage.removeItem(key);
      }
    });

    if (Object.keys(migrated).length) {
      await chrome.storage.local.set(migrated);
    }
  } catch (error) {
    debugLog('migrations.localStorageError', error?.message || error);
  }
}

runMigrations();

export { runMigrations };
