// GPT-5 Refactor: Runtime configuration loader with tier policies.
import { debugLog } from './utils/debug.js';

const CONFIG = {
  DEBUG_MODE: false,
  SUPABASE_URL: 'https://your-project-ref.supabase.co', // Replace with your actual Supabase URL
  SUPABASE_FUNCTIONS_URL: 'https://your-project-ref.supabase.co/functions/v1', // Replace with your functions URL
  HF_SHARED_TOKEN: '',
  AUTH_REDIRECT_URL: '',
  ALLOWED_ORIGINS: ['http://localhost:54321'],
  ROCKETHUB_PROMO_END: '',
  ROCKETHUB_PROMO_DEFAULT_DAYS: 14,
  TIER_POLICIES: {
    free: {
      type: 'free',
      quota: { windowMs: 36 * 60 * 60 * 1000, max: 3 },
      defaultModel: 'gpt2'
    },
    ltd: {
      type: 'license',
      quota: null,
      defaultModel: 'tiiuae/falcon-7b-instruct'
    },
    pro: {
      type: 'subscription',
      quota: null,
      defaultModel: 'tiiuae/falcon-7b-instruct'
    }
  }
};

async function getRuntimeSupabaseConfig() {
  try {
    if (chrome?.storage?.local) {
      const data = await chrome.storage.local.get(['supabaseUrl', 'supabaseFunctionsUrl', 'supabaseAnonKey']);
      return {
        url: (data.supabaseUrl || CONFIG.SUPABASE_URL || '').trim(),
        functionsUrl: (data.supabaseFunctionsUrl || CONFIG.SUPABASE_FUNCTIONS_URL || '').trim(),
        key: (data.supabaseAnonKey || '').trim()
      };
    }
  } catch (error) {
    debugLog('config.supabaseLoadFailed', error?.message || error);
  }
  return {
    url: CONFIG.SUPABASE_URL,
    functionsUrl: CONFIG.SUPABASE_FUNCTIONS_URL,
    key: ''
  };
}

async function getRuntimeHfToken() {
  try {
    if (chrome?.storage?.local) {
      const data = await chrome.storage.local.get(['hfToken', 'hfSharedToken']);
      if (typeof data.hfToken === 'string' && data.hfToken.trim()) {
        return data.hfToken.trim();
      }
      if (typeof data.hfSharedToken === 'string' && data.hfSharedToken.trim()) {
        return data.hfSharedToken.trim();
      }
    }
  } catch (error) {
    debugLog('config.hfTokenLoadFailed', error?.message || error);
  }
  return CONFIG.HF_SHARED_TOKEN || null;
}

function getTierPolicies() {
  return CONFIG.TIER_POLICIES;
}

const configUtils = {
  CONFIG,
  getRuntimeSupabaseConfig,
  getRuntimeHfToken,
  getTierPolicies,
  default: CONFIG
};

if (typeof globalThis !== 'undefined') {
  globalThis.CONFIG = CONFIG;
  globalThis.getRuntimeSupabaseConfig = getRuntimeSupabaseConfig;
  globalThis.getRuntimeHfToken = getRuntimeHfToken;
  globalThis.getTierPolicies = getTierPolicies;
  globalThis.configUtils = configUtils;
}

export { CONFIG, getRuntimeSupabaseConfig, getRuntimeHfToken, getTierPolicies, configUtils };
export default CONFIG;
