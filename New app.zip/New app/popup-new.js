'use strict';

(function() {
  const storageHelper = window.storageHelper;
  const clipboardManager = window.clipboardManager;
  const hfClient = window.hfClient;
  const tokenStorage = window.tokenStore || window.tokenStorage;

  const state = {
    clipboardMonitoring: false,
    currentClipboard: '',
    demoMode: true,
    hasToken: false
  };

  const dom = {};

  document.addEventListener('DOMContentLoaded', init);

  async function init() {
    cacheDom();
    bindEvents();
    await checkToken();
    await loadHistoryCount();
    updateClipboardUI();
  }

  function cacheDom() {
    dom.clipboardToggle = document.getElementById('clipboard-toggle');
    dom.clipboardStatusIcon = document.getElementById('clipboard-status-icon');
    dom.clipboardStatusText = document.getElementById('clipboard-status-text');
    dom.currentClipboard = document.getElementById('current-clipboard');
    dom.useClipboard = document.getElementById('use-clipboard');
    dom.aiInput = document.getElementById('ai-input');
    dom.enhanceBtn = document.getElementById('enhance-btn');
    dom.clearInput = document.getElementById('clear-input');
    dom.aiOutputSection = document.getElementById('ai-output-section');
    dom.aiOutput = document.getElementById('ai-output');
    dom.copyOutput = document.getElementById('copy-output');
    dom.saveOutput = document.getElementById('save-output');
    dom.demoBadge = document.getElementById('demo-badge');
    dom.historyCount = document.getElementById('history-count');
    dom.themeToggle = document.getElementById('theme-toggle');
  }

  function bindEvents() {
    dom.clipboardToggle?.addEventListener('click', toggleClipboardMonitoring);
    dom.useClipboard?.addEventListener('click', useClipboardInAI);
    dom.enhanceBtn?.addEventListener('click', handleEnhance);
    dom.clearInput?.addEventListener('click', clearInput);
    dom.copyOutput?.addEventListener('click', copyOutput);
    dom.saveOutput?.addEventListener('click', saveToHistory);
    dom.themeToggle?.addEventListener('click', toggleTheme);
    dom.aiInput?.addEventListener('keydown', handleKeyboard);

    if (clipboardManager) {
      window.onClipboardChange = handleClipboardChange;
    }
  }

  async function checkToken() {
    try {
      const token = await tokenStorage?.getToken();
      state.hasToken = Boolean(token);
      state.demoMode = !state.hasToken;
      
      if (state.demoMode && dom.demoBadge) {
        dom.demoBadge.hidden = false;
      }
    } catch (error) {
      state.demoMode = true;
      if (dom.demoBadge) dom.demoBadge.hidden = false;
    }
  }

  async function toggleClipboardMonitoring() {
    if (!clipboardManager) return;

    try {
      if (state.clipboardMonitoring) {
        await clipboardManager.stopMonitoring();
        state.clipboardMonitoring = false;
      } else {
        await clipboardManager.startMonitoring();
        state.clipboardMonitoring = true;
        await updateCurrentClipboard();
      }
      updateClipboardUI();
    } catch (error) {
      console.error('Clipboard toggle failed:', error);
    }
  }

  function updateClipboardUI() {
    if (!dom.clipboardToggle) return;

    if (state.clipboardMonitoring) {
      dom.clipboardStatusIcon.textContent = '⏸';
      dom.clipboardStatusText.textContent = 'Stop Monitoring';
      dom.clipboardToggle.classList.add('active');
    } else {
      dom.clipboardStatusIcon.textContent = '▶';
      dom.clipboardStatusText.textContent = 'Start Monitoring';
      dom.clipboardToggle.classList.remove('active');
    }
  }

  async function updateCurrentClipboard() {
    if (!clipboardManager) return;

    try {
      const text = await clipboardManager.getCurrentClipboard();
      state.currentClipboard = text || '';
      displayClipboard(text);
    } catch (error) {
      console.error('Failed to get clipboard:', error);
    }
  }

  function displayClipboard(text) {
    if (!dom.currentClipboard) return;

    if (!text) {
      dom.currentClipboard.innerHTML = '<p class="placeholder">No clipboard content yet</p>';
      dom.useClipboard.disabled = true;
      return;
    }

    const preview = text.length > 150 ? text.slice(0, 147) + '...' : text;
    dom.currentClipboard.innerHTML = `<p>${escapeHtml(preview)}</p>`;
    dom.useClipboard.disabled = false;
  }

  function handleClipboardChange(text) {
    state.currentClipboard = text || '';
    displayClipboard(text);
  }

  function useClipboardInAI() {
    if (!state.currentClipboard) return;
    dom.aiInput.value = state.currentClipboard;
    dom.aiInput.focus();
  }

  async function handleEnhance() {
    const input = dom.aiInput.value.trim();
    if (!input) return;

    dom.enhanceBtn.disabled = true;
    dom.enhanceBtn.querySelector('.btn-label').textContent = 'Enhancing...';

    try {
      let result;
      
      if (state.demoMode) {
        result = await getDemoResponse(input);
      } else {
        const token = await tokenStorage.getToken();
        const response = await hfClient.generate('gpt2', token, `Improve this text: ${input}`, {
          parameters: { max_new_tokens: 100, temperature: 0.7 }
        });
        result = response?.data?.[0]?.generated_text || 'Enhancement failed';
      }

      displayOutput(result);
    } catch (error) {
      console.error('Enhancement failed:', error);
      displayOutput('Enhancement failed. Please try again.');
    } finally {
      dom.enhanceBtn.disabled = false;
      dom.enhanceBtn.querySelector('.btn-label').textContent = 'Enhance with AI';
    }
  }

  async function getDemoResponse(input) {
    await new Promise(resolve => setTimeout(resolve, 800));
    
    const responses = [
      `Enhanced version: ${input.charAt(0).toUpperCase() + input.slice(1)}. This text has been professionally refined for clarity and impact.`,
      `Improved: ${input}. The content has been optimized for better readability and engagement.`,
      `Polished: ${input.trim()}. Enhanced with AI to ensure professional quality and tone.`
    ];
    
    return responses[Math.floor(Math.random() * responses.length)];
  }

  function displayOutput(text) {
    if (!dom.aiOutput || !dom.aiOutputSection) return;

    dom.aiOutput.textContent = text;
    dom.aiOutputSection.hidden = false;
  }

  function clearInput() {
    dom.aiInput.value = '';
    dom.aiOutputSection.hidden = true;
    dom.aiInput.focus();
  }

  async function copyOutput() {
    const text = dom.aiOutput.textContent;
    if (!text) return;

    try {
      await navigator.clipboard.writeText(text);
      showToast('Copied to clipboard');
    } catch (error) {
      console.error('Copy failed:', error);
    }
  }

  async function saveToHistory() {
    const text = dom.aiOutput.textContent;
    if (!text) return;

    try {
      await chrome.runtime.sendMessage({ action: 'save_clipboard', text });
      showToast('Saved to history');
      await loadHistoryCount();
    } catch (error) {
      console.error('Save failed:', error);
    }
  }

  async function loadHistoryCount() {
    try {
      const response = await chrome.runtime.sendMessage({ action: 'getClipboardHistory' });
      const count = response?.history?.length || 0;
      if (dom.historyCount) {
        dom.historyCount.textContent = `${count} item${count === 1 ? '' : 's'} saved`;
      }
    } catch (error) {
      console.error('Failed to load history count:', error);
    }
  }

  function handleKeyboard(e) {
    if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
      e.preventDefault();
      handleEnhance();
    }
  }

  function toggleTheme() {
    const current = document.documentElement.dataset.theme || 'light';
    const next = current === 'light' ? 'dark' : 'light';
    document.documentElement.dataset.theme = next;
    document.body.dataset.theme = next;
    dom.themeToggle.textContent = next === 'dark' ? '☀️' : '🌙';
  }

  function showToast(message) {
    const toast = document.createElement('div');
    toast.className = 'toast toast-success';
    toast.textContent = message;
    document.body.appendChild(toast);
    
    setTimeout(() => toast.classList.add('show'), 10);
    setTimeout(() => {
      toast.classList.remove('show');
      setTimeout(() => toast.remove(), 300);
    }, 2000);
  }

  function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }
})();
