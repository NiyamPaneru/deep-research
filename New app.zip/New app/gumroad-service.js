// Gumroad License Service
// Handles license validation and tier management

class GumroadService {
  constructor() {
    this.apiUrl = 'https://api.gumroad.com/v2';
    this.productId = 'your-product-id'; // Replace with your Gumroad product ID
  }

  async validateLicense(licenseKey) {
    try {
      // For now, use simple local validation
      // In production, validate against Gumroad API
      const response = await this.mockValidation(licenseKey);
      return response;
    } catch (error) {
      console.error('License validation failed:', error);
      return { valid: false, tier: 'FREE' };
    }
  }

  async mockValidation(licenseKey) {
    // Mock validation - replace with real Gumroad API call
    if (!licenseKey || licenseKey.length < 10) {
      return { valid: false, tier: 'FREE' };
    }

    // Simple pattern matching for demo
    if (licenseKey.startsWith('PRO-')) {
      return { 
        valid: true, 
        tier: 'PRO',
        type: 'gumroad',
        expiresAt: null // Lifetime license
      };
    }
    
    if (licenseKey.startsWith('BIZ-')) {
      return { 
        valid: true, 
        tier: 'BUSINESS',
        type: 'gumroad',
        expiresAt: null
      };
    }

    return { valid: false, tier: 'FREE' };
  }

  async storeLicense(licenseKey, validationResult) {
    if (!chrome?.storage?.local) return false;
    
    try {
      await chrome.storage.local.set({
        userLicense: {
          key: licenseKey,
          status: validationResult.valid ? 'valid' : 'invalid',
          tier: validationResult.tier,
          type: validationResult.type || 'gumroad',
          validatedAt: Date.now(),
          expiresAt: validationResult.expiresAt
        },
        userTier: validationResult.valid ? validationResult.tier.toLowerCase() : 'free'
      });
      return true;
    } catch (error) {
      console.error('Failed to store license:', error);
      return false;
    }
  }

  async clearLicense() {
    if (!chrome?.storage?.local) return false;
    
    try {
      await chrome.storage.local.set({
        userLicense: null,
        userTier: 'free'
      });
      return true;
    } catch (error) {
      console.error('Failed to clear license:', error);
      return false;
    }
  }

  getPurchaseUrl() {
    return 'https://gumroad.com/l/smartclipboard';
  }
}

// Singleton instance
const gumroadService = new GumroadService();

// Global export
if (typeof window !== 'undefined') {
  window.gumroadService = gumroadService;
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = gumroadService;
}