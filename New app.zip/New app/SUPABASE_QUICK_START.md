# Supabase Quick Start - 5 Minute Setup

## 🎯 Current Status: ⚠️ NOT CONFIGURED

Your extension has Supabase code ready but **no project connected**.

## ⚡ Super Quick Setup (5 commands)

```bash
# 1. Create project at supabase.com (2 min)
# Get your PROJECT_REF from dashboard URL

# 2. Link project
supabase link --project-ref YOUR_PROJECT_REF

# 3. Create tables
supabase db push

# 4. Deploy functions
supabase functions deploy verify_ltd
supabase functions deploy generate

# 5. Set secrets
supabase secrets set SUPABASE_SERVICE_ROLE_KEY=your_key_here
supabase secrets set HUGGING_FACE_API_KEY=your_hf_token_here
```

## 📝 Update config.js

```javascript
const CONFIG = {
  SUPABASE_URL: 'https://YOUR_PROJECT.supabase.co',
  SUPABASE_FUNCTIONS_URL: 'https://YOUR_PROJECT.supabase.co/functions/v1',
  // ... rest of config
};
```

## ✅ Test It Works

```bash
# Run the test script
node test-supabase.js

# Or test with curl
curl -X POST 'https://YOUR_PROJECT.supabase.co/functions/v1/verify_ltd' \
  -H 'Content-Type: application/json' \
  -d '{"licenseKey":"TEST-LTD-12345","email":"test@example.com"}'
```

## 🆘 Need Help?

See `SUPABASE_STATUS_CHECK.md` for detailed step-by-step guide.

## 🎉 What's Ready

✅ Edge Functions with rate limiting (5/min per IP)
✅ CORS headers configured
✅ Database schema ready
✅ Test license included
✅ Error handling implemented

## 🚀 After Setup

1. Uncomment LTD/Pro code in `settings.js`
2. Test license activation in Chrome
3. Deploy to production!