# 🛠️ Setup & Deployment Guide

## 🚀 Quick Setup

### For Users

1. **Install Extension** from Chrome Web Store
2. **Choose Your Path**:
   - **LTD/Pro**: Purchase → Get key → Activate → Sign in
   - **BYOK**: Get HuggingFace token → Add in settings
   - **Free**: Just start using (3 AI generations/day)

### For Developers

```bash
# Clone repository
git clone [repository-url]
cd smart-clipboard-ai

# Install dependencies
npm install

# Create environment file
cp .env.example .env

# Add your credentials to .env
# SUPABASE_URL=your_url
# SUPABASE_ANON_KEY=your_key
# GUMROAD_PRODUCT_ID=your_id

# Load extension in Chrome
# 1. Go to chrome://extensions/
# 2. Enable "Developer mode"
# 3. Click "Load unpacked"
# 4. Select project folder
```

## 🔑 API Keys & Services

### Supabase Setup (Required for LTD/Pro)

1. **Create Supabase Project**
   - Go to [supabase.com](https://supabase.com)
   - Create new project
   - Copy URL and anon key

2. **Create Tables**

```sql
-- User access tracking
CREATE TABLE user_access (
  email TEXT PRIMARY KEY,
  tier TEXT NOT NULL,
  activated_at TIMESTAMP DEFAULT NOW()
);

-- License key mapping
CREATE TABLE license_mappings (
  license_key TEXT PRIMARY KEY,
  email TEXT NOT NULL,
  tier TEXT NOT NULL,
  activated_at TIMESTAMP DEFAULT NOW()
);
```

3. **Add to .env**
```bash
SUPABASE_URL=https://your-project.supabase.co
SUPABASE_ANON_KEY=your_anon_key_here
```

### HuggingFace Token (Optional - for BYOK)

1. Go to [HuggingFace Settings](https://huggingface.co/settings/tokens)
2. Create account (free)
3. Generate new token with "Read" permissions
4. Users add this in extension settings

### Gumroad Integration (For Payments)

1. **Create Gumroad Account**
   - Go to [gumroad.com](https://gumroad.com)
   - Create products for LTD and Pro plans

2. **Generate License Keys**
   - Enable license keys for products
   - Set up webhook for automatic delivery

3. **Add Product ID**
```bash
GUMROAD_PRODUCT_ID=your_product_id
```

## 🏗️ Build Process

### Development Build
```bash
npm run dev
```

### Production Build
```bash
# Remove console.logs
npm run clean

# Build optimized version
npm run build

# Test production build
npm run test:prod
```

### Package for Chrome Web Store
```bash
# Create zip file
npm run package

# Output: smart-clipboard-ai.zip
```

## 📦 Chrome Web Store Submission

### Pre-Submission Checklist

- [ ] Remove all `console.log` statements
- [ ] Test all features (clipboard, AI, history, settings)
- [ ] Verify license key validation works
- [ ] Test humor toggle functionality
- [ ] Check dark/light theme compatibility
- [ ] Test on multiple screen sizes
- [ ] Verify all permissions are necessary
- [ ] Test Google OAuth sign-in
- [ ] Validate Supabase integration
- [ ] Check error handling

### Store Listing Requirements

**Title**: Smart Clipboard AI

**Short Description** (132 chars max):
"AI-powered clipboard manager with personality. Never lose what you copy, enhance it with AI."

**Detailed Description**:
```
Transform your clipboard into an intelligent assistant!

✨ KEY FEATURES:
• Auto-save everything you copy
• AI enhancement (improve, summarize, translate)
• Smart search through history
• Multi-device sync for LTD users
• Optional humor system (toggle on/off)

💰 FLEXIBLE PRICING:
• Free: 3 AI generations/day
• Pro: $7/mo unlimited AI
• LTD: One-time payment, lifetime access
• BYOK: Bring your own HuggingFace token (free!)

🔒 PRIVACY FIRST:
• All data stays on your device
• No tracking or data collection
• Secure Google authentication
• Manifest V3 compliant

Perfect for developers, writers, students, and anyone who copies text!
```

**Screenshots** (1280x800 or 640x400):
1. Main popup with clipboard history
2. AI generation in action
3. Settings page with humor toggle
4. History page with search
5. License activation screen

**Category**: Productivity

**Language**: English

### Upload Process

1. Go to [Chrome Web Store Developer Dashboard](https://chrome.google.com/webstore/devconsole)
2. Click "New Item"
3. Upload `smart-clipboard-ai.zip`
4. Fill in store listing details
5. Add screenshots and promotional images
6. Set pricing (free with in-app purchases)
7. Submit for review

## 🔒 Security Configuration

### Environment Variables

Never commit these to git:

```bash
# .env file
SUPABASE_URL=your_supabase_url
SUPABASE_ANON_KEY=your_anon_key
GUMROAD_PRODUCT_ID=your_product_id
HUGGINGFACE_TOKEN=your_token_here  # Optional, for testing
```

### Manifest V3 Compliance

✅ **Required**:
- No `eval()` or `new Function()`
- No remote code execution
- Specific permissions only
- Service worker background
- Chrome storage API (not localStorage)

✅ **Implemented**:
- All code is local
- Minimal permissions
- Secure token storage
- HTTPS-only API calls

### Security Best Practices

- All tokens stored in chrome.storage.sync (encrypted)
- No hardcoded credentials
- Input sanitization for XSS prevention
- License key validation server-side
- Rate limiting on API calls

## 📊 Monitoring & Analytics

### Key Metrics to Track

**User Engagement**:
- Daily active users
- Clipboard items saved per user
- AI generations per user
- Humor toggle usage (target: 70%+ keep ON)

**Conversion Metrics**:
- Free → Pro conversion rate
- LTD sales during launch
- BYOK adoption rate
- Churn rate for Pro subscribers

**Technical Metrics**:
- Extension load time
- API response time
- Error rates
- Storage usage per user

### Error Monitoring

Set up logging for:
- Extension popup errors
- Background script errors
- API call failures
- License validation failures
- Storage quota issues

## 🔄 Maintenance Schedule

### Weekly Tasks
- Monitor error logs
- Check user feedback
- Review conversion metrics
- Update joke pool (add 5-10 new jokes)

### Monthly Tasks
- Update dependencies
- Security audit
- Performance optimization
- Add new features based on feedback
- Refresh humor content (20-30 new jokes)

### Quarterly Tasks
- Major feature releases
- UI/UX improvements
- Pricing strategy review
- Marketing campaign updates

## 🚀 Launch Strategy

### Phase 1: Soft Launch (Week 1-2)
- Limited release to beta testers
- Gather feedback
- Fix critical bugs
- Optimize performance

### Phase 2: Public Launch
- Submit to Chrome Web Store
- Launch marketing campaign
- Promote LTD deal
- Monitor metrics closely

### Phase 3: Growth (Month 2+)
- Regular content updates
- Feature enhancements
- Community building
- Expand to other browsers (Firefox, Edge)

## 🆘 Troubleshooting

### Build Issues

**npm install fails**:
```bash
# Clear cache and retry
npm cache clean --force
rm -rf node_modules package-lock.json
npm install
```

**Build errors**:
- Check Node.js version (14+ required)
- Verify all dependencies installed
- Check for syntax errors in code

### Extension Issues

**Extension won't load**:
- Check manifest.json is valid
- Verify all files are present
- Look for errors in Chrome console

**API calls failing**:
- Verify Supabase credentials
- Check network tab for errors
- Ensure CORS is configured correctly

**License validation not working**:
- Check Supabase tables exist
- Verify Google OAuth is configured
- Test with valid license key

## 📞 Support Resources

- **Documentation**: This file + README.md
- **Issues**: GitHub Issues page
- **Email**: support@yourextension.com
- **Discord**: Community server (optional)

---

## ✅ Ready to Deploy!

Your extension is production-ready with:
- ✅ Manifest V3 compliance
- ✅ Security best practices
- ✅ License key system
- ✅ Multi-device support
- ✅ Professional UI
- ✅ Comprehensive error handling

**Next Step**: Package and submit to Chrome Web Store! 🚀
