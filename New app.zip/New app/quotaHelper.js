import storageHelper from './storageHelper.js';
import logger from './services/logger.js';

// Updated Tier System with mandatory sign-in for LTD & Pro
const TIER_CONFIGS = {
  free: {
    name: 'Free',
    generations: 3,
    resetMs: 36 * 60 * 60 * 1000,
    model: 'gpt2',
    requiresSignIn: false, // ✅ No sign-in for free users
    requiresLicense: false
  },
  ltd: {
    name: 'Lifetime Deal',
    generations: 50,
    resetMs: 24 * 60 * 60 * 1000,
    model: 'tiiuae/falcon-7b-instruct',
    requiresSignIn: true, // ✅ MANDATORY sign-in
    requiresLicense: true,
    source: 'rockethub'
  },
  pro: {
    name: 'Pro',
    generations: -1,
    resetMs: 0,
    model: 'tiiuae/falcon-7b-instruct',
    requiresSignIn: true, // ✅ MANDATORY sign-in
    requiresLicense: true,
    source: 'gumroad'
  }
};

async function storageGet(keys) {
  try {
    return await storageHelper.storageGet(keys);
  } catch (_error) {
    return {};
  }
}

async function storageSet(items) {
  try {
    return Boolean(await storageHelper.storageSet(items));
  } catch (_error) {
    return false;
  }
}

function getTierConfig(tierKey) {
  return TIER_CONFIGS[tierKey] || TIER_CONFIGS.free;
}

async function resolveTierKey() {
  try {
    const result = await storageGet(['userTier']);
    return result.userTier || 'free';
  } catch (error) {
    logger.debug('quota.resolveTierFailed', error?.message || error);
    return 'free';
  }
}

async function getUsageSnapshot(tierKey, deviceId) {
  const tier = getTierConfig(tierKey);
  const storageKey = `usage_${tierKey}_${deviceId}`;

  try {
    const result = await storageGet([storageKey]);
    const usage = result[storageKey] || { used: 0, lastReset: Date.now() };
    const now = Date.now();
    const elapsed = now - usage.lastReset;

    if (tier.resetMs > 0 && elapsed >= tier.resetMs) {
      usage.used = 0;
      usage.lastReset = now;
      await storageSet({ [storageKey]: usage });
    }

    const remaining = tier.generations === -1 ? Infinity : Math.max(0, tier.generations - usage.used);
    return {
      plan: tier,
      remaining,
      used: usage.used,
      total: tier.generations
    };
  } catch (error) {
    logger.debug('quota.snapshotFailed', error?.message || error);
    return {
      plan: tier,
      remaining: tier.generations === -1 ? Infinity : tier.generations,
      used: 0,
      total: tier.generations
    };
  }
}

async function checkAndIncrementQuota(tierKey, deviceId, amount = 1) {
  const snapshot = await getUsageSnapshot(tierKey, deviceId);

  if (snapshot.remaining === Infinity) {
    return { ok: true, remaining: Infinity };
  }

  if (snapshot.remaining < amount) {
    return { ok: false, remaining: snapshot.remaining };
  }

  try {
    const storageKey = `usage_${tierKey}_${deviceId}`;
    const result = await storageGet([storageKey]);
    const usage = result[storageKey] || { used: 0, lastReset: Date.now() };
    usage.used += amount;
    await storageSet({ [storageKey]: usage });
    const remaining = snapshot.total === -1 ? Infinity : Math.max(0, snapshot.total - usage.used);
    return { ok: true, remaining };
  } catch (error) {
    logger.debug('quota.incrementFailed', error?.message || error);
    return { ok: false, remaining: snapshot.remaining };
  }
}

async function decrementQuota(tierKey, deviceId, amount = 1) {
  try {
    const tier = getTierConfig(tierKey);
    const storageKey = `usage_${tierKey}_${deviceId}`;
    const result = await storageGet([storageKey]);
    const usage = result[storageKey] || { used: 0, lastReset: Date.now() };
    usage.used = Math.max(0, usage.used - amount);
    await storageSet({ [storageKey]: usage });
    const remaining = tier.generations === -1 ? Infinity : Math.max(0, tier.generations - usage.used);
    return { remaining };
  } catch (error) {
    logger.debug('quota.decrementFailed', error?.message || error);
    return { remaining: 0 };
  }
}

function listPlans(options = {}) {
  const { includeHidden = false } = options;
  return Object.values(TIER_CONFIGS).filter((plan) => includeHidden || !plan.hidden);
}

const quotaHelper = {
  getTierConfig,
  getPlan: getTierConfig,
  resolveTierKey,
  getUsageSnapshot,
  checkAndIncrementQuota,
  decrementQuota,
  listPlans
};

if (typeof globalThis !== 'undefined') {
  globalThis.quotaHelper = quotaHelper;
}

export {
  quotaHelper,
  getTierConfig,
  resolveTierKey,
  getUsageSnapshot,
  checkAndIncrementQuota,
  decrementQuota,
  listPlans
};

export default quotaHelper;
