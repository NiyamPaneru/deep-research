/**
 * API Key Setup Script for Smart Clipboard AI
 * Run this in the browser console to configure your API keys
 */

// Configuration function
async function setupApiKeys() {
  console.log('🔧 Smart Clipboard AI - API Key Setup');
  
  // Check if we're in a Chrome extension context
  const isExtension = typeof chrome !== 'undefined' && chrome.storage;
  
  if (isExtension) {
    console.log('✅ Chrome extension context detected');
    
    // Set up Hugging Face API key for the Supabase function
    const hfApiKey = prompt('Enter your Hugging Face API key:');
    if (hfApiKey) {
      try {
        await chrome.storage.sync.set({ 
          supabaseApiKey: hfApiKey.trim(),
          supabaseUrl: 'https://kmyewkhcpvqkfyhlodeg.functions.supabase.co/generate'
        });
        console.log('✅ API keys saved to Chrome storage');
        alert('✅ API keys configured successfully!');
      } catch (error) {
        console.error('❌ Failed to save API keys:', error);
        alert('❌ Failed to save API keys. Check console for details.');
      }
    }
  } else {
    console.log('⚠️ Not in Chrome extension context, using localStorage');
    
    const hfApiKey = prompt('Enter your Hugging Face API key:');
    if (hfApiKey) {
      localStorage.setItem('smartClipboard_supabaseApiKey', hfApiKey.trim());
      localStorage.setItem('smartClipboard_supabaseUrl', 'https://kmyewkhcpvqkfyhlodeg.functions.supabase.co/generate');
      console.log('✅ API keys saved to localStorage');
      alert('✅ API keys configured successfully!');
    }
  }
}

// Test function
async function testApiConnection() {
  console.log('🧪 Testing API connection...');
  
  try {
    const response = await fetch('https://kmyewkhcpvqkfyhlodeg.functions.supabase.co/generate', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        prompt: 'test prompt',
        useCase: 'headline'
      })
    });
    
    if (response.ok) {
      const data = await response.json();
      console.log('✅ API connection successful:', data);
      alert('✅ API connection test passed!');
    } else {
      console.error('❌ API returned error:', response.status, response.statusText);
      alert(`❌ API test failed: ${response.status} ${response.statusText}`);
    }
  } catch (error) {
    console.error('❌ API connection failed:', error);
    alert('❌ API connection test failed. Check console for details.');
  }
}

// Auto-run setup
console.log('Run setupApiKeys() to configure your API keys');
console.log('Run testApiConnection() to test the API');

// Export functions to global scope
window.setupApiKeys = setupApiKeys;
window.testApiConnection = testApiConnection;