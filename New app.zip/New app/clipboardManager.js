(function initClipboardManager(globalScope) {
  'use strict';

  const CLIPBOARD_HISTORY_KEY = 'clipboardHistory';
  const LEGACY_CLIPBOARD_KEYS = ['clipboardHistory_v2'];
  const MAX_CLIPBOARD_ITEMS = 50;
  const MIN_TEXT_LENGTH = 3;
  const MAX_TEXT_LENGTH = 10000;
  const CLIPBOARD_CONTENT_SCRIPT_ID = 'smartClipboardListener';
  const PERMISSION_ORIGINS = ['https://*/*', 'http://*/*'];

  let isMonitoring = false;
  let lastClipboardText = '';
  let runtimeListenerRegistered = false;

  let migrationAttempted = false;

  async function ensureHistoryMigrated() {
    if (migrationAttempted) return;
    migrationAttempted = true;

    try {
      const keys = [CLIPBOARD_HISTORY_KEY, ...LEGACY_CLIPBOARD_KEYS];
      let payload;

      if (globalScope.storageHelper) {
        payload = await globalScope.storageHelper.storageGet(keys);
      } else if (chrome?.storage?.local) {
        payload = await new Promise((resolve) => {
          chrome.storage.local.get(keys, resolve);
        });
      } else {
        return;
      }

      const current = Array.isArray(payload?.[CLIPBOARD_HISTORY_KEY]) ? payload[CLIPBOARD_HISTORY_KEY] : [];
      if (current.length) {
        return;
      }

      for (const legacyKey of LEGACY_CLIPBOARD_KEYS) {
        const legacy = Array.isArray(payload?.[legacyKey]) ? payload[legacyKey] : [];
        if (!legacy.length) continue;

        if (globalScope.storageHelper) {
          await globalScope.storageHelper.storageSet({ [CLIPBOARD_HISTORY_KEY]: legacy });
          if (typeof globalScope.storageHelper.storageRemove === 'function') {
            await globalScope.storageHelper.storageRemove(legacyKey);
          }
        } else if (chrome?.storage?.local) {
          await new Promise((resolve) => {
            chrome.storage.local.set({ [CLIPBOARD_HISTORY_KEY]: legacy }, resolve);
          });
          chrome.storage.local.remove(legacyKey);
        }
        break;
      }
    } catch (error) {
      console.warn('Clipboard history migration failed:', error);
    }
  }

  const clipboardManager = {
    startMonitoring,
    stopMonitoring,
    getClipboardHistory,
    addToHistory,
    clearHistory,
    copyToClipboard,
    getCurrentClipboard,
    hasHostPermission,
    permissionOrigins: () => [...PERMISSION_ORIGINS],
    isMonitoringActive: () => isMonitoring
  };

  async function startMonitoring() {
    if (isMonitoring) return;

    try {
      await ensureHistoryMigrated();
      registerRuntimeListener();

      const registered = await registerClipboardContentScript();
      if (!registered) {
        throw new Error('CONTENT_SCRIPT_REGISTRATION_FAILED');
      }

      lastClipboardText = '';
      isMonitoring = true;
      console.log('Clipboard monitoring started');
    } catch (error) {
      isMonitoring = false;
      console.warn('Failed to start clipboard monitoring:', error?.message || error);
      throw error;
    }
  }

  async function stopMonitoring() {
    if (!isMonitoring) return;

    isMonitoring = false;
    console.log('Clipboard monitoring stopped');
  }

  async function getCurrentClipboard() {
    try {
      if (navigator.clipboard && navigator.clipboard.readText) {
        return await navigator.clipboard.readText();
      }
    } catch (error) {
      // Clipboard access denied or not available
    }
    return '';
  }

  async function registerClipboardContentScript() {
    if (typeof chrome === 'undefined' || !chrome.scripting?.registerContentScripts) {
      return false;
    }

    try {
      const existing = await chrome.scripting.getRegisteredContentScripts({ ids: [CLIPBOARD_CONTENT_SCRIPT_ID] });
      if (Array.isArray(existing) && existing.length) {
        return true;
      }
    } catch (_error) {
      // getRegisteredContentScripts rejects when nothing is registered — safe to ignore
    }

    try {
      await chrome.scripting.registerContentScripts([
        {
          id: CLIPBOARD_CONTENT_SCRIPT_ID,
          js: ['content-scripts/clipboard-listener.js'],
          matches: PERMISSION_ORIGINS,
          runAt: 'document_end'
        }
      ]);
      return true;
    } catch (error) {
      console.warn('Failed to register clipboard listener script:', error?.message || error);
      return false;
    }
  }

  function registerRuntimeListener() {
    if (runtimeListenerRegistered) return;
    if (typeof chrome === 'undefined' || !chrome.runtime?.onMessage?.addListener) {
      return;
    }

    chrome.runtime.onMessage.addListener((message) => {
      if (!message || message.action !== 'clipboard:saved') {
        return;
      }

      const item = message.item;
      const text = typeof item?.text === 'string' ? item.text : '';
      if (!text) {
        return;
      }

      lastClipboardText = text;
      if (!isMonitoring) {
        return;
      }

      if (typeof globalScope.onClipboardChange === 'function') {
        try {
          globalScope.onClipboardChange(text, item);
        } catch (_error) {
          // ignore popup callback errors
        }
      }
    });

    runtimeListenerRegistered = true;
  }

  async function hasHostPermission() {
    if (typeof chrome === 'undefined' || !chrome.permissions?.contains) {
      return true;
    }

    return new Promise((resolve) => {
      try {
        chrome.permissions.contains({ origins: PERMISSION_ORIGINS }, (granted) => {
          if (chrome.runtime?.lastError) {
            resolve(false);
            return;
          }
          resolve(Boolean(granted));
        });
      } catch (_error) {
        resolve(false);
      }
    });
  }

  async function copyToClipboard(text) {
    try {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        await navigator.clipboard.writeText(text);
        lastClipboardText = text; // Update our tracking
        return true;
      }
    } catch (error) {
      console.warn('Failed to copy to clipboard:', error);
    }
    return false;
  }

  function detectContentType(text) {
    if (!text) return 'text';
    const trimmed = text.trim();
    
    if (/^https?:\/\//.test(trimmed)) return 'url';
    if (/^\w+@\w+\.\w+/.test(trimmed)) return 'email';
    if (/^\+?[\d\s\-\(\)]+$/.test(trimmed) && trimmed.length > 7) return 'phone';
    if (/(function|class|const|let|var|def|import|export)\s/.test(trimmed)) return 'code';
    if (/^\d+$/.test(trimmed)) return 'number';
    if (trimmed.includes('\n') && trimmed.length > 100) return 'document';
    
    return 'text';
  }

  async function addToHistory(text) {
    if (!text || typeof text !== 'string') return;
    
    const cleanText = text.trim();
    if (cleanText.length < MIN_TEXT_LENGTH || cleanText.length > MAX_TEXT_LENGTH) return;
    
    try {
      const history = await getClipboardHistory();
      
      // Remove duplicates
      const filtered = history.filter(item => item.text !== cleanText);
      
      // Add new item at the beginning
      const newItem = {
        id: Date.now(),
        text: cleanText,
        timestamp: new Date().toISOString(),
        source: 'clipboard',
        type: detectContentType(cleanText)
      };
      
      filtered.unshift(newItem);
      
      // Limit history size
      if (filtered.length > MAX_CLIPBOARD_ITEMS) {
        filtered.splice(MAX_CLIPBOARD_ITEMS);
      }
      
      // Save to storage
      if (globalScope.storageHelper) {
        await globalScope.storageHelper.storageSet({ [CLIPBOARD_HISTORY_KEY]: filtered });
        if (typeof globalScope.storageHelper.storageRemove === 'function' && LEGACY_CLIPBOARD_KEYS.length) {
          await globalScope.storageHelper.storageRemove(LEGACY_CLIPBOARD_KEYS);
        }
      } else if (chrome?.storage?.local) {
        await chrome.storage.local.set({ [CLIPBOARD_HISTORY_KEY]: filtered });
        if (LEGACY_CLIPBOARD_KEYS.length) {
          chrome.storage.local.remove(LEGACY_CLIPBOARD_KEYS);
        }
      }
      
      return newItem;
    } catch (error) {
      console.warn('Failed to add to clipboard history:', error);
    }
  }

  async function getClipboardHistory() {
    try {
      await ensureHistoryMigrated();
      let data;
      if (globalScope.storageHelper) {
        data = await globalScope.storageHelper.storageGet({ [CLIPBOARD_HISTORY_KEY]: [] });
      } else if (chrome?.storage?.local) {
        data = await new Promise((resolve) => {
          chrome.storage.local.get({ [CLIPBOARD_HISTORY_KEY]: [] }, resolve);
        });
      } else {
        return [];
      }
      
      const history = data[CLIPBOARD_HISTORY_KEY] || [];
      return Array.isArray(history) ? history : [];
    } catch (error) {
      console.warn('Failed to get clipboard history:', error);
      return [];
    }
  }

  async function clearHistory() {
    try {
      if (globalScope.storageHelper) {
        await globalScope.storageHelper.storageSet({ [CLIPBOARD_HISTORY_KEY]: [] });
        if (typeof globalScope.storageHelper.storageRemove === 'function' && LEGACY_CLIPBOARD_KEYS.length) {
          await globalScope.storageHelper.storageRemove(LEGACY_CLIPBOARD_KEYS);
        }
      } else if (chrome?.storage?.local) {
        await chrome.storage.local.set({ [CLIPBOARD_HISTORY_KEY]: [] });
        if (LEGACY_CLIPBOARD_KEYS.length) {
          chrome.storage.local.remove(LEGACY_CLIPBOARD_KEYS);
        }
      }
      return true;
    } catch (error) {
      console.warn('Failed to clear clipboard history:', error);
      return false;
    }
  }

  // Auto-start monitoring when loaded
  // NOTE: Do not auto-start monitoring here. Monitoring should be controlled
  // by the popup UI (user preference) or by an explicit background action.
  // This avoids surprising the user by enabling clipboard reads without consent.

  globalScope.clipboardManager = clipboardManager;
  
  if (typeof module !== 'undefined' && module.exports) {
    module.exports = clipboardManager;
  }
})(typeof self !== 'undefined' ? self : typeof globalThis !== 'undefined' ? globalThis : this);