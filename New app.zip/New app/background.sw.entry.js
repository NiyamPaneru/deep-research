// GPT-5 Refactor: Esbuild entry aggregates background modules.
import './config.js';
import './storage/migrations.js';
import './background/index.js';
