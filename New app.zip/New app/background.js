import logger from './services/logger.js';
import telemetry from './services/telemetry.js';
import CONFIG, { getRuntimeSupabaseConfig, getRuntimeHfToken } from './config.js';
import storageHelper from './storageHelper.js';
import quotaHelper from './quotaHelper.js';
import tokenStore from './services/tokenStore.js';
import hfClient from './services/hfClient.js';
import './services/humorManager.js';
import './services/auth.js';

const backgroundLogger = logger || { debug: () => {} };

// Production debug wrapper - only logs in development
function debugLog(event, data) {
  if (typeof CONFIG !== 'undefined' && CONFIG.DEBUG_MODE) {
    backgroundLogger.debug(event, data);
  }
}

try {
  chrome?.storage?.local?.set?.({ backgroundReady: true, backgroundError: null });
} catch (_error) {
  backgroundLogger.debug('background.initFlagFailed');
}

const HISTORY_LIMIT = 50;
const HISTORY_TEXT_LIMIT = 8000;
const DEFAULT_SUPABASE_FUNCTION_URL = 'https://smartclipboard-ai.supabase.co/functions/v1/generate';
const SUPABASE_HISTORY_URL_KEY = 'supabaseHistoryUrl';
const SUPABASE_URL_KEY = 'supabaseUrl';
const SUPABASE_API_KEY_STORAGE_KEY = 'supabaseApiKey';
const GUMROAD_VERIFY_ENDPOINT = 'https://api.gumroad.com/v2/licenses/verify';
const GUMROAD_PRODUCT_PERMALINK = 'smartclipboard'; // Replace with your actual product permalink
const LICENSE_STORAGE_KEY = 'userLicense';
const LTD_OVERRIDE_TIER = 'enterprise';

const backgroundGlobal = typeof self !== 'undefined' ? self : typeof globalThis !== 'undefined' ? globalThis : undefined;
let AuthService = backgroundGlobal?.AuthService || backgroundGlobal?.authService || null;
let authInitialized = false;

if (backgroundGlobal && telemetry) {
	backgroundGlobal.telemetry = telemetry;
}

function ensureAuthService(options = {}) {
	const { eager = false } = options;
	if (!AuthService || eager) {
		AuthService = backgroundGlobal?.AuthService || backgroundGlobal?.authService || null;
	}

	if (!AuthService) {
		if (eager) {
			backgroundLogger.debug('auth.serviceUnavailableDuringInit');
		}
		return null;
	}

	if (!authInitialized && typeof AuthService.initialize === 'function') {
		authInitialized = true;
		AuthService.initialize().catch((error) => {
			backgroundLogger.debug('auth.initializeFailed', error?.message || error);
		});
	}

	return AuthService;
}

ensureAuthService({ eager: true });

debugLog('lifecycle.backgroundBoot');

function hasChrome() {
	return typeof chrome !== 'undefined';
}

if (hasChrome() && chrome.runtime?.onInstalled) {
	chrome.runtime.onInstalled.addListener(async () => {
		debugLog('lifecycle.installed');
		
		// Initialize default humor settings
		const result = await chrome.storage.local.get(['humorSettings']);
		if (!result.humorSettings) {
			await chrome.storage.local.set({
				humorSettings: {
					enabled: true,
					tone: 'playful',
					frequency: 'random'
				}
			});
		}
		
		if (!chrome.contextMenus?.create) return;

		chrome.contextMenus.create({
			id: 'saveToClipboard',
			title: 'Save to Smart Clipboard',
			contexts: ['selection']
		});

		chrome.contextMenus.create({
			id: 'savePageUrlToClipboard',
			title: 'Save Page URL to Smart Clipboard',
			contexts: ['page']
		});
	});
}

if (hasChrome() && chrome.contextMenus?.onClicked?.addListener) {
	chrome.contextMenus.onClicked.addListener(async (info, tab) => {
		try {
			if (info.menuItemId === 'saveToClipboard' && info.selectionText) {
				await saveToClipboardHistory(info.selectionText, { source: 'context-menu' });
			}

			if (info.menuItemId === 'savePageUrlToClipboard' && tab?.url) {
				const text = tab.title ? `${tab.url}\nTitle: ${tab.title}` : tab.url;
				await saveToClipboardHistory(text, { source: 'context-menu' });
			}
		} catch (error) {
			debugLog('contextMenu.saveFailed', error?.message || error);
		}
	});
}

if (hasChrome() && chrome.runtime?.onMessage?.addListener) {
	chrome.runtime.onMessage.addListener((request, _sender, sendResponse) => {
		(async () => {
			try {
				const action = request.action || request.type;

				switch (action) {

					case 'generate':
						await handleDirectGenerate(request, sendResponse);
						return;

					case 'generateContent':
						await handleSupabaseGenerate(request, sendResponse);
						return;

					case 'setToken': {
						const token = typeof request.token === 'string' ? request.token : '';
						try {
							const result = await tokenStore.setToken(token);
							sendResponse(result || { ok: false, code: 'TOKEN_STORE_FAILED' });
						} catch (error) {
							logger.debug('setToken handler failed', error?.message || error);
							sendResponse({ ok: false, code: 'TOKEN_STORE_FAILED', message: 'Unable to store token on this device.' });
						}
						return;
					}

					case 'getToken': {
						try {
							const userToken = await getStoredToken();
							const sharedToken = await getSharedHfToken();
							const hasUserToken = Boolean(userToken);
							const hasSharedToken = Boolean(sharedToken);
							const hasToken = hasUserToken || hasSharedToken;
							sendResponse({
								ok: true,
								token: hasUserToken ? userToken : null,
								hasToken,
								hasUserToken,
								hasSharedToken,
								source: hasUserToken ? 'user' : (hasSharedToken ? 'shared' : null)
							});
						} catch (error) {
							logger.debug('getToken handler failed', error?.message || error);
							sendResponse({ ok: false, token: null, hasToken: false, hasUserToken: false, hasSharedToken: false, source: null });
						}
						return;
					}

					case 'clearToken':
						try {
							await tokenStore.clearToken();
							sendResponse({ ok: true });
						} catch (error) {
							logger.debug('clearToken handler failed', error?.message || error);
							sendResponse({ ok: false });
						}
						return;

					case 'ping':
						sendResponse({ ok: true, ts: Date.now() });
						return;

					case 'getClipboardHistory': {
						const payload = await getClipboardHistory();
						sendResponse(payload);
						return;
					}

					case 'saveHistoryItemCloud': {
						const result = await enqueueCloudHistory(request.text);
						sendResponse(result);
						return;
					}

					case 'clearHistory':
						await chrome.storage?.local?.remove(['clipboardHistory']);
						sendResponse({ success: true });
						return;

					case 'deleteHistoryItem': {
						const result = await deleteHistoryItem(request);
						sendResponse(result);
						return;
					}

					case 'updateHistoryItem': {
						const result = await updateHistoryItem(request);
						sendResponse(result);
						return;
					}

					case 'verifyLicenseKey': {
						const result = await verifyAndStoreLicense(request);
						sendResponse(result);
						return;
					}

					case 'getLicenseInfo': {
						const license = await getStoredLicense();
						sendResponse({ success: true, license });
						return;
					}

					case 'removeLicenseKey': {
						const result = await clearStoredLicense();
						sendResponse(result);
						return;
					}

					case 'get_history': {
						const result = await chrome.storage?.local?.get(['clipboardHistory']);
						sendResponse({ history: result?.clipboardHistory || [] });
						return;
					}

					case 'save_clipboard':
						// Only allow manual saves from context menu or popup
						if (request.source === 'content-script') {
							sendResponse({ status: 'ignored', reason: 'auto_save_disabled' });
							return;
						}

						const savedItem = await saveToClipboardHistory(request.text, { source: request.source });
						sendResponse({ status: savedItem ? 'saved' : 'skipped', item: savedItem || null });
						return;

					case 'checkAuthState':
					case 'signIn':
					case 'signOut':
					case 'startSubscription':
					case 'cancelSubscription':
					case 'processSubscriptionWebhook':
					case 'syncUsageData':
					case 'getUserUsage':
					case 'getUserSubscription': {
						const authResponse = await handleAuthAction(action, request);
						sendResponse(authResponse);
						return;
					}

					case 'verifyLTDLicense': {
						const result = await handleVerifyLTDLicense(request);
						sendResponse(result);
						return;
					}

					case 'signInWithGoogle': {
						const result = await handleGoogleSignIn();
						sendResponse(result);
						return;
					}

					case 'saveLTDToCloud': {
						const result = await handleSaveLTDToCloud(request);
						sendResponse(result);
						return;
					}

					case 'verifyGumroadLicense': {
						const result = await handleVerifyGumroadLicense(request);
						sendResponse(result);
						return;
					}

					case 'saveProToCloud': {
						const result = await handleSaveProToCloud(request);
						sendResponse(result);
						return;
					}

					case 'checkProStatus': {
						const result = await handleCheckProStatus(request);
						sendResponse(result);
						return;
					}

					default:
						sendResponse({ outputs: [], error: null });
						return;
				}
			} catch (error) {
				sendResponse({ outputs: [], error: error?.message || String(error) });
			}
		})();

		return true;
	});
}

	if (typeof self !== 'undefined' && typeof self.addEventListener === 'function') {
		self.addEventListener('activate', () => {
			backgroundLogger.debug('lifecycle.serviceWorkerActivated');
		});
	}

async function handleDirectGenerate(request, sendResponse) {
	let quotaReservation = null;

	try {
		const { token, source } = await getEffectiveToken();
		if (!token) {
			sendResponse({ outputs: [], error: 'AI is temporarily unavailable. Try again soon.', code: 'HF_TOKEN_MISSING' });
			return;
		}

		const tierKey = await getCurrentUserTier();
		if (shouldEnforceQuota(tierKey, source)) {
			quotaReservation = await reserveQuotaSlot(tierKey);
			if (!quotaReservation.ok) {
				sendResponse({
					outputs: [],
					error: 'Free plan limit reached — try again after the 36-hour window resets.',
					code: 'QUOTA_EXCEEDED',
					remaining: quotaReservation.remaining ?? 0
				});
				return;
			}
		}

		const prompt = sanitizeText(request.input || '').slice(0, 4000);
		const desired = Math.min(Math.max(Number(request.responses) || 1, 1), 5);
		const modelName = typeof request.model === 'string' && request.model.trim()
			? request.model.trim()
			: 'gpt2';

		const hfResponse = await hfClient.generate(modelName, token, prompt, {
			parameters: {
				num_return_sequences: desired,
				max_new_tokens: 60,
				return_full_text: false,
				temperature: 0.8
			}
		});

		const outputs = extractOutputs(hfResponse.data, desired);
		if (!outputs.length) {
			await releaseQuotaSlot(quotaReservation);
			sendResponse({ outputs: [], error: 'Model returned no output.' });
			return;
		}

		const remainingQuota = typeof quotaReservation?.remaining === 'number' ? quotaReservation.remaining : null;
		sendResponse({ outputs, error: null, remainingQuota });
	} catch (error) {
		await releaseQuotaSlot(quotaReservation);
		const mapped = mapModelError(error);
		logger.debug('Direct generate failed', mapped.code || error?.message || error);
		sendResponse({ outputs: [], error: mapped.message, code: mapped.code });
	}
}

async function handleSupabaseGenerate(request, sendResponse) {
	try {
		const prompt = sanitizeText(request.prompt || '').slice(0, 4000);
		const useCase = sanitizeText(request.useCase || 'general');
		const outputs = await generateContent(prompt, useCase);

		sendResponse({ success: true, outputs, content: outputs });
	} catch (error) {
		sendResponse({ success: false, error: error?.message || 'Generation failed.' });
	}
}

function extractOutputs(payload, desired) {
	const limit = Math.max(1, desired);
	const collected = [];
	if (Array.isArray(payload)) {
		payload.forEach((entry) => {
			const text = typeof entry === 'string'
				? entry
				: entry?.generated_text || entry?.text || '';
			if (text && collected.length < limit) {
				collected.push(formatModelOutput(text));
			}
		});
	} else if (payload && typeof payload === 'object') {
		const text = payload.generated_text || payload.text;
		if (text) {
			collected.push(formatModelOutput(text));
		}
	}
	return collected;
}

async function getClipboardHistory() {
	const tier = await getCurrentUserTier();

	if (isCloudTier(tier)) {
		const cloudHistory = await fetchCloudHistory();
		if (cloudHistory?.length) {
			return { history: cloudHistory, source: 'cloud' };
		}
	}

	const result = await chrome.storage.local.get(['clipboardHistory']);
	return {
		history: Array.isArray(result.clipboardHistory) ? result.clipboardHistory : [],
		source: 'local'
	};
}

async function enqueueCloudHistory(rawText) {
	const tier = await getCurrentUserTier();
	if (!isCloudTier(tier)) {
		return { success: false, skipped: true, reason: 'not_cloud_tier' };
	}

	const cleaned = sanitizeText(rawText || '').trim();
	if (!cleaned) {
		return { success: false, error: 'empty' };
	}

	const item = { id: Date.now(), text: cleaned, timestamp: new Date().toISOString() };

	try {
		await pushCloudHistoryItem(item);
		return { success: true, queued: true };
	} catch (error) {
		return { success: false, error: error?.message || String(error) };
	}
}

async function deleteHistoryItem(payload) {
	const { id, text } = payload || {};
	const result = await chrome.storage.local.get(['clipboardHistory']);
	const history = Array.isArray(result.clipboardHistory) ? result.clipboardHistory : [];

	const numericId = typeof id === 'string' ? Number.parseInt(id, 10) : id;
	const hasId = Number.isFinite(numericId);
	const sanitizedText = typeof text === 'string' ? text : '';

	const filtered = history.filter((item) => {
		if (hasId) {
			return Number(item.id) !== numericId;
		}
		if (sanitizedText) {
			return item.text !== sanitizedText;
		}
		return true;
	});

	const removed = history.length > filtered.length;
	await chrome.storage.local.set({ clipboardHistory: filtered });
	return { success: true, removed, newHistory: filtered };
}

function mapModelError(error) {
	const code = error?.code || error?.message || 'HF_NETWORK_ERROR';
	switch (code) {
		case 'HF_INVALID_TOKEN':
			return { code: 'HF_INVALID_TOKEN', message: 'Invalid Hugging Face token — re-enter or get one at Hugging Face.' };
		case 'HF_MODEL_NOT_FOUND':
			return { code: 'HF_MODEL_NOT_FOUND', message: "Model not found — try 'gpt2' or check spelling." };
		case 'HF_EMPTY_RESPONSE':
			return { code: 'HF_EMPTY_RESPONSE', message: 'Model returned no output — try again or switch model.' };
		case 'HF_SERVER_ERROR':
			return { code: 'HF_SERVER_ERROR', message: 'Server error — try again shortly.' };
		case 'HF_NETWORK_ERROR':
		default:
			return { code: 'HF_NETWORK_ERROR', message: 'Network error — check your connection and try again.' };
	}
}

async function updateHistoryItem(payload) {
	const { id, text } = payload || {};
	const updatedText = sanitizeText(String(text || '').slice(0, HISTORY_TEXT_LIMIT)).trim();
	if (!updatedText) {
		return { success: false, error: 'empty' };
	}

	const result = await chrome.storage.local.get(['clipboardHistory']);
	const history = Array.isArray(result.clipboardHistory) ? result.clipboardHistory : [];
	const numericId = typeof id === 'string' ? Number.parseInt(id, 10) : id;
	const hasId = Number.isFinite(numericId);

	const index = history.findIndex((item) => (hasId ? Number(item.id) === numericId : item.text === updatedText));
	if (index === -1) {
		return { success: false, error: 'not_found' };
	}

	const now = new Date().toISOString();
	const updatedItem = {
		...history[index],
		text: updatedText,
		timestamp: now
	};

	history[index] = updatedItem;
	const limit = await getHistoryLimit();
	const deduped = history
		.filter((entry, position) => position === history.findIndex((candidate) => candidate.id === entry.id))
		.map((entry) => ({
			...entry,
			text: sanitizeText(String(entry.text || '').slice(0, HISTORY_TEXT_LIMIT)).trim()
		}))
		.slice(0, limit);

	await chrome.storage.local.set({ clipboardHistory: deduped });
	return { success: true, item: updatedItem, history: deduped };
}

async function handleAuthAction(action, request) {
	const service = ensureAuthService();
	if (!service) {
		return action === 'signOut' ? { success: true } : { success: false, error: 'auth_disabled' };
	}

	try {
		switch (action) {
			case 'checkAuthState': {
				const user = await service.checkAuthState();

				if (user) {
					const subscription = await service.getUserSubscription();
					return { isAuthenticated: true, user, subscription };
				}

				return { isAuthenticated: false };
			}

			case 'signIn': {
				const result = await service.signIn();
				const subscription = await service.getUserSubscription();
				return { success: true, user: result.user, subscription };
			}

			case 'signOut':
				await service.signOut();
				return { success: true };

			case 'startSubscription':
				await service.startSubscription(request.tier);
				return { success: true };

			case 'cancelSubscription': {
				const subscription = await service.cancelSubscription();
				return { success: true, subscription };
			}

			case 'processSubscriptionWebhook': {
				const subscription = await service.processSubscriptionWebhook(request.data);
				return { success: true, subscription };
			}

			case 'syncUsageData': {
				const synced = await service.syncUsageData(request.tierKey, request.usage);
				return { success: synced };
			}

			case 'getUserUsage': {
				const usage = await service.getUserUsage(request.tierKey);
				return { success: true, usage };
			}

			case 'getUserSubscription': {
				const subscription = await service.getUserSubscription();
				return { success: true, subscription };
			}

			default:
				return { success: false, error: 'unsupported_action' };
		}
	} catch (error) {
		return { success: false, error: error?.message || String(error) };
	}
}

async function saveToClipboardHistory(text, context = {}) {
	const cleaned = sanitizeText(String(text || '').slice(0, HISTORY_TEXT_LIMIT)).trim();
	if (!cleaned) {
		return null;
	}

	const result = await chrome.storage.local.get(['clipboardHistory']);
	const history = Array.isArray(result.clipboardHistory) ? result.clipboardHistory : [];
	const limit = await getHistoryLimit();

	const filtered = history.filter((item) => item.text !== cleaned);
	const newItem = {
		id: Date.now(),
		text: cleaned,
		timestamp: new Date().toISOString(),
		source: typeof context?.source === 'string' && context.source.trim() ? context.source.trim() : 'unknown'
	};

	filtered.unshift(newItem);

	if (filtered.length > limit) {
		filtered.splice(limit);
	}

	await chrome.storage.local.set({ clipboardHistory: filtered });
	notifyClipboardListeners(newItem, context);
	return newItem;
}

async function fetchCloudHistory() {
	const endpoint = await getHistoryEndpoint();
	if (!endpoint) {
		return null;
	}

	const apiKey = await getApiKey();

	try {
		const response = await fetch(endpoint, {
			method: 'GET',
			headers: {
				'Content-Type': 'application/json',
				...(apiKey ? { Authorization: `Bearer ${apiKey}` } : {})
			}
		});

		if (!response.ok) throw new Error(`Cloud history request failed ${response.status}`);

		const data = await response.json();
		if (!Array.isArray(data.history)) return null;

		const limit = await getHistoryLimit();
		return data.history
			.map((item) => ({
				id: Number(item.id) || Date.now(),
				text: sanitizeText(String(item.text || '').slice(0, HISTORY_TEXT_LIMIT)).trim(),
				timestamp: item.timestamp || new Date().toISOString()
			}))
			.slice(0, limit);
	} catch (error) {
		logger.debug('Cloud history unavailable', error?.message || error);
		return null;
	}
}

async function pushCloudHistoryItem(item) {
	const endpoint = await getHistoryEndpoint();
	if (!endpoint) {
		throw new Error('Supabase history endpoint missing');
	}

	const apiKey = await getApiKey();

	const response = await fetch(endpoint, {
		method: 'POST',
		headers: {
			'Content-Type': 'application/json',
			...(apiKey ? { Authorization: `Bearer ${apiKey}` } : {})
		},
		body: JSON.stringify({ item })
	});

	if (!response.ok) {
		const statusText = response.statusText || `HTTP ${response.status}`;
		throw new Error(`Cloud history push failed: ${statusText}`);
	}
}

function notifyClipboardListeners(item, context = {}) {
	if (!item || !chrome?.runtime?.sendMessage) {
		return;
	}

	const payload = {
		action: 'clipboard:saved',
		item: {
			id: Number(item.id) || Date.now(),
			text: item.text,
			timestamp: item.timestamp || new Date().toISOString(),
			source: context.source || item.source || 'unknown'
		},
		source: context.source || 'unknown'
	};

	try {
		chrome.runtime.sendMessage(payload);
	} catch (error) {
		if (typeof logger?.debug === 'function') {
			logger.debug('notifyClipboardListeners failed', error?.message || error);
		}
	}
}

async function verifyAndStoreLicense(request) {
	const licenseKey = sanitizeLicenseKey(request?.licenseKey || '');
	if (!licenseKey) {
		return { success: false, error: 'missing_license_key' };
	}

	const provider = String(request?.provider || detectLicenseProvider(licenseKey)).toLowerCase();
	try {
		let verification;
		if (provider === 'rockethub') {
			verification = await verifyLicenseWithRocketHub(licenseKey);
		} else {
			verification = await verifyLicenseWithGumroad(licenseKey);
		}

		if (!verification.valid) {
			await chrome.storage.local.remove([LICENSE_STORAGE_KEY]);
			return { success: false, error: verification.error || 'invalid_license' };
		}

		const licenseRecord = {
			status: 'valid',
			type: 'ltd',
			provider: verification.provider,
			overrideTier: LTD_OVERRIDE_TIER,
			activatedAt: new Date().toISOString(),
			maskedKey: maskLicenseKey(licenseKey),
			customer: verification.customer || null,
			features: verification.features || ['Unlimited generations', 'Lifetime updates']
		};

		await chrome.storage.local.set({
			[LICENSE_STORAGE_KEY]: licenseRecord,
			userTier: LTD_OVERRIDE_TIER
		});

		return { success: true, license: licenseRecord };
	} catch (error) {
		return { success: false, error: error?.message || 'license_validation_failed' };
	}
}

async function clearStoredLicense() {
	await chrome.storage.local.remove([LICENSE_STORAGE_KEY]);
	await chrome.storage.local.set({ userTier: 'free' });
	return { success: true };
}

async function getStoredLicense() {
	const data = await chrome.storage.local.get([LICENSE_STORAGE_KEY]);
	return data?.[LICENSE_STORAGE_KEY] || null;
}

function sanitizeLicenseKey(raw) {
	return String(raw || '').trim();
}

function detectLicenseProvider(licenseKey) {
	return /^RH[-_]/i.test(licenseKey) ? 'rockethub' : 'gumroad';
}

async function verifyLicenseWithGumroad(licenseKey) {
	if (!GUMROAD_PRODUCT_PERMALINK) {
		throw new Error('gumroad_product_missing');
	}
	const params = new URLSearchParams({
		license_key: licenseKey,
		product_permalink: GUMROAD_PRODUCT_PERMALINK
	});
	const response = await fetch(`${GUMROAD_VERIFY_ENDPOINT}?${params.toString()}`, {
		method: 'GET',
		headers: { Accept: 'application/json' }
	});
	if (!response.ok) {
		throw new Error(`gumroad_http_${response.status}`);
	}
	const data = await response.json();
	if (data?.success && data?.purchase && data.purchase.refunded !== true && data.purchase.chargebacked !== true) {
		return {
			valid: true,
			provider: 'gumroad',
			customer: {
				email: data.purchase.email || null,
				name: data.purchase.full_name || null
			},
			features: ['Unlimited generations', 'Lifetime deal', 'Priority support']
		};
	}
	return { valid: false, provider: 'gumroad', error: 'invalid_license' };
}

async function verifyLicenseWithRocketHub(licenseKey) {
	if (/^RH[-_][A-Z0-9]{6,}$/i.test(licenseKey)) {
		return {
			valid: true,
			provider: 'rockethub',
			customer: null,
			features: ['Unlimited generations', 'Lifetime deal']
		};
	}
	return { valid: false, provider: 'rockethub', error: 'invalid_license' };
}

function maskLicenseKey(key) {
	const stripped = String(key || '').replace(/\s+/g, '');
	if (!stripped) return '';
	const tail = stripped.slice(-4);
	return `${'•'.repeat(Math.max(stripped.length - 4, 4))}${tail}`;
}

async function getSupabaseUrl() {
	const data = await chrome.storage.sync.get([SUPABASE_URL_KEY]);
	const stored = typeof data[SUPABASE_URL_KEY] === 'string' ? data[SUPABASE_URL_KEY].trim() : '';
	return stored || DEFAULT_SUPABASE_FUNCTION_URL;
}

async function getHistoryEndpoint() {
	const data = await chrome.storage.sync.get([SUPABASE_HISTORY_URL_KEY, SUPABASE_URL_KEY]);
	const configuredHistoryUrl = typeof data[SUPABASE_HISTORY_URL_KEY] === 'string' ? data[SUPABASE_HISTORY_URL_KEY].trim() : '';
	if (configuredHistoryUrl) {
		return configuredHistoryUrl;
	}

	const baseUrl = typeof data[SUPABASE_URL_KEY] === 'string' ? data[SUPABASE_URL_KEY].trim() : DEFAULT_SUPABASE_FUNCTION_URL;
	if (!baseUrl || baseUrl.includes('your-project')) {
		return null;
	}

	// If the configured URL targets a Supabase function (contains /functions/), we cannot infer a history endpoint reliably.
	if (/\/functions\//i.test(baseUrl)) {
		return null;
	}

	return baseUrl.replace(/\/+$/, '') + '/history';
}

async function getApiKey() {
	const data = await chrome.storage.sync.get([SUPABASE_API_KEY_STORAGE_KEY]);
	return typeof data[SUPABASE_API_KEY_STORAGE_KEY] === 'string' ? data[SUPABASE_API_KEY_STORAGE_KEY].trim() : null;
}

async function getCurrentUserTier() {
	const data = await chrome.storage.local.get(['userTier', LICENSE_STORAGE_KEY]);
	const license = data?.[LICENSE_STORAGE_KEY];
	if (license?.status === 'valid' && license?.overrideTier) {
		return license.overrideTier;
	}
	return typeof data.userTier === 'string' ? data.userTier : 'free';
}

async function getHistoryLimit() {
	const data = await chrome.storage.sync.get(['smartClipboard_historyLimit']);
	const parsed = parseInt(data.smartClipboard_historyLimit, 10);
	return Number.isFinite(parsed) && parsed > 0 ? parsed : HISTORY_LIMIT;
}

function isCloudTier(tier) {
	return ['pro', 'business', 'enterprise'].includes((tier || '').toLowerCase());
}

function sanitizeText(text) {
	if (typeof text !== 'string') return '';
	return text.replace(/\s+/g, ' ').replace(/[\u0000-\u001F\u007F]+/g, ' ').trim();
}

function sanitizeForLog(value) {
	if (typeof value !== 'string') {
		value = String(value);
	}
	return value.replace(/[\r\n\t]/g, ' ').slice(0, 160);
}

function formatModelOutput(raw) {
	const text = sanitizeText(String(raw ?? '')).trim();
	if (!text) return '';
	return text.length > 400 ? `${text.slice(0, 397)}...` : text;
}

function normalizeSharedToken(token) {
	if (typeof token !== 'string') {
		return '';
	}
	const trimmed = token.trim();
	if (!trimmed || trimmed === 'HF_TOKEN_PLACEHOLDER') {
		return '';
	}
	if (!/^[A-Za-z0-9_\-]{10,}$/.test(trimmed)) {
		return '';
	}
	return trimmed;
}

async function readSharedTokenFromStorage(area) {
	if (!area?.get) {
		return '';
	}

	return new Promise((resolve) => {
		try {
			area.get(['sharedHfToken'], (items) => {
				if (typeof chrome !== 'undefined' && chrome.runtime?.lastError) {
					resolve('');
					return;
				}
				const stored = items?.sharedHfToken;
				resolve(normalizeSharedToken(stored));
			});
		} catch (_error) {
			resolve('');
		}
	});
}

async function getSharedHfToken() {
	try {
		const configToken = normalizeSharedToken(typeof CONFIG !== 'undefined' ? CONFIG?.HF_TOKEN : null);
		if (configToken) {
			return configToken;
		}
	} catch (_error) {
		// ignore config access failures
	}

	try {
		const syncToken = await readSharedTokenFromStorage(chrome?.storage?.sync);
		if (syncToken) {
			return syncToken;
		}
	} catch (error) {
		logger?.debug?.('Shared token sync lookup failed', error?.message || error);
	}

	try {
		const localToken = await readSharedTokenFromStorage(chrome?.storage?.local);
		if (localToken) {
			return localToken;
		}
	} catch (error) {
		logger?.debug?.('Shared token local lookup failed', error?.message || error);
	}

	return null;
}

async function getEffectiveToken() {
	const userToken = await getStoredToken();
	if (userToken) {
		return { token: userToken, source: 'user' };
	}

	const sharedToken = await getSharedHfToken();
	if (sharedToken) {
		return { token: sharedToken, source: 'shared' };
	}

	return { token: null, source: null };
}

function shouldEnforceQuota(tierKey, tokenSource) {
	if (tokenSource === 'user') {
		return false;
	}

	const helper = typeof quotaHelper !== 'undefined' ? quotaHelper : null;
	if (!helper?.getTierConfig) {
		return tokenSource !== 'user';
	}

	const plan = helper.getTierConfig(tierKey);
	if (!plan) {
		return tokenSource !== 'user';
	}

	return plan.generations !== -1;
}

async function reserveQuotaSlot(tierKey) {
	const helper = typeof quotaHelper !== 'undefined' ? quotaHelper : null;
	const storage = typeof storageHelper !== 'undefined' ? storageHelper : null;

	if (!helper?.checkAndIncrementQuota || !storage?.getOrCreateDeviceId) {
		return { ok: true, tierKey, unlimited: true, shouldRefund: false };
	}

	try {
		const plan = helper.getTierConfig(tierKey);
		if (!plan || plan.generations === -1) {
			return { ok: true, tierKey, unlimited: true, shouldRefund: false };
		}

		const deviceId = await storage.getOrCreateDeviceId();
		const result = await helper.checkAndIncrementQuota(tierKey, deviceId, 1);
		if (!result.ok) {
			return {
				ok: false,
				tierKey,
				deviceId,
				remaining: typeof result.remaining === 'number' ? result.remaining : 0,
				unlimited: false,
				shouldRefund: false
			};
		}

		return {
			ok: true,
			tierKey,
			deviceId,
			remaining: typeof result.remaining === 'number' ? result.remaining : 0,
			unlimited: false,
			shouldRefund: true
		};
	} catch (error) {
		logger?.debug?.('Quota reservation failed', error?.message || error);
		return { ok: true, tierKey, unlimited: true, shouldRefund: false };
	}
}

async function releaseQuotaSlot(reservation) {
	if (!reservation?.shouldRefund) {
		return;
	}

	const helper = typeof quotaHelper !== 'undefined' ? quotaHelper : null;
	if (!helper?.decrementQuota) {
		return;
	}

	try {
		await helper.decrementQuota(reservation.tierKey, reservation.deviceId, 1);
	} catch (error) {
		logger?.debug?.('Quota rollback failed', error?.message || error);
	}
}

async function getStoredToken() {
	try {
		const token = await tokenStore.getToken();
		if (token) return token;
	} catch (error) {
		logger.debug('Token decrypt failed', error?.message);
	}
	const legacy = await new Promise((resolve) => {
		chrome.storage.local.get(['userHfToken'], (data) => {
			if (chrome.runtime?.lastError) {
				logger.debug('Legacy token read error', chrome.runtime.lastError.message);
				resolve(null);
				return;
			}
			resolve(data?.userHfToken || null);
		});
	});
	if (legacy) {
		await tokenStore.setToken(legacy);
		chrome.storage.local.remove(['userHfToken']);
		return legacy;
	}
	return null;
}

async function generateContent(prompt, useCase = 'general') {
	const supabaseUrl = await getSupabaseUrl();
	if (!supabaseUrl || supabaseUrl.includes('your-project')) {
		throw new Error('Supabase URL not configured');
	}

	const apiKey = await getApiKey();

	const response = await fetch(supabaseUrl, {
		method: 'POST',
		headers: {
			'Content-Type': 'application/json',
			...(apiKey ? { Authorization: `Bearer ${apiKey}` } : {})
		},
		body: JSON.stringify({ prompt, useCase })
	});

	if (response.status === 401) {
		throw new Error(apiKey ? 'Supabase rejected API key (401)' : 'Supabase API key missing (401)');
	}

	if (!response.ok) {
		throw new Error(`HTTP error ${response.status}`);
	}

	const data = await response.json();

	if (Array.isArray(data.outputs) && data.outputs.length) return data.outputs;
	if (data.content) return [data.content];
	if (data.result) return [data.result];

	throw new Error('Invalid response from Supabase');
}

// LTD and Pro activation handlers
async function handleVerifyLTDLicense(request) {
	try {
		const { licenseKey, email } = request;
		if (!licenseKey || !email) {
			return { success: false, error: 'License key and email are required' };
		}

		// Basic validation - in production, verify with Supabase
		if (licenseKey.length < 10) {
			return { success: false, error: 'Invalid license key format' };
		}

		return { success: true, verified: true };
	} catch (error) {
		return { success: false, error: error?.message || 'License verification failed' };
	}
}

async function handleGoogleSignIn() {
	try {
		// Placeholder for Google Sign-In - integrate with Supabase Auth
		const mockUser = {
			userId: 'user_' + Date.now(),
			email: 'user@example.com'
		};
		return { success: true, ...mockUser };
	} catch (error) {
		return { success: false, error: error?.message || 'Sign-in failed' };
	}
}

async function handleSaveLTDToCloud(request) {
	try {
		const { userId, email, licenseKey, licenseEmail } = request;
		// Placeholder for Supabase cloud save
		backgroundLogger.debug('Saving LTD to cloud', { userId, email });
		return { success: true, saved: true };
	} catch (error) {
		return { success: false, error: error?.message || 'Failed to save to cloud' };
	}
}

async function handleVerifyGumroadLicense(request) {
	try {
		const { licenseKey } = request;
		if (!licenseKey) {
			return { success: false, error: 'License key is required' };
		}

		// Use existing Gumroad verification
		const verification = await verifyLicenseWithGumroad(licenseKey);
		if (!verification.valid) {
			return { success: false, error: verification.error || 'Invalid license' };
		}

		return { 
			success: true, 
			verified: true,
			email: verification.customer?.email
		};
	} catch (error) {
		return { success: false, error: error?.message || 'License verification failed' };
	}
}

async function handleSaveProToCloud(request) {
	try {
		const { userId, email, licenseKey, gumroadEmail } = request;
		// Placeholder for Supabase cloud save
		backgroundLogger.debug('Saving Pro to cloud', { userId, email });
		return { success: true, saved: true };
	} catch (error) {
		return { success: false, error: error?.message || 'Failed to save to cloud' };
	}
}

async function handleCheckProStatus(request) {
	try {
		// Placeholder for Pro status check
		return { 
			success: true,
			active: true,
			status: 'active',
			nextBilling: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString()
		};
	} catch (error) {
		return { success: false, error: error?.message || 'Status check failed' };
	}
}

debugLog('lifecycle.ready');
