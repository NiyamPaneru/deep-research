# Settings Page Recommendations

## Current Issues
1. Too many upgrade options (LTD + Pro + Gumroad) - confusing
2. No humor integration in settings
3. Complex UI with multiple cards

## Recommended Changes

### Phase 1: RocketHub Launch (2 weeks)
**Show ONLY Lifetime Deal**
- Single prominent card for $29 Lifetime Deal
- Simple license key + email activation
- Hide Pro/Gumroad options completely
- Add humor jokes in settings page

### Phase 2: After RocketHub
**Replace Lifetime with Gumroad Monthly Plans**
- Remove Lifetime Deal card entirely
- Show only Gumroad subscription options
- Basic Plan: $3/month
- Pro Plan: $7/month
- Keep humor jokes

## UI Improvements Needed

### 1. Simplify Upgrade Section
```
┌─────────────────────────────────────┐
│  🚀 RocketHub Exclusive             │
│  Lifetime Deal - $29 (67% OFF!)    │
│                                     │
│  [License Key Input]                │
│  [Email Input]                      │
│  [Activate License Button]          │
│                                     │
│  ⏰ Limited Time: 2 weeks only!     │
└─────────────────────────────────────┘
```

### 2. Add Humor Panel in Settings
- Show rotating jokes in sidebar (like history page)
- Use "settings-general" and "token-setup" category jokes
- Same 90-second rotation

### 3. Personalization Section
Keep existing toggles:
- ✅ Humor mode (ON/OFF)
- ✅ Auto-save clipboard
- ✅ Activity alerts

## Implementation Priority

1. **HIGH**: Simplify upgrade section (show only LTD for now)
2. **HIGH**: Add humor panel to settings page
3. **MEDIUM**: Add countdown timer for RocketHub deal
4. **LOW**: Prepare Gumroad integration for post-launch

## Humor Integration in Settings

### Jokes to Show
- Token setup jokes (when configuring HF token)
- Settings general jokes (in personalization section)
- Upgrade jokes (in lifetime deal card)

### Layout
```
┌──────────────────────────────────────────────┐
│  Settings Content (70%)  │  Humor Panel (30%) │
│  - Upgrade section       │                    │
│  - Personalization       │  [Rotating Joke]   │
│  - AI Providers          │                    │
│  - About                 │  Changes every     │
│                          │  90 seconds        │
└──────────────────────────────────────────────┘
```

## Next Steps

1. Create simplified settings-improved.html with:
   - Only LTD card (hide Pro/Gumroad)
   - Humor panel on right side
   - Cleaner layout

2. Add settingsHumorManager.js:
   - Load settings-specific jokes
   - 90-second rotation
   - Same toggle control

3. Update after RocketHub:
   - Remove LTD card
   - Add Gumroad monthly plans
   - Keep humor system
